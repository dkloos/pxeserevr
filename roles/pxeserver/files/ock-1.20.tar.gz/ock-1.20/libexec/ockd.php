#!/usr/bin/php
<?php

$SCRIPT_ROOT=dirname($_SERVER["PHP_SELF"]);

// Time to sleep inbetween jobs
// Do not set this above 60!!
$job_sleeptime=5;

// Time to sleep inbetween cache updates
$cache_sleeptime=300;


// Do not change below this line
$pid = getmypid();
$hostname = $_SERVER["HOSTNAME"];
$ip = gethostbyname("$hostname");
$base = dirname($_SERVER["PHP_SELF"]);
//print_r($_SERVER);

// Get command line options:
$shortopts = "rd::";
$options = getopt($shortopts);
if (isset($options["d"])) $DEBUG=true;
if (!isset($options["r"])) {
  echo "\n";
  echo "OneClickKick Background Daemon";
  echo "\n";
  echo "  -r : Run daemon \n";
  echo "  -d : Debug mode \n";
  echo "\n";
  echo "Usage: ockd.php -r|[-d]";
  echo "\n\n";
  exit (1);
}


// Include configureation from the web instance:
include("$base/conf/config.php");

// Remember to add functions to index.php!
require("$base/functions/log.php");
include("$base/functions/naming.php");
include("$base/functions/dhcp.php");
include("$base/functions/pxe.php");
include("$base/functions/general.php");
include("$base/include/backports.php");
include("$base/functions/cache.php");

$_SESSION["USERNAME"] = "*ockd*";


function cache_update() {
  global $DEBUG;
  $job_exists = jobs_find("cache_update");
  if (!isset($job_exists[0])) { 
    $jobid = job_create("cache_update");
    $hosts = hosts_list();
    for ($i=0; $i <= count($hosts); $i++) {
      if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
      if (isset($DEBUG)) echo "Updating $hosts[$i] \n";
      // This function will kick off cache refresh
      if (isset($hosts[$i])) host_details_byname($hosts[$i],1);
    }
  }
  // Finish job, but don't log
  job_finish($jobid,0);
}

function jobs_find($job_function=NULL) {
  global $sql, $DEBUG, $pid, $hostname, $ip;
  $ret = array();

  // Find and kill any zombie daemons in the database
  $query = "select job_function, plock from jobs where job_function='ockd_self' and plock=\"$pid\" and plock_host=\"$hostname\"";
  $result = mysql_query("$query", $sql);
  if ($r = mysql_fetch_array($result)) {
    $query = "update jobs set timestamp=NOW() where job_function='ockd_self' and plock=\"$pid\" and plock_host=\"$hostname\"";
    mysql_query("$query", $sql); 
  }
  else {
    $query = "insert into jobs (job_function,job_runuser,plock,plock_host,user,userip) 
	values ('ockd_self', \"". $_SERVER["USER"] . "\" , \"$pid\",\"$hostname\", \"<ockd>\", \"$ip\")";
    mysql_query("$query", $sql);
  }

  // Find jobs...
  $query = "select id, job_function, job_args, job_runuser, plock from jobs where job_function != 'ockd_self'";
  if (!is_null($job_function)) { 
    $query .= " and job_function=\"$job_function\"";
  }
  else {
    $query .= " and plock = 0";
  }

  $result = mysql_query("$query", $sql);

  $j = 0;
  while ( $r = mysql_fetch_array($result) ) {
    $job_function = $r["job_function"];
    // Sanity check, if this job_function is already running, do not run.
    $query = "select id from jobs where job_function=\"$job_function\" and plock > 0";
    if (mysql_num_rows(mysql_query("$query", $sql)) > 0) {
      if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
      if (isset($DEBUG)) echo "Skipping $job_function, it's already being run.";
      continue;
    }
    $id = $r["id"];
    if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
    if (isset($DEBUG)) echo "New job:  $job_function \n";
    $ret[$j]["id"] = $id;
    $ret[$j]["job_function"] = $job_function;
    $ret[$j]["job_args"] = $job_args;
    $ret[$j]["job_runuser"] = $job_runuser;
    $j++;
  }
  return $ret;
}


function job_create($job_function) {
  global $sql, $DEBUG, $pid, $hostname, $ip;
  $query = "insert into jobs (job_function,plock,plock_host,user,userip) 
	values (\"$job_function\",\"$pid\",\"$hostname\", \"<ockd>\", \"$ip\")";
  mysql_query("$query", $sql);
  $id = mysql_insert_id($sql);
  if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
  if (isset($DEBUG)) echo "Adding job $job_function ($pid)";
  return($id);
}


function job_lock($id) {
  global $sql, $DEBUG, $pid, $hostname;
  $query = "update jobs set plock=\"$pid\", plock_host=\"$hostname\" where id=\"$id\"";
  mysql_query("$query", $sql);
}


function job_finish($id,$log=1) {
  global $sql, $DEBUG, $pid;
  $query = "select job_function,user,userip from jobs where id=\"$id\"";
  $result = mysql_query("$query", $sql);
  $r = mysql_fetch_array($result);
  $job_function = $r["job_function"];
  $user = $r["user"];
  $remoteip = $r["userip"];
 
  $query = "delete from jobs where id=\"$id\" and plock=\"$pid\"";
  mysql_query("$query", $sql);
  if ($log == 1) writelog("info","ockd job finished: $job_function",0,"ockd", "$user", "$remoteip" );
}


function ockd_check_dead_agents() {
  global $sql, $DEBUG, $pid, $hostname;
  $query = "select id,timestamp,plock from jobs where plock_host=\"$hostname\" group by plock";
  $result = mysql_query("$query", $sql);
  while ($r = mysql_fetch_array($result)) {
    if (!posix_getsid($r["plock"])) {
      if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
      if (isset($DEBUG)) echo "Found dead agent with pid: " .$r["plock"] . ", removing from database and resetting jobs \n";
      $query = "delete from jobs where job_function='ockd_self' and plock='" . $r["plock"] . "'";
      mysql_query("$query", $sql);
      $query = "update jobs set plock='0' where job_function!='ockd_self' and plock='" . $r["plock"] . "'";
      mysql_query("$query", $sql);
    }
  }
}


function ockd_exit() {
  global $sql, $DEBUG, $pid;
  $query = "delete from jobs where plock=\"$pid\"";
  mysql_query("$query", $sql);
}

register_shutdown_function('ockd_exit');




// MAIN RUN


$job_sleep = 0;
$cache_sleep = 0;

if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
if (isset($DEBUG)) echo "job_sleeptime: $job_sleeptime, cache_sleeptime: $cache_sleeptime  ... \n";

while (true) {
  if (!mysql_ping($sql)) include("$base/conf/config.dynamic.sql.php");
  //include("$base/conf/config.dynamic.ldap.php");
  if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
  if (isset($DEBUG)) echo "job_sleep: $job_sleep, cache_sleep: $cache_sleep  ... \n";

  if ($job_sleep > $job_sleeptime) $job_sleep = 0;
  if ($cache_sleep > $cache_sleeptime) $cache_sleep = 0;

  if ($_SESSION["CFG"]["cacheenabled"] == 1 && $cache_sleep == 0) {
    if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
    if (isset($DEBUG)) echo "Running hosts_update...\n";
    cache_update();
  }

  if ($job_sleep == 0) {
    if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
    if (isset($DEBUG)) echo "Checking for dead agents and stuck jobs...\n";
    ockd_check_dead_agents();
    if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
    if (isset($DEBUG)) echo "Running jobs_find...\n";
    $jobs = jobs_find();

    for ($i=0; $i < count($jobs); $i++) {
      $id = $jobs[$i]["id"];
      $job = $jobs[$i]["job_function"];
      $job_args = $jobs[$i]["job_args"];
      $job_runuser = $jobs[$i]["job_runuser"];
      if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
      if (isset($DEBUG)) echo "Setting lock for job: $job \n";
      job_lock($id);
      if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
      if (isset($DEBUG)) echo "Running job: $job \n";
      if (isset($job_args)) {
        $job($job_args);
      }
      else {
	$job();
      }

      if (isset($DEBUG)) echo date(DATE_RFC822) . ": ";
      if (isset($DEBUG)) echo "Finishing job: $job \n";
      job_finish($id);
    }

  }

  $cache_sleep = $cache_sleep + 1;
  $job_sleep = $job_sleep + 1;
  sleep(1);
  //if (isset($DEBUG)) echo "\n\n\n";
}


?>
