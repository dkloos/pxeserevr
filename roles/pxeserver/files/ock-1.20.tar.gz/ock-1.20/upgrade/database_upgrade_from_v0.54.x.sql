--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache` (
  `ctype` varchar(10) NOT NULL,
  `ckey` varchar(255) NOT NULL,
  `cval` varchar(255) NOT NULL,
  `csource` varchar(64) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `plock` int(11) default '0',
  KEY `ctype` (`ctype`,`ckey`,`cval`),
  KEY `ckey` (`ckey`),
  KEY `cval` (`cval`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL auto_increment,
  `job_function` varchar(128) NOT NULL,
  `job_args` varchar(255) default NULL,
  `job_runuser` varchar(255) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `plock` int(11) default '0',
  `plock_host` varchar(255) default NULL,
  `user` varchar(255) NOT NULL,
  `userip` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6675 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;


--
-- Table structure for table `os`
--

DROP TABLE IF EXISTS `os`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `os` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `os`
--

LOCK TABLES `os` WRITE;
/*!40000 ALTER TABLE `os` DISABLE KEYS */;
INSERT INTO `os` VALUES (1,'Other');
INSERT INTO `os` VALUES (2,'DOS');
INSERT INTO `os` VALUES (3,'Red Hat');
INSERT INTO `os` VALUES (4,'Fedora');
INSERT INTO `os` VALUES (5,'Debian');
INSERT INTO `os` VALUES (6,'Ubuntu');
INSERT INTO `os` VALUES (7,'CentOS');
INSERT INTO `os` VALUES (8,'Slackware');
INSERT INTO `os` VALUES (9,'Mandriva');
INSERT INTO `os` VALUES (10,'Scientific Linux');
INSERT INTO `os` VALUES (11,'Linux Mint');
INSERT INTO `os` VALUES (12,'Solaris');
INSERT INTO `os` VALUES (13,'OpenSolaris');
INSERT INTO `os` VALUES (14,'OpenIndiana');
INSERT INTO `os` VALUES (15,'SUSE');
INSERT INTO `os` VALUES (16,'FreeBSD');
INSERT INTO `os` VALUES (17,'OpenBSD');
INSERT INTO `os` VALUES (18,'PCLinuxOS');
INSERT INTO `os` VALUES (19,'ArchLinux');
INSERT INTO `os` VALUES (20,'Puppy Linux');
/*!40000 ALTER TABLE `os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logtype`
--

DROP TABLE IF EXISTS `logtype`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `logtype` (
  `id` int(11) NOT NULL auto_increment,
  `logname` varchar(16) NOT NULL,
  `comment` varchar(255) default NULL,
  `refidcol` varchar(128) default NULL,
  `refidtbl` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `logname` (`logname`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `logtype`
--

LOCK TABLES `logtype` WRITE;
/*!40000 ALTER TABLE `logtype` DISABLE KEYS */;
INSERT INTO `logtype` VALUES (1,'security','Security','username','users');
INSERT INTO `logtype` VALUES (3,'kickstart','Kickstart','hostname','dhcpgroupmem');
INSERT INTO `logtype` VALUES (4,'hostconfig','Host','hostname','dhcpgroupmem');
INSERT INTO `logtype` VALUES (5,'dhcpsconfig','DHCP subnet','descr','dhcpsubnet');
INSERT INTO `logtype` VALUES (6,'dhcpgconfig','DHCP group','groupname','dhcpgroup');
INSERT INTO `logtype` VALUES (7,'dhcpconfig','DHCP general',NULL,NULL);
INSERT INTO `logtype` VALUES (8,'pxepconfig','PXE profile','name','pxeprofile');
INSERT INTO `logtype` VALUES (9,'error','General error','message','error');
INSERT INTO `logtype` VALUES (10,'info','General info','message','error');
/*!40000 ALTER TABLE `logtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `error`
--

DROP TABLE IF EXISTS `error`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `error` (
  `id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `error`
--

LOCK TABLES `error` WRITE;
/*!40000 ALTER TABLE `error` DISABLE KEYS */;
INSERT INTO `error` VALUES (0,'OK');
INSERT INTO `error` VALUES (95,'File system error');
INSERT INTO `error` VALUES (1,'Not found');
INSERT INTO `error` VALUES (255,'General failure');
INSERT INTO `error` VALUES (5,'Already exists');
INSERT INTO `error` VALUES (6,'File did not upload');
INSERT INTO `error` VALUES (7,'File size too large');
INSERT INTO `error` VALUES (8,'DHCP restart failed');
INSERT INTO `error` VALUES (9,'DHCP config test failed. Please examine the output for errors.');
INSERT INTO `error` VALUES (10,'Could not add DHCP group config');
INSERT INTO `error` VALUES (11,'Could not update DHCP group config');
INSERT INTO `error` VALUES (12,'Cannot delete the super-user account');
INSERT INTO `error` VALUES (13,'Failed to write to log');
INSERT INTO `error` VALUES (14,'Could not retreive values from database');
INSERT INTO `error` VALUES (15,'File/folder permission error');
INSERT INTO `error` VALUES (16,'Not a valid boot image');
INSERT INTO `error` VALUES (17,'Boot image already exists (folder name error)');
INSERT INTO `error` VALUES (18,'Boot image is still in use by PXE profiles');
INSERT INTO `error` VALUES (19,'Failed to update config with default settings');
/*!40000 ALTER TABLE `error` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

