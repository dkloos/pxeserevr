alter table dhcpsubnet add autoip_offset int(255) default NULL after descr;

alter table dhcpgroupmem add ipa_otp varchar(255) default NULL after statichost;

alter table dhcpgroup add hostfqdn int(1) default 0 after statichosts;

CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tagtype` varchar(64) NOT NULL,
  `tagname` varchar(255) NOT NULL,
  `tagvalue` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

