alter table pxeprofile add imagedir varchar(255) not null after name;
alter table pxeprofile add imagereadme blob after imagedir;

alter table dhcpgroupmem add statichost int(1) default 0 after dhcpgroupid;

alter table dhcpsubnet add statichosts int(1) default 0 after netmask;

alter table dhcpgroup add statichosts int(1) default 0 after groupname;

insert into error values (18,"Boot image is still in use by PXE profiles");

