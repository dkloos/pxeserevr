#!/bin/bash

#
#Script to create One Click Kick images
#

OCKVERSION=1.0
ZIP=/usr/bin/zip
ZIPOPTS="-r"
RM=/bin/rm

if [ $1 ]; then
  i=$1;
  echo "Removing existing image $i ..."
  $RM ockimage-$i-v$OCKVERSION.zip
  if [ -f $i/.ockimage ]; then
    echo "Creating image for $i..."
    $ZIP $ZIPOPTS ockimage-$i-v$OCKVERSION.zip $i/* $i/.ockimage
  fi

else
  echo "Removing exiting images..."
  $RM ockimage-*.zip

  for i in `ls`; do
    if [ -f $i/.ockimage ]; then
      echo "Creating image for $i..."
      $ZIP $ZIPOPTS ockimage-$i-v$OCKVERSION.zip $i/* $i/.ockimage
    fi
  done
fi

