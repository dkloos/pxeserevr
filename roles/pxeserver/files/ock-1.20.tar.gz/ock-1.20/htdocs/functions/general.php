<?php

function errormsg($id) {
  global $sql;
  $result = mysql_query("select message from error where id=$id", $sql);
  if (mysql_num_rows($result) > 0) {
    $r = mysql_fetch_array($result);
    $ret = $r[message];
  }
  else {
    $ret = 255;
  }
  writelog("error","$r[message]",$id,"");
  return $ret;
}


function config_avail_options() {
  $ret = array();
  $i = 0;
  $ret[$i]["item"] = "";
  $ret[$i]["desc"] = "<b>General</b>";
  $ret[$i]["type"] = "text";
  $i++;
  $ret[$i]["item"] = "webui_hostname";
  $ret[$i]["desc"] = "WEB UI Hostname";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "default_timezone";
  $ret[$i]["desc"] = "Default Timezone";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "template";
  $ret[$i]["desc"] = "Theme";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "kswebserver";
  $ret[$i]["desc"] = "IP address to serve kickstart";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "uploaddir";
  $ret[$i]["desc"] = "Upload directory";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "hostfqdn";
  $ret[$i]["desc"] = "Use FQDN for hostname";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "webtimeout";
  $ret[$i]["desc"] = "Web interface timout (seconds)";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "kickstart_unknown";
  $ret[$i]["desc"] = "Serve kickstart scripts to unknown clients";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "pxe_warning_timeout";
  $ret[$i]["desc"] = "PXE Warning Timeout (in minutes, 0 to disable)";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "kerbauth";
  $ret[$i]["desc"] = "WEB UI Kerberos Authentication";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "";
  $ret[$i]["desc"] = "<b>Naming services</b>";
  $ret[$i]["type"] = "text";
  $i++;
  $ret[$i]["item"] = "cacheenabled";
  $ret[$i]["desc"] = "Name caching";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "cachetimeout";
  $ret[$i]["desc"] = "Name cache timeout (seconds)";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "ldapenabled";
  $ret[$i]["desc"] = "LDAP lookups";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "ldap_bind_type";
  $ret[$i]["desc"] = "LDAP bind type";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "ldap_servers";
  $ret[$i]["desc"] = "LDAP servers";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "ldap_server_port";
  $ret[$i]["desc"] = "LDAP server port";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "ldap_base";
  $ret[$i]["desc"] = "LDAP base";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "ldap_bind_user";
  $ret[$i]["desc"] = "LDAP bind user";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "ldap_bind_password";
  $ret[$i]["desc"] = "LDAP bind password";
  $ret[$i]["type"] = "password";
  $i++;
  $ret[$i]["item"] = "ldap_ipa";
  $ret[$i]["desc"] = "LDAP is an IPA server";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "nisenabled";
  $ret[$i]["desc"] = "NIS lookups";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "nisdomain";
  $ret[$i]["desc"] = "NIS domain";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "mysqlenabled";
  $ret[$i]["desc"] = "MySQL lookups";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "";
  $ret[$i]["desc"] = "<b>DHCP</b>";
  $ret[$i]["type"] = "text";
  $i++;
  $ret[$i]["item"] = "f_dhcpd_conf";
  $ret[$i]["desc"] = "DHCP daemon config file";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "dhcpd_bin";
  $ret[$i]["desc"] = "DHCP daemon binary";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "dhcpd_cmd_restart";
  $ret[$i]["desc"] = "DHCP daemon restart command";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "dhcpd_syslog_file";
  $ret[$i]["desc"] = "DHCP daemon syslog file";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "";
  $ret[$i]["desc"] = "<b>TFTP / PXE</b>";
  $ret[$i]["type"] = "text";
  $i++;
  $ret[$i]["item"] = "tftpserver";
  $ret[$i]["desc"] = "Default Boot Server IP Address";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "tftpimagedir";
  $ret[$i]["desc"] = "Boot Image Dirctory";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "pxeconfigdir";
  $ret[$i]["desc"] = "PXELINUX config directory";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "bootpassword";
  $ret[$i]["desc"] = "Boot Password";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "pxemenutitle";
  $ret[$i]["desc"] = "PXE Menu Title";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "";
  $ret[$i]["desc"] = "<b>Enrollment support</b>";
  $ret[$i]["type"] = "text";
  $i++;
  $ret[$i]["item"] = "enrollment_hostname_prefix";
  $ret[$i]["desc"] = "Default hostname prefix";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "enrollment_hostname_auto_suffix";
  $ret[$i]["desc"] = "Hostname automatic suffix";
  $ret[$i]["type"] = "dropbox";
  $i++;
  $ret[$i]["item"] = "enrollment_hostname_domain";
  $ret[$i]["desc"] = "Default hostname DNS domain";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "enrollment_default_dhcp_group_id";
  $ret[$i]["desc"] = "Default DHCP group";
  $ret[$i]["type"] = "dropbox";
  $i++;
  return $ret;
}


/*
 * Return value of specific config option
 *
 * $item = configuration item to retreive value for
*/
function config_get_optvalue($item) {
  global $sql,$sm_template_dir;
  $q = "select value from config where item=\"$item\"";
  $result = mysql_query("$q", $sql);
  if ($result) $r = mysql_fetch_array($result);
  $ret = $r["value"];
  // If a the template item is requested, list all available templates from the $sm_template_dir
  if ($item == "template") {
    $current = $ret;
    $d = dir("$sm_template_dir");
    $ret = array();
    $i = 0;
    while (false !== ($entry = $d->read())) {
      if (is_file("$sm_template_dir/$entry/.ocktemplate")) {
        $text = $entry;
        if (file_get_contents("$sm_template_dir/$entry/.ocktemplate") != "") $text = san_input_str(file_get_contents("$sm_template_dir/$entry/.ocktemplate"));
        $ret[$i]["value"] = $entry;
        $ret[$i]["text"] = $text;
        if ($entry == $current) {
          $ret[$i]["selected"] = 1;
        }
	      $i++;
      }
    }
    $d->close();
  }
  elseif ($item == "default_timezone") {
    $current = $ret;
    $ret = array();
    include("functions/kickstart.php");
    $kf = new kickstart_func();
    $ls = $kf->list_timezone();
    for($i=0; $i < count($ls); $i++) {
      $ret[$i]["value"] = $ls[$i];
      $ret[$i]["text"] = $ls[$i];
      if ($ls[$i] == $current) {
        $ret[$i]["selected"] = 1;
      }
    }
  }

  elseif ($item == "nisenabled" || $item == "ldapenabled" || $item == "mysqlenabled" || $item == "hostfqdn" || $item == "kickstart_unknown" || $item == "cacheenabled" || $item == "ldap_ipa" || $item == "kerbauth") {
    $current = $ret;
    unset($ls,$ret);
    $ls = array();
    $ls[0]["value"] = "";
    $ls[0]["text"] = "Disabled";
    $ls[1]["value"] = "1";
    $ls[1]["text"] = "Enabled";
    for($i=0; $i < count($ls); $i++) {
      $ret[$i]["value"] = $ls[$i]["value"];
      $ret[$i]["text"] = $ls[$i]["text"];
      if ($ls[$i]["value"] == $current) {
        $ret[$i]["selected"] = 1;
      }
    }
  }

  elseif ($item == "ldap_bind_type") {
    $current = $ret;
    unset($ls,$ret);
    $ls = array();
    $ls[0]["value"] = "";
    $ls[0]["text"] = "Anonymous";
    $ls[1]["value"] = "ldap";
    $ls[1]["text"] = "Authenticated";
    $ls[2]["value"] = "ldaps";
    $ls[2]["text"] = "Authenticated SSL";
    for($i=0; $i < count($ls); $i++) {
      $ret[$i]["value"] = $ls[$i]["value"];
      $ret[$i]["text"] = $ls[$i]["text"];
      if ($ls[$i]["value"] == $current) {
        $ret[$i]["selected"] = 1;
      }
    }
  }
  elseif ($item == "enrollment_hostname_auto_suffix") {
    $current = $ret;
    unset($ls,$ret);
    $ls = array();
    $ls[0]["value"] = "none";
    $ls[0]["text"] = "None";
    $ls[1]["value"] = "numbered";
    $ls[1]["text"] = "Numbered";
    $ls[2]["value"] = "system-serial-number";
    $ls[2]["text"] = "System Serial Number";
    for($i=0; $i < count($ls); $i++) {
      $ret[$i]["value"] = $ls[$i]["value"];
      $ret[$i]["text"] = $ls[$i]["text"];
      if ($ls[$i]["value"] == $current) {
        $ret[$i]["selected"] = 1;
      }
    }
  }
  elseif ($item == "enrollment_default_dhcp_group_id") {
    $current = $ret;
    unset($ls,$ret);
    $ls = array();
    $ls[0]["value"] = "none";
    $ls[0]["text"] = "None";
    $dhcp_groups = dhcp_groups();
    $j = 1;
    for ($i=0; $i < count($dhcp_groups); $i++) {
      $ls[$j]["value"] = $dhcp_groups[$i]["id"];
      $ls[$j]["text"] = $dhcp_groups[$i]["groupname"];
      $j++;
    }

    for($i=0; $i < count($ls); $i++) {
      $ret[$i]["value"] = $ls[$i]["value"];
      $ret[$i]["text"] = $ls[$i]["text"];
      if ($ls[$i]["value"] == $current) {
        $ret[$i]["selected"] = 1;
      }
    }
  }
  elseif ($item == "webui_hostname" && !isset($ret)) {
    $ret = $_SERVER["SERVER_NAME"] . ":" . $_SERVER["SERVER_PORT"];
  }

  return $ret;
}


/*
 * Set a value in the config table
 *
 * If a value is not present, the item will be deleted from the config table.
 *
 * $item = configuration item
 * $value = value to be set for the configuration item
*/
function config_set_optvalue($item,$value) {
  global $sql;
  $ret = 255;
  $q = "select item from config where item=\"$item\"";
  $result = mysql_query("$q", $sql);
  if (mysql_num_rows($result) > 0) {
    if ($value) {
      $q = "update config set value=\"$value\" where item=\"$item\"";
    }
    else {
      //$q = "delete from config where item=\"$item\"";
      $q = "update config set value=\"\" where item=\"$item\"";
    }
  }
  else {
    $q = "insert into config (item,value) values (\"$item\",\"$value\")";
  }
  $result = mysql_query("$q", $sql);
  if ($result) $ret = 0;
  return $ret;
}

function config_update($post) {
  $ret = 0;
  foreach($post as $key => $value) {
    $out = config_set_optvalue($key,$value);
    if ($out > 0) $ret = $out;
  }
  return $ret;
}

/** 
 * Recursively delete a directory 
 * 
 * @param string $dir Directory name 
 * @param boolean $deleteRootToo Delete specified top-level directory as well 
 */ 
function unlinkRecursive($dir, $deleteRootToo) 
{ 
    if(!$dh = @opendir($dir)) 
    { 
        return false; 
    } 
    while (false !== ($obj = readdir($dh))) 
    { 
        if($obj == '.' || $obj == '..') 
        { 
            continue; 
        } 

        if (!@unlink($dir . '/' . $obj)) 
        { 
            unlinkRecursive($dir.'/'.$obj, true); 
        } 
    } 

    closedir($dh); 
    
    if ($deleteRootToo) 
    { 
        @rmdir($dir);
    } 
    
    return true; 
} 


/** 
 * Copy file or folder from source to destination, it can do 
 * recursive copy as well and is very smart 
 * It recursively creates the dest file or directory path if there weren't exists 
 * Situtaions : 
 * - Src:/home/test/file.txt ,Dst:/home/test/b ,Result:/home/test/b -> If source was file copy file.txt name with b as name to destination 
 * - Src:/home/test/file.txt ,Dst:/home/test/b/ ,Result:/home/test/b/file.txt -> If source was file Creates b directory if does not exsits and copy file.txt into it 
 * - Src:/home/test ,Dst:/home/ ,Result:/home/test/** -> If source was directory copy test directory and all of its content into dest      
 * - Src:/home/test/ ,Dst:/home/ ,Result:/home/**-> if source was direcotry copy its content to dest 
 * - Src:/home/test ,Dst:/home/test2 ,Result:/home/test2/** -> if source was directoy copy it and its content to dest with test2 as name 
 * - Src:/home/test/ ,Dst:/home/test2 ,Result:->/home/test2/** if source was directoy copy it and its content to dest with test2 as name 
 * @todo 
 *     - Should have rollback technique so it can undo the copy when it wasn't successful 
 *  - Auto destination technique should be possible to turn off 
 *  - Supporting callback function 
 *  - May prevent some issues on shared enviroments : http://us3.php.net/umask 
 * @param $source //file or folder 
 * @param $dest ///file or folder 
 * @param $options //folderPermission,filePermission 
 * @return boolean 
 */ 
function smartCopy($source, $dest, $options=array('folderPermission'=>0755,'filePermission'=>0755)) 
{ 
    $result=false; 
    
    if (is_file($source)) { 
        if ($dest[strlen($dest)-1]=='/') { 
            if (!file_exists($dest)) { 
                cmfcDirectory::makeAll($dest,$options['folderPermission'],true); 
            } 
            $__dest=$dest."/".basename($source); 
        } else { 
            $__dest=$dest; 
        } 
        $result=copy($source, $__dest); 
        chmod($__dest,$options['filePermission']); 
        
    } elseif(is_dir($source)) { 
        if ($dest[strlen($dest)-1]=='/') { 
            if ($source[strlen($source)-1]=='/') { 
                //Copy only contents 
            } else { 
                //Change parent itself and its contents 
                $dest=$dest.basename($source); 
                @mkdir($dest); 
                chmod($dest,$options['filePermission']); 
            } 
        } else { 
            if ($source[strlen($source)-1]=='/') { 
                //Copy parent directory with new name and all its content 
                @mkdir($dest,$options['folderPermission']); 
                chmod($dest,$options['filePermission']); 
            } else { 
                //Copy parent directory with new name and all its content 
                @mkdir($dest,$options['folderPermission']); 
                chmod($dest,$options['filePermission']); 
            } 
        } 

        $dirHandle=opendir($source); 
        while($file=readdir($dirHandle)) 
        { 
            if($file!="." && $file!="..") 
            { 
                 if(!is_dir($source."/".$file)) { 
                    $__dest=$dest."/".$file; 
                } else { 
                    $__dest=$dest."/".$file; 
                } 
                //echo "$source/$file ||| $__dest<br />"; 
                $result=smartCopy($source."/".$file, $__dest, $options); 
            } 
        } 
        closedir($dirHandle); 
        
    } else { 
        $result=false; 
    } 
    return $result; 
} 

// Curtecy of www.mrnaz.com

function rand_string($len, $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789')
{
    $string = '';
    for ($i = 0; $i < $len; $i++)
    {
        $pos = rand(0, strlen($chars)-1);
        $string .= $chars{$pos};
    }
    return $string;
}

function san_input_str($string) {
  $ret = strip_tags($string);
  return $ret;

}

function make_formid($input) {
  if (isset($input)) {
    $TRIM_CHRS = array ('/,/', '/;/', '/-/', '/_/', '/ /');
    $ret = preg_replace($TRIM_CHRS, '', $input);
  } 
  else {
    $ret = false;
  }
  return $ret;
}

function list_timezones() {
/**
 * Timezone List
 * Array compiled from timezone_identifiers_list() that can be used on
 * systems that do not support the function but a list of timezones is
 * needed anyway
 **/

  $timezone = array(
		'Africa/Abidjan',
		'Africa/Accra',
		'Africa/Addis_Ababa',
		'Africa/Algiers',
		'Africa/Asmara',
		'Africa/Bamako',
		'Africa/Bangui',
		'Africa/Banjul',
		'Africa/Bissau',
		'Africa/Blantyre',
		'Africa/Brazzaville',
		'Africa/Bujumbura',
		'Africa/Cairo',
		'Africa/Casablanca',
		'Africa/Ceuta',
		'Africa/Conakry',
		'Africa/Dakar',
		'Africa/Dar_es_Salaam',
		'Africa/Djibouti',
		'Africa/Douala',
		'Africa/El_Aaiun',
		'Africa/Freetown',
		'Africa/Gaborone',
		'Africa/Harare',
		'Africa/Johannesburg',
		'Africa/Kampala',
		'Africa/Khartoum',
		'Africa/Kigali',
		'Africa/Kinshasa',
		'Africa/Lagos',
		'Africa/Libreville',
		'Africa/Lome',
		'Africa/Luanda',
		'Africa/Lubumbashi',
		'Africa/Lusaka',
		'Africa/Malabo',
		'Africa/Maputo',
		'Africa/Maseru',
		'Africa/Mbabane',
		'Africa/Mogadishu',
		'Africa/Monrovia',
		'Africa/Nairobi',
		'Africa/Ndjamena',
		'Africa/Niamey',
		'Africa/Nouakchott',
		'Africa/Ouagadougou',
		'Africa/Porto-Novo',
		'Africa/Sao_Tome',
		'Africa/Tripoli',
		'Africa/Tunis',
		'Africa/Windhoek',
		'America/Adak',
		'America/Anchorage',
		'America/Anguilla',
		'America/Antigua',
		'America/Araguaina',
		'America/Argentina/Buenos_Aires',
		'America/Argentina/Catamarca',
		'America/Argentina/Cordoba',
		'America/Argentina/Jujuy',
		'America/Argentina/La_Rioja',
		'America/Argentina/Mendoza',
		'America/Argentina/Rio_Gallegos',
		'America/Argentina/Salta',
		'America/Argentina/San_Juan',
		'America/Argentina/San_Luis',
		'America/Argentina/Tucuman',
		'America/Argentina/Ushuaia',
		'America/Aruba',
		'America/Asuncion',
		'America/Atikokan',
		'America/Bahia',
		'America/Barbados',
		'America/Belem',
		'America/Belize',
		'America/Blanc-Sablon',
		'America/Boa_Vista',
		'America/Bogota',
		'America/Boise',
		'America/Cambridge_Bay',
		'America/Campo_Grande',
		'America/Cancun',
		'America/Caracas',
		'America/Cayenne',
		'America/Cayman',
		'America/Chicago',
		'America/Chihuahua',
		'America/Costa_Rica',
		'America/Cuiaba',
		'America/Curacao',
		'America/Danmarkshavn',
		'America/Dawson',
		'America/Dawson_Creek',
		'America/Denver',
		'America/Detroit',
		'America/Dominica',
		'America/Edmonton',
		'America/Eirunepe',
		'America/El_Salvador',
		'America/Fortaleza',
		'America/Glace_Bay',
		'America/Godthab',
		'America/Goose_Bay',
		'America/Grand_Turk',
		'America/Grenada',
		'America/Guadeloupe',
		'America/Guatemala',
		'America/Guayaquil',
		'America/Guyana',
		'America/Halifax',
		'America/Havana',
		'America/Hermosillo',
		'America/Indiana/Indianapolis',
		'America/Indiana/Knox',
		'America/Indiana/Marengo',
		'America/Indiana/Petersburg',
		'America/Indiana/Tell_City',
		'America/Indiana/Vevay',
		'America/Indiana/Vincennes',
		'America/Indiana/Winamac',
		'America/Inuvik',
		'America/Iqaluit',
		'America/Jamaica',
		'America/Juneau',
		'America/Kentucky/Louisville',
		'America/Kentucky/Monticello',
		'America/La_Paz',
		'America/Lima',
		'America/Los_Angeles',
		'America/Maceio',
		'America/Managua',
		'America/Manaus',
		'America/Marigot',
		'America/Martinique',
		'America/Mazatlan',
		'America/Menominee',
		'America/Merida',
		'America/Mexico_City',
		'America/Miquelon',
		'America/Moncton',
		'America/Monterrey',
		'America/Montevideo',
		'America/Montreal',
		'America/Montserrat',
		'America/Nassau',
		'America/New_York',
		'America/Nipigon',
		'America/Nome',
		'America/Noronha',
		'America/North_Dakota/Center',
		'America/North_Dakota/New_Salem',
		'America/Panama',
		'America/Pangnirtung',
		'America/Paramaribo',
		'America/Phoenix',
		'America/Port-au-Prince',
		'America/Port_of_Spain',
		'America/Porto_Velho',
		'America/Puerto_Rico',
		'America/Rainy_River',
		'America/Rankin_Inlet',
		'America/Recife',
		'America/Regina',
		'America/Resolute',
		'America/Rio_Branco',
		'America/Santarem',
		'America/Santiago',
		'America/Santo_Domingo',
		'America/Sao_Paulo',
		'America/Scoresbysund',
		'America/Shiprock',
		'America/St_Barthelemy',
		'America/St_Johns',
		'America/St_Kitts',
		'America/St_Lucia',
		'America/St_Thomas',
		'America/St_Vincent',
		'America/Swift_Current',
		'America/Tegucigalpa',
		'America/Thule',
		'America/Thunder_Bay',
		'America/Tijuana',
		'America/Toronto',
		'America/Tortola',
		'America/Vancouver',
		'America/Whitehorse',
		'America/Winnipeg',
		'America/Yakutat',
		'America/Yellowknife',
		'Antarctica/Casey',
		'Antarctica/Davis',
		'Antarctica/DumontDUrville',
		'Antarctica/Mawson',
		'Antarctica/McMurdo',
		'Antarctica/Palmer',
		'Antarctica/Rothera',
		'Antarctica/South_Pole',
		'Antarctica/Syowa',
		'Antarctica/Vostok',
		'Arctic/Longyearbyen',
		'Asia/Aden',
		'Asia/Almaty',
		'Asia/Amman',
		'Asia/Anadyr',
		'Asia/Aqtau',
		'Asia/Aqtobe',
		'Asia/Ashgabat',
		'Asia/Baghdad',
		'Asia/Bahrain',
		'Asia/Baku',
		'Asia/Bangkok',
		'Asia/Beirut',
		'Asia/Bishkek',
		'Asia/Brunei',
		'Asia/Choibalsan',
		'Asia/Chongqing',
		'Asia/Colombo',
		'Asia/Damascus',
		'Asia/Dhaka',
		'Asia/Dili',
		'Asia/Dubai',
		'Asia/Dushanbe',
		'Asia/Gaza',
		'Asia/Harbin',
		'Asia/Ho_Chi_Minh',
		'Asia/Hong_Kong',
		'Asia/Hovd',
		'Asia/Irkutsk',
		'Asia/Jakarta',
		'Asia/Jayapura',
		'Asia/Jerusalem',
		'Asia/Kabul',
		'Asia/Kamchatka',
		'Asia/Karachi',
		'Asia/Kashgar',
		'Asia/Kathmandu',
		'Asia/Kolkata',
		'Asia/Krasnoyarsk',
		'Asia/Kuala_Lumpur',
		'Asia/Kuching',
		'Asia/Kuwait',
		'Asia/Macau',
		'Asia/Magadan',
		'Asia/Makassar',
		'Asia/Manila',
		'Asia/Muscat',
		'Asia/Nicosia',
		'Asia/Novosibirsk',
		'Asia/Omsk',
		'Asia/Oral',
		'Asia/Phnom_Penh',
		'Asia/Pontianak',
		'Asia/Pyongyang',
		'Asia/Qatar',
		'Asia/Qyzylorda',
		'Asia/Rangoon',
		'Asia/Riyadh',
		'Asia/Sakhalin',
		'Asia/Samarkand',
		'Asia/Seoul',
		'Asia/Shanghai',
		'Asia/Singapore',
		'Asia/Taipei',
		'Asia/Tashkent',
		'Asia/Tbilisi',
		'Asia/Tehran',
		'Asia/Thimphu',
		'Asia/Tokyo',
		'Asia/Ulaanbaatar',
		'Asia/Urumqi',
		'Asia/Vientiane',
		'Asia/Vladivostok',
		'Asia/Yakutsk',
		'Asia/Yekaterinburg',
		'Asia/Yerevan',
		'Atlantic/Azores',
		'Atlantic/Bermuda',
		'Atlantic/Canary',
		'Atlantic/Cape_Verde',
		'Atlantic/Faroe',
		'Atlantic/Madeira',
		'Atlantic/Reykjavik',
		'Atlantic/South_Georgia',
		'Atlantic/St_Helena',
		'Atlantic/Stanley',
		'Australia/Adelaide',
		'Australia/Brisbane',
		'Australia/Broken_Hill',
		'Australia/Currie',
		'Australia/Darwin',
		'Australia/Eucla',
		'Australia/Hobart',
		'Australia/Lindeman',
		'Australia/Lord_Howe',
		'Australia/Melbourne',
		'Australia/Perth',
		'Australia/Sydney',
		'Europe/Amsterdam',
		'Europe/Andorra',
		'Europe/Athens',
		'Europe/Belgrade',
		'Europe/Berlin',
		'Europe/Bratislava',
		'Europe/Brussels',
		'Europe/Bucharest',
		'Europe/Budapest',
		'Europe/Chisinau',
		'Europe/Copenhagen',
		'Europe/Dublin',
		'Europe/Gibraltar',
		'Europe/Guernsey',
		'Europe/Helsinki',
		'Europe/Isle_of_Man',
		'Europe/Istanbul',
		'Europe/Jersey',
		'Europe/Kaliningrad',
		'Europe/Kiev',
		'Europe/Lisbon',
		'Europe/Ljubljana',
		'Europe/London',
		'Europe/Luxembourg',
		'Europe/Madrid',
		'Europe/Malta',
		'Europe/Mariehamn',
		'Europe/Minsk',
		'Europe/Monaco',
		'Europe/Moscow',
		'Europe/Oslo',
		'Europe/Paris',
		'Europe/Podgorica',
		'Europe/Prague',
		'Europe/Riga',
		'Europe/Rome',
		'Europe/Samara',
		'Europe/San_Marino',
		'Europe/Sarajevo',
		'Europe/Simferopol',
		'Europe/Skopje',
		'Europe/Sofia',
		'Europe/Stockholm',
		'Europe/Tallinn',
		'Europe/Tirane',
		'Europe/Uzhgorod',
		'Europe/Vaduz',
		'Europe/Vatican',
		'Europe/Vienna',
		'Europe/Vilnius',
		'Europe/Volgograd',
		'Europe/Warsaw',
		'Europe/Zagreb',
		'Europe/Zaporozhye',
		'Europe/Zurich',
		'Indian/Antananarivo',
		'Indian/Chagos',
		'Indian/Christmas',
		'Indian/Cocos',
		'Indian/Comoro',
		'Indian/Kerguelen',
		'Indian/Mahe',
		'Indian/Maldives',
		'Indian/Mauritius',
		'Indian/Mayotte',
		'Indian/Reunion',
		'Pacific/Apia',
		'Pacific/Auckland',
		'Pacific/Chatham',
		'Pacific/Easter',
		'Pacific/Efate',
		'Pacific/Enderbury',
		'Pacific/Fakaofo',
		'Pacific/Fiji',
		'Pacific/Funafuti',
		'Pacific/Galapagos',
		'Pacific/Gambier',
		'Pacific/Guadalcanal',
		'Pacific/Guam',
		'Pacific/Honolulu',
		'Pacific/Johnston',
		'Pacific/Kiritimati',
		'Pacific/Kosrae',
		'Pacific/Kwajalein',
		'Pacific/Majuro',
		'Pacific/Marquesas',
		'Pacific/Midway',
		'Pacific/Nauru',
		'Pacific/Niue',
		'Pacific/Norfolk',
		'Pacific/Noumea',
		'Pacific/Pago_Pago',
		'Pacific/Palau',
		'Pacific/Pitcairn',
		'Pacific/Ponape',
		'Pacific/Port_Moresby',
		'Pacific/Rarotonga',
		'Pacific/Saipan',
		'Pacific/Tahiti',
		'Pacific/Tarawa',
		'Pacific/Tongatapu',
		'Pacific/Truk',
		'Pacific/Wake',
		'Pacific/Wallis',
		'UTC');
  return $timezone;
}

function config_set_defaults() {
  global $sql;
  $i = 0;
  $def_options[$i]["item"] = "ockversion";
  $def_options[$i]["value"] = ock_version();
  $def_options[$i]["updatealways"] = true;
  $i++;
  $def_options[$i]["item"] = "kickstart_unknown";
  $def_options[$i]["value"] = "1";
  $i++;
  $def_options[$i]["item"] = "cacheenabled";
  $def_options[$i]["value"] = "1";
  $i++;
  $def_options[$i]["item"] = "cachetimeout";
  $def_options[$i]["value"] = "900";
  $i++;
  $def_options[$i]["item"] = "ldap_ipa";
  $def_options[$i]["value"] = "0";
  $i++;
  $def_options[$i]["item"] = "ldapenabled";
  $def_options[$i]["value"] = "0";
  $i++;
  $def_options[$i]["item"] = "nisenabled";
  $def_options[$i]["value"] = "0";
  $i++;
  $def_options[$i]["item"] = "mysqlenabled";
  $def_options[$i]["value"] = "1";
  $i++;
  $def_options[$i]["item"] = "pxe_warning_timeout";
  $def_options[$i]["value"] = "3600";
  $i++;
  $def_options[$i]["item"] = "hostfqdn";
  $def_options[$i]["value"] = "1";
  $i++;
  $def_options[$i]["item"] = "pxemenutitle";
  $def_options[$i]["value"] = "One Click Kick";
  $i++;
  $def_options[$i]["item"] = "webtimeout";
  $def_options[$i]["value"] = "900";
  $i++;
  $def_options[$i]["item"] = "default_timezone";
  $def_options[$i]["value"] = "Europe/Paris";
  $i++;
  $def_options[$i]["item"] = "bootpassword";
  $def_options[$i]["value"] = rand_string(8);
  $i++;
  $def_options[$i]["item"] = "uploaddir";
  $def_options[$i]["value"] = "uploads/";
  $i++;
  $def_options[$i]["item"] = "ksmasterkey";
  $def_options[$i]["value"] = rand_string(128);
  $i++;
  $def_options[$i]["item"] = "enrollment_hostname_prefix";
  $def_options[$i]["value"] = "ockclient";
  $i++;
  $def_options[$i]["item"] = "enrollment_hostname_auto_suffix";
  $def_options[$i]["value"] = "numbered";
  $i++;
  $def_options[$i]["item"] = "enrollment_hostname_domain";
  $def_options[$i]["value"] = "default.oneclickkick.int";
  $i++;
  $def_options[$i]["item"] = "enrollment_default_dhcp_group_id";
  $def_options[$i]["value"] = "1";
  $i++;
  $def_options[$i]["item"] = "dhcpd_syslog_file";
  $def_options[$i]["value"] = "/var/log/messages";
  $i++;

  for ($i=0; $i < count($def_options); $i++) {
    unset ($updateq);
    $item = $def_options[$i]["item"];
    $value = $def_options[$i]["value"];
    $query = "select id, value from config where item=\"" . $def_options[$i]["item"] . "\" ";
    $result = mysql_query("$query", $sql);
    if (mysql_num_rows($result) == 0) {
      $updateq = "insert into config (item, value) values (\"" . $def_options[$i]["item"] . "\", \"" . $def_options[$i]["value"] . "\")";
    }
    elseif ($def_options[$i]["updatealways"] == true) {
      $r = mysql_fetch_array($result);
      if ($r["value"] != $def_options[$i]["value"]) {
        $updateq = "update config set value=\"" . $def_options[$i]["value"] . "\" where item=\"" . $def_options[$i]["item"] . "\"";
      }
    }
    if (isset($updateq)) {
       if (mysql_query($updateq, $sql)) {
	writelog("error","Updated config: " . $def_options[$i]["item"] . ": " . $def_options[$i]["value"],"0","");
      }
      else {
	writelog("error","Item: " . $def_options[$i]["item"],"19","");
      }
    }
  }
}

function os_info($id) {
  global $sql;
  $result = mysql_query("select id,name from os where id=$id", $sql);
  if (mysql_num_rows($result) > 0) {
    $ret = array();
    $i = 0;
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"] = $r["id"];
      $ret[$i]["name"] = $r["name"];
      $ret[$i]["filename"] = strtolower(str_replace(' ', '', $r["name"]));
      $i++;
    }
  }
  else {
    $ret = 255;
  }
  return $ret;
}


?>
