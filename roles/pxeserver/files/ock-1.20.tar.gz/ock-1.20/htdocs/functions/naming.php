<?php

function host_list_gotno_ieedevice_objectclass() {
  $ldap_filter = "(&(objectClass=nshost)(!(objectClass=ieee802Device)))";

}

function host_details_byname($host,$force_cache_update=0,$extended_details=0) {
  global $sql, $nisenabled, $ldapenabled, $mysqlenabled, $hostfqdn, $ldap_conn;

  $host = strtolower($host);

  $cache = new cache();

  $cache_ip = false;
  if (!$force_cache_update == 1) $cache_ip = $cache->lookup("host4","$host");

  if ($cache_ip) {
    $ip = $cache_ip[0]["cval"];
  }
  else {
    if ($_SESSION["CFG"]["nisenabled"]) {
      $ip = gethostbyname("$host");
    }
    else {
      $ip = dns_get_record("$host", DNS_A);
      $ip = $ip[0]["ip"];
    }
    // Disable due to long delays for non-ipv6 enabled hosts
    //$ip6 = dns_get_record("$host", DNS_AAAA);

    if (isset($ip)) $cache->update("host4","$host","$ip","system");
    if (isset($ip6[0]) && $ip6[0]["ipv6"] != "") $cache->update("host6","$host",$ip6[0]["ipv6"],"system");
  }

  $cache_ip_rev = false;
  if (!$force_cache_update == 1) $cache_ip_rev = $cache->lookup("host4rev","$ip");
  if ($cache_ip_rev) {
    $iprev = $cache_ip_rev[0]["cval"];
  }
  else {
    $iprev = false;
    if (isset($ip)) {
      if ($_SESSION["CFG"]["nisenabled"]) {
        $iprev = gethostbyaddr("$ip");
      }
      else {
        $iprev = dns_get_record(implode('.',array_reverse(explode('.',$ip))).'.in-addr.arpa.',DNS_PTR);
        $iprev = $iprev[0]["target"];
      }
    }
    $cache->update("host4rev","$ip","$iprev","system");
  }

  $i = 0;
  $ret = array();

  // FIND ETHER
  $cache_ether = false;
  if (!$force_cache_update == 1) $cache_ether = $cache->lookup("ether","$host");

  if ($cache_ether) {
    $ret["ether"] = $cache_ether[0]["cval"];
    $ret["type"] = $cache_ether[0]["csource"];
  }
  else {
    // LDAP
    if ($_SESSION["CFG"]["ldapenabled"] == "1" && is_callable("ldap_search")) {
      $ldap_filter = "(&(objectClass=nsHost)(cn=$host))";
      $ldap_attrs = array("cn","macaddress","krbLastPwdChange","nsHardwarePlatform","nsOsVersion","description","nsHostLocation");

      $ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);
      $rows = ldap_get_entries($ldap_conn, $ldap_result);
      if (isset($rows[0]["macaddress"][0])) $ret["ether"] = strtolower($rows[0]["macaddress"][0]);
      if (isset($rows[0])) $ret["type"] = "ldap";
      if (isset($ret["ether"])) $cache->update("ether","$host",$ret["ether"],$ret["type"]);
    }

    // NIS
    if ($nisenabled == 1 && is_callable("yp_cat")) {
      global $nisdomain;
      if ($_SESSION["CFG"]["hostfqdn"] == 1) {
        $yp_ether = yp_match("$nisdomain", "ethers.byname", "$host");
      }
      else {
        // Split hostname and domain
        $hostshort = explode(".", $host);
        $yp_ether = yp_match("$nisdomain", "ethers.byname", "$hostshort");
      }
      preg_match('/(\S+)/', $yp_ether, $ether);
      if (isset($ether[0])) $ret["ether"] = strtolower($ether[0]);
      if (isset($ether[0])) $ret["type"] = "nis";

      if (isset($ret["ether"])) $cache->update("ether","$host",$ret["ether"],$ret["type"]);
    }
    // Collect host, ip, and ethernet address and return to requester...
    // MYSQL
    if ($mysqlenabled == 1) {
      if ($hostfqdn != 1) {
        $q = "select ether from ethers where host LIKE \"$host\" or host LIKE \"$host.%\"";
      }
      else {
        $q = "select ether from ethers where host=\"$host\"";
      }
      $result = mysql_query("$q", $sql);
      if (mysql_num_rows($result) > 0) {
        while ($r = mysql_fetch_array($result)) {
          $ret["ether"] = strtolower($r["ether"]);
        }
        $ret["type"] = "mysql";
      }
    }
  }

  if ($ret["type"] == "ldap" && $_SESSION["CFG"]["ldap_ipa"] == "1" && $extended_details == 1) {
      //$ldap_filter = "(&(objectClass=ieee802Device)(cn=$host))";
      $ldap_filter = "(&(objectClass=nsHost)(cn=$host))";
      $ldap_attrs = array("krbLastPwdChange","nsHardwarePlatform","nsOsVersion","description","nsHostLocation", "l");

      $ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);
      $rows = ldap_get_entries($ldap_conn, $ldap_result);
      for ($i=0; $i < count($rows[0]); $i++) {
        $item = $rows[0][$i];
        $value = $rows[0][$item][0];
        $ret["extended"][$item] = $value;
      }

      //echo "<pre>"; print_r($ret); echo "</pre>";
  }

  // Split hostname and domain
  $hostshort = explode(".", $host);

  // Return what we found:
  $ret["hostshort"] = $hostshort[0];
  $ret["host"] = $host;
  $ret["ip"] = $ip;
  $ret["iprev"] = $iprev;
  return $ret;
}

function host_name_byether($ether,$force_cache_update=0) {
  global $sql, $nisenabled, $ldapenabled, $mysqlenabled, $hostfqdn, $ldap_conn;

  $ether = strtolower($ether);

  $ret = false;

  $cache = new cache();

  // FIND ETHER
  $cache_ether = false;
  if (!$force_cache_update == 1) $cache_ether = $cache->lookup("ether",NULL,"$ether");

  if ($cache_ether) {
    $ret["host"] = $cache_ether[0]["ckey"];
    $ret["type"] = $cache_ether[0]["csource"];
  }
  else {
    // LDAP
    if ($_SESSION["CFG"]["ldapenabled"] == "1" && is_callable("ldap_search")) {
      $ldap_filter = "(&(objectClass=nsHost)(macAddress=$ether))";
      $ldap_attrs = array("fqdn","macaddress","krbLastPwdChange","nsHardwarePlatform","nsOsVersion","description","nsHostLocation");

      $ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);
      $rows = ldap_get_entries($ldap_conn, $ldap_result);
      if (isset($rows[0]["fqdn"][0])) $ret["host"] = $rows[0]["fqdn"][0];
      if (isset($rows[0])) $ret["type"] = "ldap";
	//      if (isset($ret["fqdn"])) $cache->update("ether","$host",$ret["ether"],$ret["type"]);
    }

    // NIS
    if ($nisenabled == 1 && is_callable("yp_cat")) {
      global $nisdomain;
      $yp_ether = yp_match("$nisdomain", "ethers.byaddr", "$ether");
      preg_match('/^[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}.*?([\w\.]+)$/', $yp_ether, $host);
      if (isset($host[1])) $ret["host"] = $host[1];
      if (isset($host[1])) $ret["type"] = "nis";
	//      if (isset($ret["ether"])) $cache->update("ether","$host",$ret["ether"],$ret["type"]);
    }

    // MYSQL
    // Collect host, ip, and ethernet address and return to requester...
    if ($mysqlenabled == 1) {
      $q = "select host from ethers where ether=\"$ether\"";
      $result = mysql_query("$q", $sql);
      if (mysql_num_rows($result) > 0) {
        while ($r = mysql_fetch_array($result)) {
          $ret["host"] = $r["host"];
        }
        $ret["type"] = "mysql";
      }
    }
  }
  return $ret;
}

function hosts_list() {
  global $sql,$nisenabled, $ldapenabled, $mysqlenabled, $hostfqdn, $ldap_conn;
  $ret = array();
  $i = 0;

  // LDAP
  if ($_SESSION["CFG"]["ldapenabled"] == "1" && is_callable("ldap_search")) {
    //$ldap_filter = "objectClass=ieee802Device";
    $ldap_filter = "objectClass=nsHost";
    $ldap_attrs = array("cn");

    $ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);
    $rows = ldap_get_entries($ldap_conn, $ldap_result);
    //print_r($rows);

    for ($j = 0; $j < $rows["count"] ; $j++) {
      $ret[$i] = $rows[$j]["cn"][0];
      //echo "Host: " . $rows[$j]["cn"][0] . " Ether: " . $rows[$j]["macaddress"][0] . "<br>";
      $i++;
    }
  }

  // NIS
  if ($nisenabled && is_callable("yp_cat")) {
    global $nisdomain;
    # Get the hostnames from ethers.byname
    $hosts = yp_cat("$nisdomain", "ethers.byname");
    while (list($host, $rip) = each ($hosts)) {
      /*
      for ($i=0; $i < count($ret); $i++) {
	echo "host: $host - ret: " . $ret[$i] . "<br>";
        if($ret[$i] == $host) continue; 
      }
      */
      $ret[$i]=$host;
      $i++;
    } 
  }

  // MYSQL
  if ($mysqlenabled == 1) {
    $q = "select host from ethers"; 
    $result = mysql_query("$q", $sql);
    if (mysql_num_rows($result) > 0) {
      $i++;
      while ($r = mysql_fetch_array($result)) {
        $ret[$i] = $r["host"];
        $i++;
      }
    }
  }
  # Return an array containing all the hosts
  return $ret;
}

# Function to retreive current group of host

function host_group($host) {
  global $sql;
  $query = "select dhcpgroup.id, dhcpgroup.groupname, dhcpgroup.pxeprofileid, dhcpgroupmem.id as dhcpgroupmemid, dhcpgroupmem.statichost as statichost, dhcpgroupmem.descr as descr from dhcpgroup,dhcpgroupmem where dhcpgroup.id=dhcpgroupmem.dhcpgroupid and dhcpgroupmem.hostname=\"$host\"";
  $result = mysql_query("$query", $sql);

  if (mysql_num_rows($result) > 0) {
    $ret = array();
    while ($r = mysql_fetch_array($result)) {
      $ret["id"]=$r["id"];
      $ret["name"]=$r["groupname"];
      $ret["dhcpgroupmemid"]=$r["dhcpgroupmemid"];
      $ret["pxeprofileid"]=$r["pxeprofileid"];
      $ret["statichost"]=$r["statichost"];
      $ret["descr"]=$r["descr"];
    }
  }
  else {
	$ret = "";
  }
  return $ret;
}

function host_group_update($host,$newgroup,$delayed_dhcpd_regen=0,$ipa_otp=0) {
	global $sql;
	$bg = new ockd_client();
	$ret = 0;
	$hostgroup = host_group("$host");
        if ($newgroup == 0) {
		$result = mysql_query("delete from dhcpgroupmem where hostname=\"$host\"", $sql);
		if (mysql_affected_rows() == 0) {
			$ret = mysql_error($sql);
		}
        }
	elseif ($hostgroup["id"]) {
		$result = mysql_query("update dhcpgroupmem set dhcpgroupid=$newgroup,ipa_otp=\"$ipa_otp\" where hostname=\"$host\"", $sql);
		if (mysql_affected_rows() == 0) {
			$ret = mysql_error($sql);
		}
	}
	else {
		$result = mysql_query("insert into dhcpgroupmem (hostname,dhcpgroupid,ipa_otp) values (\"$host\", $newgroup, \"$ipa_otp\")", $sql);
		if (mysql_affected_rows() == 0) {
			$ret = mysql_error($sql);
		}
	}
	if ($ret == 0 && $delayed_dhcpd_regen == 0) {
	  $bg->run(generate_dhcpd_conf); 
	}
        $hostgroup = host_group("$host");
	writelog("hostconfig","Host group membership was modified to ".$hostgroup["name"],$hostgroup["dhcpgroupmemid"],"");
  return $ret;
}

function host_details_update($host) {
  global $sql;
  $ret = 0;
  $hostgroup = host_group("$host");
  if (isset($hostgroup["id"])) {
    if ($_POST["statichost"] == "on") $statichost = "1";
    if (!isset($_POST["statichost"])) $statichost = "0";
    $q = "update dhcpgroupmem set statichost=\"" . $statichost . "\", descr=\"" . $_POST["descr"] . "\" where hostname=\"$host\"";
    $result = mysql_query("$q", $sql);
    if (mysql_affected_rows() == 0) {
      $ret = mysql_error($sql);
    }
    writelog("hostconfig","Host static IP set to: $statichost",$hostgroup["dhcpgroupmemid"],"");
  }
  else {
    $ret = "Not in a host group";
  }
  return $ret;
}

function host_ether_update($host,$ether) {
  global $sql;
  $host_details = host_details_byname($host,1,1);
  //echo "<pre>"; print_r($host_details); echo "</pre>";
  if ($host_details["type"] == "ldap") {
    global $ldap_conn;
    //$ldap_filter = "(&(objectClass=nshost)(!(objectClass=ieee802Device)))";
    //$ldap_attrs = array("cn","macaddress","krbLastPwdChange","nsHardwarePlatform","nsOsVersion","description","nsHostLocation");

    $ldap_filter = "(&(objectClass=nsHost)(cn=$host))";
    $ldap_attrs = array("objectClass");

    $ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);
    if (!isset($ldap_result)) return ldap_error($ldap_conn);
    //$ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter);
    $ldap_r = ldap_get_entries($ldap_conn, $ldap_result) or $ret = ldap_error($ldap_conn);
    //echo "<pre>"; print_r($ldap_r); echo "</pre>";

    $dn = $ldap_r[0]["dn"];

    if (!array_search('ieee802Device', $ldap_r[0]["objectclass"])) {
      unset($entry);
      $entry["objectclass"][0] = "ieee802Device"; // add an auxiliary objectclass
      if (!ldap_mod_add ($ldap_conn, $dn, $entry)) {
        $ret = print ldap_error($ldap_conn);
      }
    }

    //ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);
 
    unset($entry);
    $entry["macAddress"][0] = $ether;

    if (isset($dn) && (!isset($ret))) {
      if (ldap_modify ($ldap_conn, $dn, $entry)) {
        $ret = 0;
      }
      else {
        $ret = ldap_error($ldap_conn);
      }
    }
    else {
      $ret = "DN not set";
    }
  }
  elseif ($host_details["type"] == "mysql") {
    $q = "update ethers set ether=\"$ether\" where host LIKE \"$host%\"";
    $result = mysql_query("$q", $sql);
    if (mysql_affected_rows() == 0) {
      $ret = mysql_error($sql);
    }
    else {
      $ret = 0;
    }
  }
      //print ldap_error($ldap_conn);
  return $ret;
}

function host_delete_sql($host) {
  global $sql;
  $host_group = host_group("$host");
  pxe_disable_client($host_group["dhcpgroupmemid"]);
  $q = "delete from ethers where host LIKE \"$host%\"";
  $result = mysql_query("$q", $sql);
  if (mysql_affected_rows() == 0) {
    $ret = mysql_error($sql);
  }
  else {
    $ret = 0;
    writelog("error","Host $host% removed from local MySQL database","","");
  }
  return $q;
}

function host_add($host,$ether,$dhcpgroupid,$db) {
  global $sql;
  if (isset($host) && isset($ether)) {
    $hostdetails = host_details_byname($host);

    if (preg_match("/^[\w\.\-]+$/", $host) === 0) {
      $ret = "Invalid host name. $host";
    }
    elseif (!preg_match("/^[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}$/", $ether)) {
      $ret = "Invalid MAC address. $ether";
    }
    elseif (isset($hostdetails["ether"])) {
      $ret = "Host already exists. $host";
    }
    else {
      if ($db == "sql") {
        $q = "insert into ethers (host,ether) values (\"$host\",\"$ether\")";
        $result = mysql_query("$q", $sql);
        if (mysql_affected_rows() == 0) {
          $ret = mysql_error($sql);
        }
        else {
          $id = mysql_insert_id();
          writelog("info","Host $host with MAC address $ether added to local MySQL database","","");
          $ret = 0;
        }
        if ($dhcpgroupid > 0) {
          host_group_update($host,$dhcpgroupid);
        }
      }
      elseif ($db == "ipa") {
        if (isset($_POST["ether"])) {
	  $_SESSION["IPACMD"]["POST"] = $_POST;
        }
        if (isset($_SESSION["IPACMD"]["redir"])) {
          header("Location: " . $_SERVER["PHP_SELF"] . "/../ipacmd.php"); 
        }
      }
    }
  }
  else {
    $ret = "Please add all required details";
  }
  return $ret;
}

function host_add_bulk($pxebootnow) {
  if (is_file($_FILES["hostfile"]["tmp_name"])) {
    $ret = array();
    $file_contents = file($_FILES["hostfile"]["tmp_name"]);
    $i = 0;
    foreach ($file_contents as $key => $value) {
      preg_match("/^([a-zA-Z0-9.]+);([a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2})$/", $value, $match);
      if ($match[1] == "" || $match[2] == "" ) {
	$ret[$i]["host"] = "$value";
	$ret[$i]["status"] = "FAILED";
	$i++;
	continue;
      }
      $host = $match[1];
      $ether = $match[2];
//echo "k: $host - v: $ether <br>";
      $dhcpgroupid = $_POST["dhcpgroupid"];

      unset($ipastatus, $sqlstatus, $ldapstatus, $host_exists);

      $host_exists = host_details_byname($host);
//echo "<pre>"; print_r($host_exists); echo "db: " . $_POST["database"] . "<br>"; echo "</pre>";


      // Add ethers to LDAP if found in LDAP
      if ($host_exists["type"] == "ldap") {
//echo "FOUND LDAP: $host";
        $ldapstatus = host_ether_update($host,$ether);
        $ldap_group_status = host_group_update($host,$dhcpgroupid,1);
      }

      // Add host if not found in existing naming services:
      elseif (!isset($host_exists["type"])) {
	if ($_POST["database"] == "ipa") {
	  $_SESSION["IPACMD"]["redir"] = "?p=hosts&a=addhostbulkf";
	  $ipastatus  = host_add($host,$ether,$dhcpgroupid,"ipa");
	}
	elseif ($_POST["database"] == "mysql") {
  	  $sqlstatus  = host_add($host,$ether,$dhcpgroupid,"sql");
	}
      }

//echo "<pre>host_exist: " . print_r($host_exists) .  "<br>ipastatus:" . print_r($ipastatus) . "</pre>";

      if (($sqlstatus == 0 || $ipastatus == 0) && $_POST["pxeenablenow"] == "on") {
        $host_group = host_group($host);
	$pxeprofile = pxe_profile($dhcpgroupid);
	$pxestatus = pxe_enable_client($host_group["dhcpgroupmemid"],$pxeprofile["id"]);
      }
      if ($sqlstatus == 0) $sqlstatus = "SQL: OK, DHCPGROUP: OK ";
      if ($ipastatus == 0) $ipastatus = "IPA: OK, DHCPGROUP: OK ";
      if ($ldapstatus == 0) $ldapstatus = "LDAP: OK ";
      if ($ldap_group_status == 0) $ldap_group_status = "DHCPGROUP: OK ";
      if ($pxestatus == 0) $pxestatus = "PXE: OK ";
      $ret[$i]["host"] = $host;
      $ret[$i]["status"] = "$ipastatus $sqlstatus $ldapstatus $ldap_group_status $pxestatus";
      $i++;
    }
  } 

  return $ret;
}

function host_get_next_default_hostname($system_serial_number=0) {
  global $sql;

  $q = "select item,value from config where 
        item=\"enrollment_hostname_prefix\" 
        or item=\"enrollment_hostname_auto_suffix\"
        or item=\"enrollment_hostname_domain\"
        or item=\"enrollment_default_dhcp_group_id\"";
  $result = mysql_query("$q", $sql);
  if (mysql_num_rows($result) > 0) {
    while ($r = mysql_fetch_array($result)) {
      if ($r["item"] == "enrollment_hostname_prefix") $enrollment_hostname_prefix = $r["value"];
      if ($r["item"] == "enrollment_hostname_auto_suffix") $enrollment_hostname_auto_suffix = $r["value"];
      if ($r["item"] == "enrollment_hostname_domain") $enrollment_hostname_domain = $r["value"];
      if ($r["item"] == "enrollment_default_dhcp_group_id") $enrollment_default_dhcp_group_id = $r["value"];

    }
  }

  if ($enrollment_hostname_auto_suffix == "numbered") {
    $allhosts = hosts_list();
    sort ($allhosts);
    for ($i=0; $i < count($allhosts); $i++) {
      $split = preg_split('/\./', $allhosts[$i]);
      if (substr($split[0],0 , strlen($enrollment_hostname_prefix)) == "$enrollment_hostname_prefix") {
      // Return only the host component of FQDN:
        $match_hosts[] = $split[0];
      }
    }
    sort($match_hosts);
    $last = count($match_hosts);
    $last--;
    $last_host =  $match_hosts[$last];

    $nextnum = substr($last_host, strlen($enrollment_hostname_prefix));
    $num_len = strlen($nextnum);
    $nextnum = sprintf("%0" . $num_len . "d", $nextnum+1);
    $next_hostname = $enrollment_hostname_prefix . $nextnum . "." . $enrollment_hostname_domain;

  }
  elseif ($enrollment_hostname_auto_suffix == "system-serial-number") {
    $next_hostname = "$enrollment_hostname_prefix$system_serial_number.$enrollment_hostname_domain";
  }
  else {
    $next_hostname = "$enrollment_hostname_prefix.$enrollment_hostname_domain";
  }
  return $next_hostname;
}

function host_parse_syslog() {
  global $sql;
  if (is_readable($_SESSION["CFG"]["dhcpd_syslog_file"])) {
    $mess = file($_SESSION["CFG"]["dhcpd_syslog_file"]);
//  $mess = file("/var/log/messages");
    $j = 0;
    for ($i=0; $i < count($mess) ; $i++) {
      unset ($match);
      //echo "Line $i: " . $mess[$i] . "<br>";

      //preg_match('/^.+dhcpd:\ DHCPACK\ on\ ([0-9]{3}\.[0-9]{3}\.[0-9]{3}\.[0-9]{3})\ to\ ([a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2})\ via.+$/', $mess[$i], $match);
      //preg_match('/^([\w]+.\d+\ \d+\:\d+\:\d+).+dhcpd:\ DHCPACK\ on\ ([0-9]{1,3}\.[0-9]{3}\.[0-9]{1,3}\.[0-9]{1,3})\ to\ ([a-fA-F0-9]{1,2}\:[a-fA-F0-9]{1,2}\:[a-fA-F0-9]{1,2}\:[a-fA-F0-9]{1,2}\:[a-fA-F0-9]{1,2}\:[a-fA-F0-9]{1,2})\ via\ ([\w\d]+)$/', $mess[$i], $match);
      preg_match('/^([\w]+\W+?\d+\ \d+\:\d+\:\d+).+dhcpd:\ DHCPACK\ on\ ([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})\ to\ ([a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2})\ via\ ([\w\d\.]+).?$/', $mess[$i], $match);

      if (isset($match[3])) {
	$ether = $match[3];
        $lookup = host_name_byether($ether,1);
        if (isset($lookup["host"])) continue;
        $ret[$ether]["ip"] = $match[2];
        $ret[$ether]["noip"] = "0";
        $ret[$ether]["date"] = $match[1];
        $ret[$ether]["from"] = $match[4];
      }
      preg_match('/^([\w]+.\d+\ \d+\:\d+\:\d+).+dhcpd:\ DHCPDISCOVER\ from\ ([a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2})\ via\ ([\w\d\.]+).+no\ free\ leases$/', $mess[$i], $match);
      if (isset($match[2])) {
	$ether = $match[2];
        $lookup = host_name_byether($ether,1);
        if (isset($lookup["host"])) continue;
        $ret[$ether]["ip"] = "no-free-leases";
        $ret[$ether]["noip"] = "1";
        $ret[$ether]["date"] = $match[1];
        $ret[$ether]["from"] = $match[3];
      }
 
    }
  $sorted = array_unique($hosts["ether"]);
  echo "<pre>"; print_r($hosts); print_r($sorted); echo "</pre>";
  }
  else {
    $ret = "Could not open file";
  }
  return $ret;
}

?>
