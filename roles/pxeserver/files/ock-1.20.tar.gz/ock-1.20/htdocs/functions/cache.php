<?php

class cache {

  // Push update to cache
  function update($ctype,$ckey,$cval,$csource) {
    global $sql;
    if (isset($ctype,$ckey,$cval) && $ckey != "") {
      //if ($this->lookup("$ctype","$ckey","$cval")) {
      if ($this->lookup("$ctype","$ckey")) {
        $query = "update cache set cval=\"$cval\", csource=\"$csource\", timestamp=NOW() where ctype=\"$ctype\" and ckey=\"$ckey\"";
      }
      else {
        $query = "insert into cache (ctype,ckey,cval,csource) values (\"$ctype\", \"$ckey\", \"$cval\",\"$csource\") ";
      }
      if (isset($query)) mysql_query("$query", $sql);
    }
  }

  function purge($ctype=NULL) {
    global $sql;
    // Find expired entries in cache
    $query = "delete from cache where (timestamp < NOW() - "  . $_SESSION["CFG"]["cachetimeout"] . ")";

    $result = mysql_query("$query", $sql);

  }


  /* 
   * Look up in the cache
   *
   * Ex: lookup("ether",NULL,"00:00:00:00:00")
   */
  public function lookup($ctype, $ckey = NULL, $cval = NULL) {
    
    // First purge old entries
    $this->purge();

    // Now do lookup
    global $sql;
    $query = "select ctype,ckey,cval,csource,timestamp,plock from cache";
    if (isset($ctype) || isset($ckey)) {
      $query .= " where (timestamp > NOW() - " . $_SESSION["CFG"]["cachetimeout"] . ")";
    }
    if (isset($ctype)) {
      $query .= " and ctype=\"$ctype\"";
    }
    if (!is_null($ckey)) {
      $query .= " and ckey=\"$ckey\"";
    }
    if (!is_null($cval)) {
      $query .= " and cval=\"$cval\"";
    }
    $result = mysql_query("$query", $sql);
    $return = array();

    if (isset($result)) {
      while ($r = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $return[] = $r;
      }
    }

    // Return false if nothing is found
    if (mysql_num_rows($result) == 0) $return = false;

    return $return;
  }

}


?>
