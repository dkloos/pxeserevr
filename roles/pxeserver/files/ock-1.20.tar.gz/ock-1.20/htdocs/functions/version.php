<?php

// Return the current oneclickkick version
function ock_version() {
  $version = "1.20";
  return $version;
}

?>
