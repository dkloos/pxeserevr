<?php

function users_ldapstring_list ($ldapstringid=false) {
  global $sql;
  $ret = array();
  $i = 0;
 
  if (isset($_SESSION["CFG"]["ldapenabled"]) && $_SESSION["CFG"]["ldapenabled"] == "1" && is_callable("ldap_search") ) {
    $q = "select id,ldapstring,uid_attr,name_attr from users_ldap";
    if ($ldapstringid > 1) $q .= " where id=$ldapstringid";
    $q .= " order by id";
    $result = mysql_query("$q", $sql);
    if ($result) {
      while ($r = mysql_fetch_array($result)) {
        $ret[$i]["ldapstringid"]=$r["id"];
        $ret[$i]["ldapstring"]=$r["ldapstring"];
        $ret[$i]["uid_attr"]=$r["uid_attr"];
        $ret[$i]["name_attr"]=$r["name_attr"];
        $i++;
      }
    }
    return $ret;
  }
  else {
     return false;
  }
}

function users_ldap_list ($ldapstringid=false) {
  if (isset($_SESSION["CFG"]["ldapenabled"]) && $_SESSION["CFG"]["ldapenabled"] == "1" && is_callable("ldap_search") ) {
    global $ldap_conn;
    $j = 0;
    if ($ldapstringid == false) {
      $arr_strings = users_ldapstring_list();
    }
    else {
      $arr_strings = users_ldapstring_list($ldapstringid);
    }
    for ($i=0; $i < count($arr_strings); $i++) {
      
      $ldap_filter = $arr_strings[$i]["ldapstring"];
      $ldap_attrs = array($arr_strings[$i]["uid_attr"], $arr_strings[$i]["name_attr"]);

      $ldap_result = ldap_search($ldap_conn, $_SESSION["CFG"]["ldap_base"], $ldap_filter, $ldap_attrs);

      $rows = ldap_get_entries($ldap_conn, $ldap_result);
//echo "<pre>";      print_r($rows);	echo "</pre>";
      for ($k=0; $k < count($rows); $k++) {

        if (isset($rows[$k][$arr_strings[$i]["uid_attr"]][0])) {
 
          $ret[$j]["username"] = $rows[$k][$arr_strings[$i]["uid_attr"]][0];
          $ret[$j]["name"] = $rows[$k][$arr_strings[$i]["name_attr"]][0];
          $j++;
        }

      }

    }
    return $ret;
  }
  else {
    return false;
  }
}

function users_list() {
  global $sql;
  $ret = array();
  $i = 0;
  $q = "select id,username,name from users order by username";
  $result = mysql_query("$q", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"]=$r["id"];
      $ret[$i]["username"]=$r["username"];
      $ret[$i]["name"]=$r["name"];
      $i++;
    }
  }

 return $ret;
}

function user_info($id) {
  global $sql;
  $result = mysql_query("select username,name from users where id=$id", $sql);
  if ($result) {
    $ret = array();
    while ($r = mysql_fetch_array($result)) {
      $ret["username"] = $r["username"];
      $ret["name"] = $r["name"];
    }
  }
  return $ret;
}
 

function user_add($post) {
  global $sql;
  $ret = 0;
  if (($post["username"] != "") && ($post[password] != "")) {
    $query = "insert into users (username,name,password) values (\"".$post["username"]."\",\"".$post["name"]."\",aes_encrypt(\"".$post["password"].".\",'pwstring'))";
    $result = mysql_query("$query", $sql);
    if ($result) {
      $ret = 0;
       $id = mysql_insert_id();
       writelog("security","User account added","$id","");
    }
    else {
      $ret = 1;
    }
  }
  return $ret;
}

function user_delete($id) {
  global $sql;
  if ($id == "1") return 12;
  $userinfo = user_info($id);
  $result = mysql_query("delete from users where id=$id", $sql);
  if ($result) {
    $ret = 0;
     writelog("security","User account ".$userinfo["name"]." deleted","$id","");
  }
  else {
    $ret = 1;
  }
  return $ret;
}

function user_modify($id,$post) {
  global $sql;
  $q = "update users set username=\"".$post["username"]."\", name=\"".$post["name"]."\"";
  if ($post[password] != "nochange") {
    writelog("security","User account password changed","$id","");
    $q .= ", password=aes_encrypt(\"$post[password]\",'pwstring')";
  }
  $q .= " where id=$id";
  $result = mysql_query("$q", $sql);
  if ($result) {
    $ret = 0;
    writelog("security","User account modified","$id","");
  }
  else {
    $ret = 1;
  }
  return $ret;
}

?>
