<?php

function auth_user($username,$password=NULL) {
  global $sql, $SESSKEY;
  //if (is_null($password) && (isset($_SERVER["AUTH_TYPE"]) && $_SERVER["AUTH_TYPE"] == "Negotiate")) {
  if (is_null($password) && (isset($_SESSION["SSO"]["AUTH_TYPE"]) && $_SESSION["SSO"]["AUTH_TYPE"] == "Negotiate")) {
    $q = "select id,username from users where username=\"$username\"";
  }
  else {
    $q = "select id,username,aes_decrypt(password,'pwstring') as password from users where username=\"$username\" and password=aes_encrypt(\"$password\",'pwstring')";
  }
  $result = mysql_query("$q", $sql);
  $r = mysql_fetch_array($result);
  if (isset($r["username"]) && (isset($r["password"]) ||  $_SESSION["SSO"]["AUTH_TYPE"] == "Negotiate")) {
    $ret = 0;
    $_SESSION['USERNAME'] = $username;
    $_SESSION['USERID'] = $r["id"];
    $_SESSION['SESSKEY'] = $SESSKEY;
    $_SESSION['SESSTIME'] = mktime();
    // Write log after session data is commited so username is picked up in the log
    writelog("security","User logged in",$r["id"],"");
    run_onlogin_funcs();
  }
  else {
    $ret = 1;
    writelog("security","User $username failed login",0,"");
  }
  return $ret;
}

function run_onlogin_funcs() {
  if (! $_SERVER["SCRIPT_URL"] == "/ock/enroll.php") {
    // Remove dead boot files from disk:
    pxe_check_dead_bootfiles();
  }
}


?>
