<?php
function dhcp_subnets() {
  global $sql;
  $ret = array();
  $i = 0;
  $ret[$i]["id"]=0;
  $ret[$i]["subnet"]="Global settings";
  $ret[$i]["netmask"]="DHCP Global config";
  $ret[$i]["descr"]="Global settings";
  $i++;
  $result = mysql_query("select * from dhcpsubnet order by subnet,netmask", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"]=$r["id"];
      $ret[$i]["subnet"]=$r["subnet"];
      $ret[$i]["netmask"]=$r["netmask"];
      $ret[$i]["descr"]=$r["descr"];
      $ret[$i]["statichosts"]=$r["statichosts"];
      $ret[$i]["autoip_offset"]=$r["autoip_offset"];
      preg_match('/(\d{1,3}\.\d{1,3}\.\d{1,3})\.\d{1,3}/',  $r["subnet"], $subnet);
      $ret[$i]["3octets"] = $subnet[1];
      $i++;
    }
  }
  return $ret;
}

function dhcp_subnetinfo($subnetid) {
  global $sql;
  $ret = array();
  $result = mysql_query("select * from dhcpsubnet where id=$subnetid", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $ret["id"]=$r["id"];
      $ret["subnet"]=$r["subnet"];
      $ret["netmask"]=$r["netmask"];
      $ret["descr"]=$r["descr"];
      $ret["statichosts"]=$r["statichosts"];
      $ret["autoip_offset"]=$r["autoip_offset"];
      preg_match('/(\d{1,3}\.\d{1,3}\.\d{1,3})\.\d{1,3}/', $ret["subnet"], $subnetmatch);
      $ret["3octets"] = $subnetmatch[1];
    }
  }
  return $ret;
}

function dhcp_subnetadd($post) {
  global $sql;
  $bg = new ockd_client();
  $ret = 0;
  $result = mysql_query("insert into dhcpsubnet (subnet,netmask,descr) values (\"".$post["subnet"]."\", \"".$post["netmask"]."\", \"".$post["descr"]."\") ", $sql);
  if (mysql_affected_rows() == 0) {
    $ret = mysql_error($sql);
  }
  else {
    $subnetid = mysql_insert_id();
    writelog("dhcpsconfig","Subnet added","$subnetid","");
    $dhcp_status = $bg->run(generate_dhcpd_conf);
    if ($dhcp_status == 0) { 
      $ret = 0;
    }
    else {
      $ret = $dhcp_status;
    }
  }
  return $ret;
}

function dhcp_subnetdel($id) {
  global $sql;
  $bg = new ockd_client();
  $sinfo = dhcp_subnetinfo($id);
  $ret = 0;
  $result = mysql_query("delete from dhcpconf where dhcpsubnetid=$id", $sql);
  if (mysql_affected_rows() == 0) {
    $ret = mysql_error($sql);
  }
  $result = mysql_query("delete from dhcpsubnet where id=$id", $sql);
  if (mysql_affected_rows() == 0) {
    $ret = mysql_error($sql);
  }
  else {
    writelog("dhcpsconfig","Subnet ".$sinfo["descr"]." (".$sinfo["subnet"]."/".$sinfo["netmask"].") deleted","$id","");
   // Regenerate DHCP config file and restart DHCP:
   $dhcp_status = $bg->run(generate_dhcpd_conf);
   if ($dhcp_status == 0) { 
      $ret = 0;
   }
   else {
     $ret = $dhcp_status;
    }
  }
  return $ret;
}


function dhcp_subnetconfig($subnetid) {
  global $sql;
  $ret = array();
  $result = mysql_query("select * from dhcpconf where dhcpsubnetid=$subnetid", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result, MYSQL_NUM)) {
      $key=$r[2];
      $ret[$key] = "$r[3]";
    }
  }
  return $ret;
}

function dhcp_subnetupdate($id,$post) {
  global $sql;
  $ret = 0;
  if ($post["subnet"]) {
    if ($post["statichosts"] == "on") $statichosts = "1";
    if ($post["statichosts"] != "on") $statichosts = "0";
    $result = mysql_query("update dhcpsubnet set 
	subnet=\"".$post["subnet"]."\", 
	netmask=\"".$post["netmask"]."\", 
	descr=\"".$post["descr"]."\", 
	statichosts=\"$statichosts\", 
	autoip_offset=\"".$post["autoip_offset"]."\" 
	where id=$id", $sql);
    if (mysql_affected_rows() > 0) {
     if ($dhcp_status == 0) {
        $ret = 0;
     }
     else {
       $ret = $dhcp_status;
      }
    }
    else {
      $ret = mysql_error($sql);
    }
  }
  foreach ($post as $key => $value) {
    if (($key != "subnet") && ($key != "netmask") && ($key != "descr" && $key != "statichosts" && $key != "autoip_offset")) {
      if ($key == "option_domain-name") {
        dhcp_set_optvalue($id,"ddns-domainname",$value);
      }
      $return = dhcp_set_optvalue($id,$key,$value);
//        if ($return != 0) $ret = 255;
    }
  }
  // Manually set options for certain checkbox options
  if ($post["ddns-updates"]) {
      $return = dhcp_set_optvalue($id,"ddns-updates","on");
      $return = dhcp_set_optvalue($id,"ddns-update-style","interim");
  }
  else {
      $return = dhcp_set_optvalue($id,"ddns-update-style","interim");
      $return = dhcp_set_optvalue($id,"ddns-updates","");
  }

  if ($post["authoritative;"]) {
      $return = dhcp_set_optvalue($id,"authoritative;","#on");
  }
  else {
      $return = dhcp_set_optvalue($id,"authoritative;","");
  }
  if ($post["get-lease-hostnames"]) {
      $return = dhcp_set_optvalue($id,"get-lease-hostnames","true");
  }
  else {
      $return = dhcp_set_optvalue($id,"get-lease-hostnames","");
  }
  if ($post["ping-check"]) {
      $return = dhcp_set_optvalue($id,"ping-check","true");
  }
  else {
      $return = dhcp_set_optvalue($id,"ping-check","");
  }
  if ($post["update-static-leases"]) {
      $return = dhcp_set_optvalue($id,"update-static-leases","true");
  }
  else {
      $return = dhcp_set_optvalue($id,"update-static-leases","");
  }
  if ($post["one-lease-per-client"]) {
      $return = dhcp_set_optvalue($id,"one-lease-per-client","true");
  }
  else {
      $return = dhcp_set_optvalue($id,"one-lease-per-client","false");
  }
  if ($post["allow_client-updates;"]) {
      $return = dhcp_set_optvalue($id,"allow client-updates;","#on");
  }
  else {
      $return = dhcp_set_optvalue($id,"allow client-updates;","");
  }
  if ($post["deny_duplicates;"]) {
      $return = dhcp_set_optvalue($id,"deny duplicates;","#on");
  }
  else {
      $return = dhcp_set_optvalue($id,"deny duplicates;","");
  }


 
if ($ret == 0) {
    $bg = new ockd_client();
    writelog("dhcpsconfig","Subnet modified",$id,"");
   // Regenerate DHCP config file and restart DHCP:
    $bg->run(generate_dhcpd_conf);
  }
  return $ret;
}

function dhcp_groups() {
  global $sql;
  $ret = array();
  $i = 0;
  $result = mysql_query("select id,groupname,descr,statichosts,hostfqdn from dhcpgroup order by groupname", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"]=$r["id"];
      $ret[$i]["groupname"]=$r["groupname"];
      $ret[$i]["descr"]=$r["descr"];
      $ret[$i]["statichosts"]=$r["statichosts"];
      $ret[$i]["hostfqdn"]=$r["hostfqdn"];
      $i++;
    }
  }
  return $ret;
}

function dhcp_groupconfig($groupid) {
  global $sql;
  $ret = array();
  $result = mysql_query("select * from dhcpgroupconf where dhcpgroupid=$groupid", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result, MYSQL_NUM)) {
      $key=$r[2];
      $ret[$key] = "$r[3]";
    }
  }
  return $ret;
}


function dhcp_groupconfig_get_optvalue($groupid,$item) {
  global $sql;
  $result = mysql_query("select value from dhcpgroupconf where dhcpgroupid=$groupid and item=\"$item\"", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $ret = $r["value"];
    }
  }
  if (isset($ret)) {
    return $ret;
  }
  else {
    return false;
  }
}

#This function will replace dhcp_gropconfig
function dhcp_groupconfig_avail_options() {
  $ret = array();
  $i = 0;
  $ret[$i]["item"] = "next-server";
  $ret[$i]["desc"] = "BOOTP server";
  $ret[$i]["type"] = "input";
  $ret[$i]["validate"] = "ipv4";
  $ret[$i]["required"] = "false";
  $i++;
  $ret[$i]["item"] = "filename";
  $ret[$i]["desc"] = "Boot filename";
  $ret[$i]["type"] = "input";
  $i++;
  $ret[$i]["item"] = "option domain-name-servers";
  $ret[$i]["desc"] = "DNS Servers";
  $ret[$i]["type"] = "input";
  $ret[$i]["validate"] = "ipv4multicomma";
  $ret[$i]["required"] = "true";
  $i++;
  $ret[$i]["item"] = "option netbios-name-servers";
  $ret[$i]["desc"] = "WINS Servers";
  $ret[$i]["type"] = "input";
  $ret[$i]["validate"] = "ipv4multicomma";
  $ret[$i]["required"] = "false";
  $i++;
  $ret[$i]["item"] = "option domain-name";
  $ret[$i]["desc"] = "Domain name";
  $ret[$i]["type"] = "input";
  $i++;
  return $ret;
}


# Function to get dhcp group info
function dhcp_groupinfo($groupid) {
  global $sql;
  $result = mysql_query("select * from dhcpgroup where id=$groupid", $sql);
  if ($result) {
    $ret = array();
    while ($r = mysql_fetch_array($result)) {
      $ret["name"] = $r["groupname"];
      $ret["descr"] = $r["descr"];
      $ret["statichosts"] = $r["statichosts"];
      $ret["hostfqdn"] = $r["hostfqdn"];
    }
  }
  else {
    $ret = 5;
  }
  $result2 = mysql_query("select count(id) as num_members from dhcpgroupmem where dhcpgroupid=$groupid", $sql);
  if ($result2) {
    $r2 = mysql_fetch_array($result2);
    $ret["num_members"] = $r2["num_members"];
  }
  else {
    $ret = 5;
  }
  return $ret;
}



# function to update dhcp group config
# will loop over entire $_POST and update config accordincly

function dhcp_groupconf_update($groupid,$post) {
  global $sql;
  $bg = new ockd_client();
  $ret = 0;
  // Force the dynamic dns domain name to be the same as the domain name for the group
  if (isset($post["option_domain-name"])) {
    $post["ddns-domainname"] = $post["option_domain-name"];
  }
  foreach ($post as $key => $value) {
    $key = str_replace("_", " ", "$key");
    $q = "select item from dhcpgroupconf where item=\"$key\" and dhcpgroupid=\"$groupid\"";
    $result = mysql_query("$q", $sql);
    if (mysql_num_rows($result) > 0) {
      if ($value == "") {
        $q = "delete from dhcpgroupconf where item=\"$key\" and dhcpgroupid=\"$groupid\"";
      }
      else {
        $q = "update dhcpgroupconf set value=\"$value\" where item=\"$key\" and dhcpgroupid=$groupid";
      }
      $result2 = mysql_query("$q", $sql);
      if (mysql_affected_rows() == 0) {
        $ret = 11;
      }
    }
    elseif ($value) {
      $q = "insert into dhcpgroupconf (dhcpgroupid,item,value) values ($groupid,\"$key\",\"$value\")";
      $result2 = mysql_query("$q", $sql);
      if (mysql_affected_rows() == 0) {
        $ret = 10;
      }
    }
  }
//  if ($ret == 0) {
    // Regenerate DHCP config file and restart DHCP:
    writelog("dhcpgconfig","DHCP group configuration modified",$groupid,"");
    $dhcp_status = $bg->run(generate_dhcpd_conf);
    if ($dhcp_status == 0) {
       $ret = 0;
    }
    else {
      $ret = $dhcp_status;
    }
//  }
  return $ret;
}

# function to create a new dhcp group
function dhcp_group_add($post) {
  global $sql, $tftpserver;
  $ret = 0;
  if ($post["groupname"] != "") {
    $query = "insert into dhcpgroup (groupname,descr,pxeprofileid) values (\"".$post["groupname"]."\",\"".$post["descr"]."\",\"".$post["pxeprofileid"]."\")";
    mysql_query("$query", $sql);
    $id = mysql_insert_id($sql);
    if ($id != "") {
      writelog("dhcpgconfig","DHCP Group added",$id,"");
      $result = mysql_query("insert into dhcpgroupconf (dhcpgroupid,item,value) select $id,dhcpgroupconf.item, dhcpgroupconf.value from dhcpgroupconf where dhcpgroupconf.dhcpgroupid=$post[templateid]", $sql);
      if ($result) {
        $result = mysql_query("update dhcpgroupconf set value=\"$tftpserver\" where dhcpgroupid=\"$id\" and item=\"next-server\"");
        if (!$result) {
          $ret = 255;
        }
      }
      else {
        $ret = 255;
      }
    }
    else {
      $ret = 255;
    }
  }
  return $ret;
}

#function to delete a dhcp group
function dhcp_group_del($id) {
  global $sql;
  $bg = new ockd_client();
  $ret = 0;
  if ($id != "") {
    pxe_disable_group($id);
    // Need to write to log before the actual delete for the groupname to be logged.
    writelog("dhcpgconfig","DHCP Group deleted",$id,"");
    if (mysql_query("delete from dhcpgroupconf where dhcpgroupid=$id", $sql)) {
      $result = mysql_query("select * from dhcpgroupmem where dhcpgroupid=$id", $sql); 
      while ($r = mysql_fetch_array($result)) {
        writelog("hostconfig","Host group membership removed",$r["id"],"");
      }
      if (mysql_query("delete from dhcpgroupmem where dhcpgroupid=$id", $sql)) {
        if (!mysql_query("delete from dhcpgroup where id=$id", $sql)) {
          $ret = 255;
        }
      }
      else {
        $ret = 255;
      }
    }
    else {
      $ret = 255;
    }
  }
  else {
    $ret = 255;
  }
  // Regenerate DHCP config file and restart DHCP:
  $dhcp_status = $bg->run(generate_dhcpd_conf);
  if ($dhcp_status == 0) {
     $ret = 0;
  }
  else {
    $ret = $dhcp_status;
  }

  return $ret;
}


function dhcp_groupmembers($groupid) {
  global $sql;
  $ret = array();
  $i = 0;
  $result = mysql_query("select * from dhcpgroupmem where dhcpgroupid=$groupid", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"]=$r["id"];
      $ret[$i]["hostname"]=$r["hostname"];
      $ret[$i]["descr"]=$r["descr"];
      $ret[$i]["statichost"]=$r["statichost"];
      $i++;
    }
  }
  return $ret;
}

function dhcp_fixentry($key,$value) {
  if ($key == "filename") {
    $value = "\"$value\"";
  }
  elseif ($key == "option domain-search") {
    $search_domains = explode(',', $value);
    unset($value);
    for ($i=0; $i<count($search_domains); $i++) {
      if ($i == "0") {
        $value = "\"" . $search_domains[$i] . "\"";
      }
      else {
        $value .= ",\"" . $search_domains[$i] . "\"";
      }
    }
  }
  elseif ($key == "option domain-name") {
    $value = "\"$value\"";
  }
  elseif ($key == "ddns-domainname") {
    $value = "\"$value\"";
  }
  elseif ($key == "option grubmenu") {
    $value = "\"$value\"";
  }
  elseif ($key == "option wpad-url") {
    $value = "\"$value\"";
  }
  elseif ($key == "include") {
    $value = "\"$value\"";
  }
  elseif ($key == "failover peer") {
    $value = "\"$value\"";
  }
  return $value;
}

function dhcp_hostingroup($host) {
  global $sql;
  $result = mysql_query("select * from dhcpgroupmem where hostname = \"$host\"");
  if (mysql_num_rows($result) > 0) {
    $ret = "yes";
  }
  else {
    $ret = "no";
  }
  return $ret;
}


function generate_dhcpd_conf() {
  global $f_dhcpd_conf, $dhcpd_bin, $dhcpd_cmd_restart, $tftpserver, $sql, $webroot, $hostfqdn;
  $dhconf = "# \n";
  $dhconf .= "# ISC DHCPd configuration file\n";
  $dhconf .= "# Generated by OneClickKick (http://sf.net/projects/oneclickkick)\n";
  #$dhconf .= "# Please go to http://" . $_SERVER["SERVER_NAME"] . "$webroot\n";
  $dhconf .= "# Please go to " . $_SESSION["CFG"]["webui_hostname"] . "$webroot using a web browser\n";
  $dhconf .= "# to make changes to this configuration.\n";
  $dhconf .= "# \n";
  $dhconf .= "# Last updated at " . date(DATE_RFC822) . "\n";
  $dhconf .= "# \n";
  # Get global dhcp options from DB
  $result = mysql_query("select * from dhcpconf where dhcpsubnetid=0 order by id", $sql);
  if ($result) {
    while ($r = mysql_fetch_array($result)) {
      $item = $r["item"];
      $data = $r["data"];
      $data = dhcp_fixentry($item,$data);
      $dhconf .= "$item $data;\n";
    }
  }
  $dhconf .= "\n\n\n";

  # Get DHCP subnets
  $dhsub = dhcp_subnets();
  # For subnet classes
  $i=0;
  $j=0;
  $dh_conf_hosts=array();
  # Get the hostnames
  $hosts = hosts_list();

  # Determine which subnet to put the host in
  while (list($hostid, $host) = each ($hosts)) {
    # Get IP, and Ethernet address for the host
    $h = host_details_byname("$host");

    if (isset($h["ip"]) && isset($h["host"]) && isset($h["ether"])) {
      preg_match('/(\d+.\d+.\d+)/', $h["ip"], $subnet);
      $h_subnet = $subnet[0] . ".0";

      for ($i=0; $i < count($dhsub); $i++) {
        if ($h_subnet == $dhsub[$i]["subnet"]) {
	        $subnet = $dhsub[$i]["subnet"];
	        $dh_conf_hosts[$subnet][$host]=$host;
	        $j++;
        }
      }
    }
  }
  ksort($dh_conf_hosts);
  /* Print hosts without a group membership.
   * Start $i at 1, to skip creation of "subnet Global"
   */
  for ($i=1; $i < count($dhsub); $i++) {
    unset($dhconfp, $options);
    $options = dhcp_subnetconfig($dhsub[$i]["id"]);
    if (isset($options["range"]) && isset($options["failover peer"])) $dhconfp .= "    pool { \n";
    $subnet = $dhsub[$i]["subnet"];
    $netmask = $dhsub[$i]["netmask"];
    $dhconf .= "subnet $subnet netmask $netmask {\n";
    while (list($key, $val) = each($options)) {
      $val = dhcp_fixentry($key,$val);
      if ($key == "range" || $key == "failover peer") {
        if ($key == "failover peer" && isset($options["range"])) $dhconfp .= "      $key $val;\n";
        if ($key != "failover peer") $dhconfp .= "      $key $val;\n";
      }
      else {
        $dhconf .= "  $key $val;\n";
      }
    }
    /* Deny dynamic bootp clients for failover subnets.
     * DHCP protocol limitation
     */
    if (isset($options["range"]) && isset($options["failover peer"])) $dhconfp .= "      deny dynamic bootp clients; \n";
    if (isset($options["range"]) && isset($options["failover peer"])) $dhconfp .= "    } \n";
    $dhconf .= $dhconfp;

    while (list($key, $val) = each($dh_conf_hosts[$subnet])) {
      $h = host_details_byname("$val");
      if ($hostfqdn == 1) {
	$option_hostname = $h["host"];
      }
      else {
        $option_hostname = $h[hostshort];
      }
      if (dhcp_hostingroup($h["host"]) == "no") {
        $dhconf .= "  host ".$h["host"]." {\n";
        $dhconf .= "    option host-name \"$option_hostname\"; \n";
        if ($h["ether"] != "na") $dhconf .= "    hardware ethernet ".$h["ether"]."; \n";
        if ($dhsub[$i]["statichosts"] == 1) $dhconf .= "    fixed-address ".$h["ip"]."; \n";
        $dhconf .= "  } \n\n";
      }
    }
    $dhconf .= "}\n\n";
  }
  // Now print the hosts in dhcp groups.
  $dhcpgroups=dhcp_groups();
  for ($i=0; $i < count($dhcpgroups); $i++) {
    $dhconf .= "group { # " . $dhcpgroups[$i]["groupname"] . " \n";
    $options=dhcp_groupconfig($dhcpgroups[$i]["id"]);
    while (list($key, $val) = each($options)) {
      $val = dhcp_fixentry($key,$val);
      $dhconf .= "  $key $val;\n";
    }
    $members=dhcp_groupmembers($dhcpgroups[$i]["id"]);
    for ($j=0; $j < count($members); $j++) {
      $c=host_details_byname($members[$j]["hostname"]);
      if ($hostfqdn == 1) {
        $option_hostname = $c["host"];
      }
      else {
        $option_hostname = $c["hostshort"];
      }

      //if (isset($c["ether"]) && isset($c["ip"])) {
      if (isset($c["ether"])) {
        $dhconf .= "  host ".$c["host"]." {\n";
        $dhconf .= "    ddns-hostname \"" . $c["hostshort"]  . "\"; \n";
        if ($dhcpgroups[$i]["hostfqdn"] == 1) {
          $dhconf .= "    option host-name \"" . $c["host"] . "\"; \n";
	}
        elseif ($dhcpgroups[$i]["hostfqdn"] == 2) {
          $dhconf .= "    option host-name \"" . $c["hostshort"] . "\"; \n";
	}
	else {
          $dhconf .= "    option host-name \"$option_hostname\"; \n";
	}
        if ($h["ether"] != "na") {
	  $dhconf .= "    hardware ethernet ".$c["ether"]."; \n";
	}
        if (isset($c["ip"])) {
	  if ($dhcpgroups[$i]["statichosts"] == 1 || $members[$j]["statichost"] == 1) {
	    $dhconf .= "    fixed-address ".$c["ip"]."; \n";
	  }
	}
        $dhconf .= "  } \n";
      }
    }
  $dhconf .= "}\n\n";
  }
  // Overwrite and close the dhcpd.conf file
  $f_dhcpd_conf_tmp = tempnam(sys_get_temp_dir(), 'preflight-test.dhcpd.conf.');
  $fp = fopen("$f_dhcpd_conf_tmp", 'w');
  fwrite($fp, $dhconf);
  $_SESSION[tmp][lastdhcpdconf] = $dhconf;
  fclose($fp);
  exec("$dhcpd_bin -d -f -cf $f_dhcpd_conf_tmp -t 2> /dev/stdout", $errout, $cnfstatus);
  $_SESSION[tmp][lastdhcpdoutput] = $errout;
  if ($cnfstatus == 0) {
    if (copy("$f_dhcpd_conf_tmp","$f_dhcpd_conf")) {
      exec("$dhcpd_cmd_restart 2> /dev/stdout", $rerrout, $rcnfstatus);
    
      if ($rcnfstatus == 0) {
        $retval = 0;
        writelog("dhcpconfig","DHCP service restarted","","");
      }
      else {
        $retval = 8;
      }
    }
    else {
      $retval = 20;
    }

    // Remove the temporary config file
    unlink("$f_dhcpd_conf_tmp");
  }
  else {
    $retval = 9;
  }
  return $retval;
}

# function to update dhcp group
function dhcp_group_update($groupid,$newname,$newpxeprofileid,$newdescr,$newhostfqdn) {
  global $sql;
  $bg = new ockd_client();
  $ret = 0;
  if ($_POST["statichosts"] == "on") $statichosts = "1";
  if ($_POST["statichosts"] != "on") $statichosts = "0";

  $result = mysql_query("update dhcpgroup set groupname=\"$newname\", pxeprofileid=\"$newpxeprofileid\", descr=\"$newdescr\", statichosts=\"$statichosts\", hostfqdn=\"$newhostfqdn\" where id=$groupid", $sql);
  if (mysql_affected_rows() == 0) {
    $ret = mysql_error($sql);
  }
  else {
   writelog("dhcpgconfig","DHCP Group modified",$groupid,"");
   // Regenerate DHCP config file and restart DHCP:
   $dhcp_status = $bg->run(generate_dhcpd_conf);
   if ($dhcp_status == 0) {
      $ret = 0;
   }
   else {
     $ret = $dhcp_status;
    }
  }
  return $ret;  
}


// Return available dhcp options
// Type is 0 the dhcp subnet id, so 0 will return global options
function dhcp_avail_options($type) {
  $ret = array();
  $i = 0;

  // DHCPD.CONF GLOBAL OPTIONS
  if ($type == 0) {
    $ret[$i]["item"] = "default-lease-time";
    $ret[$i]["desc"] = "Default lease time (in seconds)";
    $i++;
    $ret[$i]["item"] = "max-lease-time";
    $ret[$i]["desc"] = "Max lease time (in seconds)";
    $i++;
    $ret[$i]["item"] = "include";
    $ret[$i]["desc"] = "Include config file (include)";
    $i++;
    $ret[$i]["item"] = "ping-check";
    $ret[$i]["desc"] = "Perform ping check? (ping-check)";
    $ret[$i]["type"] = "checkbox";
    $i++;
    $ret[$i]["item"] = "ddns-updates";
    $ret[$i]["desc"] = "Do Dynamic DNS Updates? (ddns-updates)";
    $ret[$i]["type"] = "checkbox";
    $i++;
    $ret[$i]["item"] = "allow client-updates;";
    $ret[$i]["desc"] = "Allow Client Dynamic DNS updates? (allow client-updates)";
    $ret[$i]["type"] = "checkbox";
    $i++;
    $ret[$i]["item"] = "update-static-leases";
    $ret[$i]["desc"] = "Update Dynamic DNS for static leases? (update-static-leases)";
    $ret[$i]["type"] = "checkbox";
    $i++;
    $ret[$i]["item"] = "deny duplicates;";
    $ret[$i]["desc"] = "Deny duplicate leases? (deny duplicates)";
    $ret[$i]["type"] = "checkbox";
    $i++;
    $ret[$i]["item"] = "one-lease-per-client";
    $ret[$i]["desc"] = "One lease per client? (one-lease-per-client)";
    $ret[$i]["type"] = "checkbox";
    $i++;
  }

  // dhcpd.conf per subnet options
  elseif ($type > 0) {
    $ret[$i]["item"] = "subnet";
    $ret[$i]["desc"] = "Subnet";
    $ret[$i]["validate"] = "ipv4";
    $ret[$i]["required"] = "true";
    $i++;
    $ret[$i]["item"] = "netmask";
    $ret[$i]["desc"] = "Netmask";
    $ret[$i]["validate"] = "ipv4";
    $ret[$i]["required"] = "true";
    $i++;
    $ret[$i]["item"] = "descr";
    $ret[$i]["desc"] = "Description";
    $ret[$i]["validate"] = "present";
    $ret[$i]["required"] = "true";
    $i++;
    $ret[$i]["item"] = "range";
    $ret[$i]["desc"] = "DHCP Range (from-ip to-ip)";
    $ret[$i]["validate"] = "dhcprange";
    $ret[$i]["required"] = "false";
    $i++;
    $ret[$i]["item"] = "autoip_offset";
    $ret[$i]["desc"] = "Starting IP for auto-assignment (last octet only)";
    $i++;
    $ret[$i]["item"] = "failover peer";
    $ret[$i]["desc"] = "Failover peer (dhcp-failover)";
    $i++;
    $ret[$i]["item"] = "statichosts";
    $ret[$i]["desc"] = "Static IP for members?";
    $ret[$i]["type"] = "checkbox";
    $i++;
  }

  // dhcpd.conf options for either global or per subnet options
  $ret[$i]["item"] = "authoritative;";
  $ret[$i]["desc"] = "Authorative DHCP? (authoritative)";
  $ret[$i]["type"] = "checkbox";
  $i++;
  $ret[$i]["item"] = "next-server";
  $ret[$i]["desc"] = "BOOTP server (next-server)";
  $ret[$i]["validate"] = "ipv4";
  $ret[$i]["required"] = "true";
  $i++;
  $ret[$i]["item"] = "filename";
  $ret[$i]["desc"] = "Boot filename (filename)";
  $i++;
  $ret[$i]["item"] = "option broadcast-address";
  $ret[$i]["desc"] = "Broadcast address";
  $ret[$i]["validate"] = "ipv4";
  $ret[$i]["required"] = "false";
  $i++;
  $ret[$i]["item"] = "option routers";
  $ret[$i]["desc"] = "Gateway (routers)";
  $ret[$i]["validate"] = "ipv4";
  $ret[$i]["required"] = "false";
  $i++;
  $ret[$i]["item"] = "option domain-name";
  $ret[$i]["desc"] = "Domain name";
  $i++;
  $ret[$i]["item"] = "option domain-search";
  $ret[$i]["desc"] = "Domain search order";
  $i++;
  $ret[$i]["item"] = "get-lease-hostnames";
  $ret[$i]["desc"] = "DNS lookup client ip address for D-DNS updates? (get-lease-hostnames)";
  $ret[$i]["type"] = "checkbox";
  $i++;
  $ret[$i]["item"] = "option domain-name-servers";
  $ret[$i]["desc"] = "DNS Servers";
  $ret[$i]["validate"] = "ipv4multicomma";
  $ret[$i]["required"] = "false";
  $i++;
  $ret[$i]["item"] = "option netbios-name-servers";
  $ret[$i]["desc"] = "WINS Servers";
  $ret[$i]["validate"] = "ipv4multicomma";
  $ret[$i]["required"] = "false";
  $i++;
  $ret[$i]["item"] = "option wpad-url";
  $ret[$i]["desc"] = "WPAD/PAC Proxy settings (wpad-url)";
  $i++;
  $ret[$i]["item"] = "option ntp-servers";
  $ret[$i]["desc"] = "NTP-servers (option ntp-servers) (comma seperated)";
  $i++;
  return $ret;
}

# Return value of specific dhcp option
function dhcp_get_optvalue($dhcpsubnetid,$item) {
  global $sql;
  if ($item == "subnet" || $item == "netmask" || $item == "descr" || $item == "statichosts") {
    $q = "select $item as data from dhcpsubnet where id=\"$dhcpsubnetid\"";
  }
  else {
    $q = "select data from dhcpconf where item=\"$item\" and dhcpsubnetid=\"$dhcpsubnetid\"";
  }
  $result = mysql_query("$q", $sql); 
  if ($result) $r = mysql_fetch_array($result);  
  $ret = $r["data"]; 
  return $ret;
}

# Set a dhcp value
function dhcp_set_optvalue($dhcpsubnetid,$item,$value) {
  global $sql;
  $item = str_replace("_", " ", "$item");
  $ret = 255;
  $q = "select item from dhcpconf where dhcpsubnetid=\"$dhcpsubnetid\" and item=\"$item\"";
  $result = mysql_query("$q", $sql);

  // Update if item already exists and there is a value present
  // Or delete the item from config if the value is not present
  // to allow global options to take place
  if (mysql_num_rows($result) > 0) {
    if ($value == "") {
      $q = "delete from dhcpconf where dhcpsubnetid=\"$dhcpsubnetid\" and item=\"$item\"";
    }
    else {
      $q = "update dhcpconf set data=\"$value\" where dhcpsubnetid=\"$dhcpsubnetid\" and item=\"$item\"";
    }
    $result2 = mysql_query("$q", $sql);
    if ($result) $ret = 0;
  }

  // Item does not already exist, create item
  elseif ($value) {
    $q = "insert into dhcpconf (dhcpsubnetid,item,data) values (\"$dhcpsubnetid\",\"$item\",\"$value\")";
    $result2 = mysql_query("$q", $sql);
    if ($result) $ret = 0;
  }
 return $ret;
}

function dhcp_get_dhcpd_version() {
  global $dhcpd_bin;
  exec("$dhcpd_bin --version 2> /dev/stdout", $output, $errout);
  if ($errout == 0) {
    foreach ($output as $v) {
      $ret .= $v;
    }
  }
  else {
    $ret = false;
  }
  return $ret;
}

?>
