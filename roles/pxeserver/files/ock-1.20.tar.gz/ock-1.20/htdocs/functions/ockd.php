<?php

class ockd_client {

  // Check to see if there is a ockd alive
  function alive() {
    global $sql;
    $query = "delete from jobs where job_function='ock_self' and (timestamp < now() - interval 60 second)";
    mysql_query("$query", $sql);
    $query = "select timestamp, plock, plock_host from jobs where job_function='ockd_self' and (timestamp > now() - interval 60 second)";
    $result = mysql_query("$query", $sql);
    if (mysql_num_rows($result) > 0) {
      $ret = array();
      $i = 0;
      while ($r = mysql_fetch_array($result)) {
        $ret[$i]["timestamp"] = $r["timestamp"];
        $ret[$i]["plock"] = $r["plock"];
        $ret[$i]["plock_host"] = $r["plock_host"];
        $i++;
      }
    }
    else {
      $ret = false;
    }
    return $ret;
  }

  function run($job_function) {
    global $sql;
    $query = "insert into jobs (job_function,user,userip) values (\"$job_function\", \"". $_SESSION["USERNAME"] ."\", \"". $_SERVER["REMOTE_ADDR"] ."\")";
    if ($this->alive()) {
      mysql_query("$query", $sql);
      writelog("info","ockd job added: $job_function",0,"", $_SESSION["USERNAME"], $_SERVER["REMOTE_ADDR"]);
      $ret = 0;
    }
    else {
      $ret = $job_function();
    }
    return $ret;
  }

  function check_alert() {
    global $sql;
    $query = "select job_function,timestamp from jobs where job_function != 'ockd_self' and (timestamp < now() - interval 60 second)";
    $result = mysql_query("$query", $sql);
    if (mysql_num_rows($result) > 0) {
      $ret = "Alert! " . mysql_num_rows($result) . " background jobs older than 60 seconds found. Please check status of ockd.";
      $i = 0;
      while ($r = mysql_fetch_array($result)) {
        $job_function = $r["job_function"];
        $timestamp = $r["timestamp"];
        $ret .= " Job: $job_function from $timestamp.";
      }
    }
    else {
      $ret = false;
    }
    return $ret;
  }
}

?>
