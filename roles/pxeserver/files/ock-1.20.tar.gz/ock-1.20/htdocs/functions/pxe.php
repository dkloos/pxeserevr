<?php

# Check if a client is active for PXE boot
function pxe_checkactive($dhcpgroupmemid) {
  global $sql;
  $ret = "no";
  $result = mysql_query("select * from pxeactive where dhcpgroupmemid=$dhcpgroupmemid");
  if (mysql_num_rows($result) > 0) {
    $ret = "yes";
  }
  if (!isset($ret)) $ret = FALSE;
  return $ret;
}

function pxe_host_curprofile($dhcpgroupmemid) {
  global $sql;
  $ret = 1;
  $result = mysql_query("select pxeprofileid from pxeactive where dhcpgroupmemid=$dhcpgroupmemid");
  if ($result) {
    $r = mysql_fetch_array($result);
    $id = $r["pxeprofileid"];
    $ret = pxe_profileinfo($id);
  }
  return $ret;
}


# Function to enable a client for install via PXE
# This function will return 1 if the client is already configured for PXE boot
# and the force flag has not been set.
# It will return 95 if there are file permission errors
# It will return 0 if everything went OK.
function pxe_enable_client($dhcpgroupmemid,$pxeprofileid,$force=0) {
  global $sql, $pxeconfigdir, $webroot, $kswebserver, $tftpserver;
  $active = pxe_checkactive($dhcpgroupmemid);
  if ($active == "yes" && $force != "1") {
    $ret = "5";
  }
  else {
    if ($pxeprofileid == "") return 255;
    if (pxe_profileinfo($pxeprofileid) == 255) return 255;
    $ret = "0";
    $result = mysql_query("select hostname,dhcpgroupid from dhcpgroupmem where id=$dhcpgroupmemid", $sql);
    if (mysql_num_rows($result) > 0) {
      while ($r = mysql_fetch_array($result)) {
        $hostname=$r["hostname"];
        $dhcpgroupid=$r["dhcpgroupid"];
      }
    }   
    $h = host_details_byname("$hostname");
    $t = new tags();
    if (isset($h["ether"])) {
      $auth = rand_string(32);
      $ether = strtolower(preg_replace("/:/","-",$h["ether"]));
      $result = mysql_query("select item, value from pxeconf where pxeprofileid=$pxeprofileid order by id");
      $pxeconf = "";
      if ($result) {
        while ($r = mysql_fetch_array($result, MYSQL_NUM)) {
  	// Replace _KS_ and _TFTPSEVER_ placeholders with real data
          $val = $r[1];
          $val = preg_replace("/_KS_/","http://$kswebserver/$webroot/ks.php?host=$hostname&auth=$auth&dl=1","$val");
          $val = preg_replace("/_TFTPSERVER_/","$tftpserver","$val");
          $val = $t->parse_line($val,"pxe");
          $pxeconf .= "$r[0] $val\n";
        }
      }
      if ($fp = fopen("$pxeconfigdir/01-$ether", 'w')) {
        fwrite ($fp, $pxeconf);
        fclose ($fp);
        if ($active == "yes") {
          $query = "update pxeactive set pxeprofileid=\"$pxeprofileid\",auth=\"$auth\",gotksfile=0 where dhcpgroupmemid=\"$dhcpgroupmemid\"";
        }
        else {
          $query = "insert into pxeactive (dhcpgroupmemid,pxeprofileid,auth) values (\"$dhcpgroupmemid\",\"$pxeprofileid\",\"$auth\")";
        }
        mysql_query("$query", $sql);
        $pxepinfo = pxe_profileinfo($pxeprofileid);
        writelog("kickstart","Host PXE enabled for ".$pxepinfo["name"],$dhcpgroupmemid,"");
      }
      else {
        $ret = 95;
      }
    }
  }
  return $ret;
}

# Disable PXE boot for a client
function pxe_disable_client($dhcpgroupmemid,$force=0,$updateonly=0) {
  global $sql, $pxeconfigdir;
  $active = pxe_checkactive($dhcpgroupmemid);
  $ret = 0;
  if ($active == "yes") {
    $result = mysql_query("select id,hostname,dhcpgroupid from dhcpgroupmem where id=$dhcpgroupmemid", $sql);
    if (mysql_num_rows($result) > 0) {
      while ($r = mysql_fetch_array($result)) {
        $dhcpgroupmemid=$r["id"];
        $hostname=$r["hostname"];
        $dhcpgroupid=$r["dhcpgroupid"];
      }
      $h = host_details_byname("$hostname");
      $ether = strtolower(preg_replace("/:/","-","$h[ether]"));
      mysql_query("update dhcpgroupmem set ipa_otp == '0' where id=\"$dhcpgroupmemid\"", $sql);
      if (pxe_host_gotks($dhcpgroupmemid) == 0) { 
        $unlnk = true; 
      } else { 
        $unlnk = unlink("$pxeconfigdir/01-$ether"); 
      }    
      if ($unlnk) {
        if ($updateonly == "0") {
          mysql_query("delete from pxeactive where dhcpgroupmemid=$dhcpgroupmemid", $sql);
          writelog("kickstart","Host PXE finished/disabled",$dhcpgroupmemid,"");
        }
        else {
          mysql_query("update pxeactive set gotksfile=1 where dhcpgroupmemid=$dhcpgroupmemid", $sql);
    	  writelog("kickstart","PXE disabled because ks script was downloaded",$dhcpgroupmemid,"");
        }
      }
      elseif ($force == "1" && $updateonly == "0") {
        mysql_query("delete from pxeactive where dhcpgroupmemid=$dhcpgroupmemid", $sql);
        writelog("kickstart","Host PXE finished/disabled",$dhcpgroupmemid,"");
      }
      else {
        $ret = 95;
      }
    }
  }
  else {
    $ret = 1;
  }
  return $ret;
}

# Enable PXE boot for an entire dhcp group
function pxe_enable_group($dhcpgroupid,$pxeprofileid,$force=1) {
  global $sql;
  $ret = 0;
  $i = 0;
  if ($pxeprofileid == 0) {
    $result = mysql_query("select pxeprofileid from dhcpgroup where id=\"$dhcpgroupid\"");
    if (mysql_num_rows($result) > 0) {
      while ($r = mysql_fetch_array($result)) {
        $pxeprofileid=$r["pxeprofileid"];
      }
    }
  }
  $result=mysql_query("select * from dhcpgroupmem where dhcpgroupid=\"$dhcpgroupid\"", $sql);
  if (mysql_num_rows($result) > 0) {
    while ($r = mysql_fetch_array($result)) {
      $dhcpgroupmemid = $r["id"];
      $hostname = $r["hostname"];
      $h=host_details_byname("$hostname");
      $stat[$i][hostname] = $hostname;
      if (isset($h["ip"]) && isset($h["ether"])) {
        $stat[$i][result] = pxe_enable_client($dhcpgroupmemid,$pxeprofileid,$force);
      }
      else {
        $stat[$i][result] = 1;
      }
      $i++;
    }
  }
  return $stat;
}

function pxe_disable_group($dhcpgroupid) {
  global $sql;
  $ret = 0;
  $i = 0;
  $result = mysql_query("select * from dhcpgroupmem where dhcpgroupid=\"$dhcpgroupid\"", $sql);
  if (mysql_num_rows($result) > 0) {
    while ($r = mysql_fetch_array($result)) {
      $dhcpgroupmemid = $r["id"];
      $hostname = $r["hostname"];
      $h=host_details_byname("$hostname");
      $stat[$i][hostname] = $hostname;
      if (isset($h["ip"]) && isset($h["ether"])) {
        $stat[$i][result] = pxe_disable_client($dhcpgroupmemid);
      }
      else {
        $stat[$i][result] = 1;
      }
      $i++;
    }
  }
  return $stat;
}


# Function to retreive PXE group for DHCP GROUP

function pxe_profile($dhcpgroupid) {
  global $sql;
  $result = mysql_query("select dhcpgroup.pxeprofileid,pxeprofile.name from dhcpgroup,pxeprofile where dhcpgroup.pxeprofileid=pxeprofile.id and dhcpgroup.id=$dhcpgroupid", $sql);
  if (mysql_num_rows($result) > 0) {
    $ret = array();
    $r = mysql_fetch_array($result);
    $ret["id"] = $r["pxeprofileid"];
    $ret["name"] = $r["name"];
  }
  else {
    $ret = 0;
  }
  return $ret;
}

# function to retreive PXE profiles

function pxe_profiles() {
  global $sql;
  $result = mysql_query("select id,name,osid from pxeprofile order by name", $sql);
  if (mysql_num_rows($result) > 0) {
    $ret = array();
    $i = 0;
    while ($r = mysql_fetch_array($result)) {
      //$ret[$i]["id"] = $r["id"];
      //$ret[$i]["name"] = $r["name"];
      $ret[$i] = $r;
      $i++;
    }
  }  
  else {
    $ret = 255;
  }
  return $ret;
}

# function to retrevive template profiles
function pxe_imagefile_list() {
  global $tftpimagedir;

  // Loop over the tftp image directory to find .ockimage files
  $d = dir("$tftpimagedir");
  $ret = array();
  $i = 0;

  // Find a list of boot images
  $bootimages = array();
  while (false !== ($entry = $d->read())) {
    if (is_file("$tftpimagedir/$entry/.ockimage")) {
      $bootimages[] = $entry;
    }
  }

  // Sort the boot images according to the directory name
  asort($bootimages);

  // Retreive info about each bootimage and put this into the return array
  foreach ($bootimages as $entry) {
    $id = $entry;
    // Check if the .ockimage file got contents,
    // and read the name tag from the file.
    // Directory name where the .ockimage file was found
    // is returned as ID.
    if (file_get_contents("$tftpimagedir/$entry/.ockimage", NULL, NULL, NULL, 32000) != "") {
      $fcont = file("$tftpimagedir/$entry/.ockimage");
      $match = array();
      foreach($fcont as $key => $value) {
        preg_match("/^([\S]+):([\S\s]+)/", $value, $match);
        if (strtolower($match[1]) == "name") $name = $match[2];
        if (strtolower($match[1]) == "osid") $osid = $match[2];
      }
      $ret[$i]["id"] = $entry;
      $ret[$i]["name"] = $name;
      $ret[$i]["osid"] = $osid;
      if ($entry == $current) {
        $ret[$i][selected] = 1;
      }
      $i++;
    }
  }
  $d->close();

  // Return found images
  return $ret;
}


function pxe_gotks($pxeprofileid) {
  global $sql;
  $result = mysql_query("select pxeprofileid from ksconf where pxeprofileid=$pxeprofileid", $sql);
  if (mysql_num_rows($result) > 0) {
    $ret = 0;
  }
  else {
    $ret = 255;
  }
  return $ret;
}

function pxe_host_gotks($dhcpgroupmemid) {
  global $sql;
  $result = mysql_query("select gotksfile from pxeactive where dhcpgroupmemid=$dhcpgroupmemid", $sql);
  if ($result) {
    $r = mysql_fetch_array($result);
    if ($r["gotksfile"] == 1) {
      $ret = 0;
    }
    else {
      $ret = 1;
    }
  }
  else {
    $ret = 255;
  }
  return $ret;
}

function pxe_profileinfo($pxeprofileid) {
  global $sql;
  $result = mysql_query("select * from pxeprofile where id=$pxeprofileid order by id", $sql);
  if (mysql_num_rows($result) > 0) {
    $ret = array();
    $r = mysql_fetch_array($result);
    $ret["id"] = $r["id"];
    $ret["name"] = $r["name"];
    $ret["descr"] = $r["descr"];
    $ret["boottypeid"] = $r["boottypeid"];
    $ret["osid"] = $r["osid"];
    $ret["defpxe"] = $r["defpxe"];
    $ret["defpxepwd"] = $r["defpxepwd"];
    $ret["imagedir"] = $r["imagedir"];
    $ret["imagereadme"] = $r["imagereadme"];
  }
  else {
    $ret = 255;
  }
  return $ret;
}

function pxe_defaultfile_create() {
  global $sql, $pxeconfigdir, $bootpassword, $tftpserver, $kswebserver, $webroot;
  $ret = 0;
  $q = "select * from pxeprofile where defpxe=1 order by name";
  $result = mysql_query("$q", $sql);
  $ksmasterkey = pxe_ks_setmasterkey();
  $t = new tags();

  $q = "select value from config where item='pxemenutitle'";
  $result2 = mysql_query("$q", $sql);
  if (mysql_num_rows($result2) > 0) {
    $r = mysql_fetch_array($result2);
    $pxemenutitle = trim(strip_tags($r["value"]));
  }
  else {
    $pxemenutitle = "OCK MAIN";
  }


  $pxeconf = "#\n";
  $pxeconf .= "# Pxelinux default configuration created by OneClickKick\n";
  $pxeconf .= "# Created at: " . date(DATE_COOKIE) . "\n";
  $pxeconf .= "\n";
  $pxeconf .= "MENU BACKGROUND img/splash.jpg\n";
  $pxeconf .= "DEFAULT img/vesamenu.c32\n";
  $pxeconf .= "INCLUDE img/menu.cfg\n";
  $pxeconf .= "MENU TITLE " . $pxemenutitle ."\n";
  $pxeconf .= "TIMEOUT 100\n";
  $pxeconf .= "PROMPT 0\n";
  $pxeconf .= "NOESCAPE 0\n";

  $pxeconf .= "LABEL bootlocal\n";
  $pxeconf .= "MENU LABEL Boot ^Local Harddrive\n";
  $pxeconf .= "LOCALBOOT 0\n";

  while($r = mysql_fetch_array($result)) {
    $pxeprofileid = $r["id"];
    $defpxepwd = $r["defpxepwd"];
    $pxeprofilename = $r["name"];

    $pxeconf .= "# \n";
    $pxeconf .= "# PXE Profile: $pxeprofilename \n";
    $pxeconf .= "# Password protected: $defpxepwd\n";
    $pxeconf .= "MENU BEGIN\n";
    $pxeconf .= "MENU LABEL $pxeprofilename\n";

    $base64_alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $base64_alphabet .= 'abcdefghijklmnopqrstuvwxyz0123456789ab';
    $salt = '$1$';
    for($i=0; $i<9; $i++){
        $salt .= $base64_alphabet[rand(0,63)];
    }
    $salt .= '$';

    if (CRYPT_MD5 == 1) { 
      $bpassword = crypt($bootpassword,$salt); 
    }

    if ($defpxepwd == 1) $pxeconf .= "MENU PASSWD " . $bpassword . "\n";
    if ($defpxepwd == 1) $pxeconf .= "MENU MASTER PASSWD " . $bpassword . "\n";
 

    $result2 = mysql_query("select item, value from pxeconf where pxeprofileid=$pxeprofileid order by id");
    if ($result2) {
      while ($r2 = mysql_fetch_array($result2, MYSQL_NUM)) {
        if (strtoupper($r2[0]) == "DEFAULT") continue;
        if (strtoupper($r2[0]) == "PROMPT") continue;
        //if (strtoupper($r2[0]) == "MENU LABEL") continue;
        if (strtoupper($r2[0]) == "INCLUDE") continue;
        $val = $r2[1];
        $val = preg_replace("/_KS_/","http://$kswebserver/$webroot/ks.php?&masterauth=$ksmasterkey&pxeprofileid=$pxeprofileid&dl=1","$val");
        $val = preg_replace("/_TFTPSERVER_/","$tftpserver","$val");
        $val = preg_replace("/_OCKENROLLBOOT_/","http://$kswebserver/$webroot/enrollboot.php","$val");
        $val = preg_replace("/_WEBUI_HOSTNAME_/",$_SESSION["CFG"]["webui_hostname"],"$val");
        $val = $t->parse_line($val,"pxe");
        $pxeconf .= "$r2[0] $val\n";
      }
    }
    //$pxeconf .= "MENU LABEL $pxeprofilename\n";

   $pxeconf .= "MENU END\n";
    $pxeconf .= "\n";
  }
  if ($fp = fopen("$pxeconfigdir/default", 'w')) {
    fwrite ($fp, $pxeconf) or $ret = false;
    fclose ($fp) or $ret = false;
  }
  else {
    return $ret = false;
  }
  return $ret;
}

# modify an existing pxe profile
function pxe_profile_update($profileid,$post) {
  global $sql;
  $ret = 0;
  if ($post["defpxe"] != "") {
    $defpxe = 1;
  }
  else {
    $defpxe = 0;
  }
  if ($post["defpxepwd"] != "") {
    $defpxepwd = 1;
  }
  else {
    $defpxepwd = 0;
  }
  $result = mysql_query("update pxeprofile set name=\"".$post["name"]."\", descr=\"".$post["descr"]."\", defpxe=\"$defpxe\", defpxepwd=\"$defpxepwd\" where id=$profileid", $sql);
  if (mysql_affected_rows() > 0) {
    $ret = 0;
    writelog("pxepconfig","PXE profile modified",$profileid,"");
  }
  else {
    $ret = mysql_error($sql);
  }
  pxe_defaultfile_create();
  return $ret;
}


# function to add a new PXE profile
function pxe_profile_add($post) {
  global $sql, $tftpimagedir;
  $ret = 0;
  if ($post[profilename] != "") {
    // Read contents of image settings
    $fcont = file("$tftpimagedir/$post[template]/.ockimage");

    // Determine OS type and boot type
    foreach($fcont as $key => $value) {
      preg_match("/^([\S]+):([\S\s]+)/", $value, $match);
      if (strtolower($match[1]) == "osid") $osid = $match[2];
      if (strtolower($match[1]) == "boottypeid") $boottypeid = $match[2];
    }
 

    // Create the initial profile entry
    $query = "insert into pxeprofile (name,descr,imagedir) values (\"".$post["profilename"]."\",\"".$post["descr"]."\",\"".$post["template"]."\")";
    $result = mysql_query("$query", $sql);
    if ($result) {
      $id = mysql_insert_id($sql);
      if (is_file("$tftpimagedir/$post[template]/README.OCK")) {
	$imagereadme = file_get_contents("$tftpimagedir/$post[template]/README.OCK");
        mysql_query("update pxeprofile set imagereadme=\"$imagereadme\" where id=\"$id\"", $sql);
      }
      mysql_query("update pxeprofile set osid=\"$osid\", boottypeid=\"$boottypeid\" where id=\"$id\"", $sql);
      writelog("pxepconfig","PXE profile added",$id,"");


      // Now build the config based on the template chosen

      $match = array();
      foreach($fcont as $key => $value) {
      	// Get the BOOT lines and determine line number and parent
        preg_match("/^BOOT-([\d]+)-([\d]+):(.*)/", $value, $match);
  
	unset($match2);
      	// Seperate the item and value
      	preg_match("/^([\S\s]+)\;(.*)/", $match[3], $match2);
	unset($item,$value);
      	$item = $match2[1];
      	$value = $match2[2];
      
      	// Replace the _IMAGE_ placeholder with the real image name
      	$value = preg_replace("/_IMAGE_/", "$post[template]", "$value");
      
      	// Reset the parent value if this line does not have a parent
      	if ($match[2] == 0) $parent = 0;
      
      	// Add the line to the database
      	if ($item != "") {
          mysql_query("insert into pxeconf (item,value,pxeprofileid,parent) values (\"$item\",\"$value\",$id,$parent)", $sql);
          $parent = mysql_insert_id($sql);
      	}
      	
      }
    }
    else {
      $ret = mysql_error($sql);
    }
  }
  else {
    $ret = 0;
  }
  // Recreate the pxe default file
  pxe_defaultfile_create();
  return $ret;
}

function pxe_profile_del($id) {
  global $sql;
  $pxepinfo = pxe_profileinfo($id);
  $ret = 0;
  $result = mysql_query("delete from pxeconf where pxeprofileid=$id", $sql);
  if ($result) {
    $result = mysql_query("delete from pxeprofile where id=$id", $sql);
    if (!$result) $ret = 255;
    $result = mysql_query("delete from ksconf where pxeprofileid=$id", $sql);
    if (!$result) $ret = 255;
    $result = mysql_query("select dhcpgroupmemid from pxeactive where pxeprofileid=$id", $sql);
    if ($result) {
      while ($r = mysql_fetch_array($result)) {
        pxe_disable_client($r[dhcpgroupmemid]);
      }
    }
    else { $ret = 255; }
    $result = mysql_query("update dhcpgroup set pxeprofileid='' where pxeprofileid=$id", $sql);
  }
  else {
    $ret = 255;
  }
  if ($ret == 0) {
    pxe_defaultfile_create();
    writelog("pxepconfig","PXE profile ".$pxepinfo["name"]." removed",$id,"");
  }
  return $ret;
}


function pxe_profile_getconf($id) {
  global $sql;
  $result = mysql_query("select * from pxeconf where pxeprofileid=$id order by id", $sql);
  if ($result) {
    $ret = array();
    $i=0;
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"] = $r["id"];
      $ret[$i]["item"] = $r["item"];
      $ret[$i]["value"] = $r["value"];
      $ret[$i]["descr"] = $r["descr"];
      $ret[$i]["parent"] = $r["parent"];
      $i++;
    }
  }
  else {
    $ret = 255;
  }
  return $ret;
}

function pxe_profile_updconf($post) {
  global $sql;
  $ret = 0;
  foreach ($post as $key => $value) {
    if (!mysql_query("update pxeconf set value=\"$value\" where id=$key", $sql)) {
      $ret = 255;
    }
  }
  if ($ret == 0) {
    writelog("pxepconfig","PXE profile modified config",$key,"");
  }
  pxe_defaultfile_create();
  return $ret;
}

function pxe_ks_upload($pxepid,$files,$updateflag,$template) {
  global $sql;
  $ret = 0;

  // Retreive ks from uploaded file, or if this is template generated
  // retreive ks from the files array
  if (is_uploaded_file($files['ksfile']['tmp_name'])) {
    if ($files['ksfile']['size'] < 1280000) {
      $fcont = file($files['ksfile']['tmp_name'], FILE_SKIP_EMPTY_LINES | FILE_IGNORE_NEW_LINES | FILE_TEXT);
    }
    else {
      $ret = 7;
    }
  }
  elseif ($template == 1) {
    $fcont = $files;
  }
  else {
    $ret = 6;
  }
  if ($fcont) {
    if ($updateflag == "1") {
	mysql_query("delete from ksconf where pxeprofileid=\"$pxepid\"", $sql);
    }
    $parent = 0;
    foreach ($fcont as $key => $value) {
      $value = rtrim($value);
      // Find sections in KS file
      if (substr($value,0,1) == "%") {
	$query = sprintf("insert into ksconf (`pxeprofileid`,`data`) values (\"$pxepid\", '%s')", mysql_real_escape_string($value, $sql));
        mysql_query("$query", $sql);
	$parent = mysql_insert_id($sql);
      }
      else {
        $query = sprintf("insert into ksconf (pxeprofileid,data,parent) values (\"$pxepid\", '%s', \"$parent\")", mysql_real_escape_string($value, $sql));
        mysql_query("$query", $sql);
      }
    }
  }
  else {
    $ret = 255;
  }
  if ($ret == 0) {
    writelog("pxepconfig","KS script updated",$pxepid,"");
  }
  return $ret;
}

function pxe_ks_getconf($pxepid,$html=1) {
  global $sql;
  if ($pxepid != "") {
    $query = "select * from ksconf where pxeprofileid=$pxepid and parent=0 order by id";
    $result = mysql_query("$query", $sql);
    if ($result) {
      $ret = array();
      $i=0;
      while ($r = mysql_fetch_array($result)) {
        $ret[$i]["id"] = $r["id"];
        $ret[$i]["parent"] = $r["parent"];
        $ret[$i]["data"] = htmlspecialchars($r["data"]);
        $query2 = "select * from ksconf where parent=" . $ret[$i]["id"] . " order by id";
        $result2 = mysql_query("$query2", $sql);
        if (mysql_num_rows($result2) > 0) {
          while ($r2 = mysql_fetch_array($result2)) {
            $i++;
            $ret[$i]["id"] = $r2["id"];
            $ret[$i]["parent"] = $r2["parent"];
            if ($html == 1) {
              $ret[$i]["data"] = htmlspecialchars($r2["data"]);
	    }
	    else {
              $ret[$i]["data"] = $r2["data"];
	    }
          }
        }
      $i++;
      }
    }
  }
  return $ret;
}

function pxe_ks_updconf($pxepid, $post) {
  global $sql;
  $ret = 0;
  foreach ($post as $key => $value) {
    if (!mysql_query("update ksconf set data=\'$value\' where id=$key", $sql)) {
      $ret = 255;
    }
  }
  if ($ret == 0) {
    writelog("pxepconfig","KS script modified",$pxepid,"");
  }
  return $ret;
}

function pxe_ockimage_parse($image) {
  global $tftpimagedir;

  $ret = array();

  // Read contents of image settings
  $fcont = file("$tftpimagedir/$image/.ockimage");

  // Determine OS type and boot type
  foreach($fcont as $key => $value) {
    preg_match("/^([\S]+):([\S\s]+)/", $value, $match);
    if (strtolower($match[1]) == "name") 		$ret[info]["name"] = $match[2];
    if (strtolower($match[1]) == "description") 	$ret[info]["description"] = $match[2];
    if (strtolower($match[1]) == "ock-image-version") 	$ret[info]["ock-image-version"] = $match[2];
    if (strtolower($match[1]) == "osid") 		$ret[info]["osid"] = $match[2];
    if (strtolower($match[1]) == "boottypeid") 		$ret[info]["boottypeid"] = $match[2];
  }
  return $ret;
}

function pxe_imagefile_upload() {
  global $tftpimagedir, $uploaddir;
  $dest = $_FILES["imagefile"]["name"];
  $req_version = "1.0";
  $ret = 0;

  // Determine if file upload was successfull
  if (is_file($_FILES["imagefile"]["tmp_name"])) {

    // Create a temporary directory to unzip files
    $tmpname = rand();
    $tmpdir = "$uploaddir/$tmpname";
    mkdir("$tmpdir");

    // Unzip uploaded file
    $zip = new ZipArchive;
    $zip->open($_FILES["imagefile"]["tmp_name"]);
    $zip->extractTo("$tmpdir/");
    $zip->close();

    // Loop over the unzipped archive and check for valid boot images
    $d = dir("$tmpdir");
    while (false !== ($entry = $d->read())) {
      if ($entry == ".") continue;
      if ($entry == "..") continue;
      if (is_file("$tmpdir/$entry/.ockimage")) {

        $source = "$tmpdir/$entry";
        $dest = "$tftpimagedir/$entry";

	// Check if the boot image already exists on the server
	if (file_exists("$dest")) {
	  $ret = 17;
	   continue;
	}

        if (smartCopy($source, $dest)) {
          $bimgi = pxe_ockimage_parse($entry);
	  if ($bimgi["info"]["name"] && $bimgi["info"]["ock-image-version"]) {

	    // Successfull image upload, write to log
  	    $logname = $bimgi[info]["name"];
            writelog("pxepconfig","PXE boot image $logname \($entry\) uploaded", "","");
	  }
	  else {

	    // Remove uploaded image
	    unlinkRecursive($dest, true);
	    $ret = 16;
	  }
	}
	else {
	  $ret = 95;
	}

      }
      else {
        $ret = 16;
      }
    }
    // Remove temporary files
    unlinkRecursive($tmpdir, true);
  }
  else {
    $ret = 6;
  }
  return $ret;
}

function pxe_imagefile_del($image) {
  global $tftpimagedir;
  $ret = 0;
  $dir = "$tftpimagedir/$image";
  $bimgi = pxe_ockimage_parse("$image");
  $logname = $bimgi[info]["name"];
  $deleteRootToo = true;

  if ($image != "" && !pxe_imagefile_in_use("$image")) {
    if (unlinkRecursive($dir, $deleteRootToo)) {
      $ret = 0;

      // Boot image file removed successfully, write to log
      writelog("pxepconfig","PXE boot image $logname \"$image\" deleted", "","");
    }
    else {
      // File/folder permission error
      $ret = 15;
    }
  }
  else {
    // Boot image is still in use by PXE profiles
    $ret = 18;
  }
  return $ret;
}

function pxe_imagefile_in_use($image) {
  global $sql;
  $q = "select name from pxeprofile where imagedir=\"$image\"";
  $result = mysql_query("$q", $sql);
  if (mysql_num_rows($result) > 0) {
    $ret = array();
    while ($r = mysql_fetch_array($result)) {
      $ret[] = $r["name"];
    } 
  }
  else {
    $ret = false;
  }
  return $ret;
}

function pxe_ks_setmasterkey() {
  global $sql;
  $newkey = rand_string(128);
  $result = mysql_query("select value from config where item=\"ksmasterkey\"", $sql);
  if (mysql_num_rows($result) > 0) {
    $q = "update config set value=\"$newkey\" where item=\"ksmasterkey\"";
  }
  else {
    $q = "insert into config (item,value) values (\"ksmasterkey\", \"$newkey\")";
  }
  if (mysql_query("$q", $sql)) {
    $ret = "$newkey";
  }
  else {
    $ret = false;
  }
  return($ret);
}


function pxe_ks_getmasterkey() {
  global $sql;
  $result = mysql_query("select ksmasterkey from config", $sql);
  if (mysql_num_rows($result) > 0) {
    $r = mysql_fetch_row($result);
    $ret = $r[ksmasterkey];
  }
  else {
    $ret = pxe_ks_setmasterkey();
  }
  return $ret;
}

function pxe_image_get_readme($imagename) {
  global $tftpimagedir;
  if (is_file("$tftpimagedir/$imagename/README.OCK")) {
    //$ret = file_get_contents("$tftpimagedir/$imagename/README.OCK", NULL, NULL, NULL, 32000);
    $ret = file_get_contents("$tftpimagedir/$imagename/README.OCK");
  }
  else {
    $ret = false;
  }
  return $ret;
}

/*
 *
 * Check for expired pxe clients
 *
 */

function pxe_check_expired_clients() {
  global $sql;

  // Find active pxe clients that no longer exists
  $query = "select id,dhcpgroupmemid from pxeactive";
  $result = mysql_query("$query", $sql);
  if (mysql_num_rows($result) > 0) {
    while ($r = mysql_fetch_array($result)) {
      $query2 = "select id from dhcpgroupmem where id=" .$r["dhcpgroupmemid"];
      $result2 = mysql_query("$query2", $sql);
      if (mysql_num_rows($result2) == 0) {
        $r2 = mysql_fetch_array($result2);
        $query3 = "delete from pxeactive where id=" . $r["id"];
        mysql_query("$query3", $sql);
      }
    }
  }

  unset($query,$result,$result2,$r2);

  if ($_SESSION["CFG"]["pxe_warning_timeout"] > 0) {
    //$query = "select dhcpgroupmemid, audit, gotksfile from pxeactive where audit < (now() - " . $_SESSION["CFG"]["pxe_warning_timeout"] . ")";
    $query = "select dhcpgroupmemid, audit, gotksfile from pxeactive where unix_timestamp(audit) < (unix_timestamp(now()) - " . $_SESSION["CFG"]["pxe_warning_timeout"] . ")";
    $result = mysql_query("$query", $sql);

    if (mysql_num_rows($result) > 0) {
      while ($r = mysql_fetch_array($result)) {
        $query = "select hostname from dhcpgroupmem where id = " . $r["dhcpgroupmemid"];
        $host_result = mysql_query("$query", $sql);
        $r2 = mysql_fetch_array($host_result);
        $hostname = $r2["hostname"];
        if (isset($hostname)) {
          $host_details = host_details_byname($hostname);
          if (isset($host_details["ether"])) $ret_hosts .= "$hostname ";
        }
      }
    }
    else {
      $ret = false;
    }
  }
  else {
    $ret = false;
  }
  if (isset($ret_hosts)) $ret = "Alert! The following hosts was PXE enabled for more than " . $_SESSION["CFG"]["pxe_warning_timeout"] . " seconds ago, and has not been kickstarted: $ret_hosts";
  return $ret;
}


function pxe_check_dead_bootfiles() {
  // Loop over the pxelinux directory and check for dead clients
  $d = dir($_SESSION["CFG"]["pxeconfigdir"]);
  $cache = new cache();
  while (false !== ($entry = $d->read())) {
    if ($entry == ".") continue;
    if ($entry == "..") continue;
    if (substr($entry, 0, 2) != "01") continue;
    if (is_file($_SESSION["CFG"]["pxeconfigdir"]. "/".$entry)) {
      $mac = strtolower(preg_replace("/-/",":",substr($entry, 3, 17)));
      if (!$cache->lookup("ether",NULL,$mac)) {
        writelog("error", "Attempting removal of dead boot file on disk for mac $mac",NULL,NULL);
        unlink($_SESSION["CFG"]["pxeconfigdir"]."/".$entry);
      }
    }
  }
}


function pxe_find_host_from_mac_in_httpheader() {
  $macs = array();
  $regexp_mac_pattern = "/^.+([a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}\:[a-fA-F0-9]{2}$)/";
  $ret = false;

  // Find the first 10 interfaces
  for ($i=0; $i < 10; $i++) {
    $header = "HTTP_X_RHN_PROVISIONING_MAC_$i";
    if (isset($_SERVER["$header"])) {
      preg_match($regexp_mac_pattern, $_SERVER["$header"], $matches);
      $macs[] = $matches[1];
    }
  }

  // Did we find any interfaces? If so, go ahead and look them up
  if (count($macs) > 0) {
    $cache = new cache();

    for ($i=0; $i < count($macs); $i++) {
      $host_details = host_name_byether($macs[$i]);
      if ($host_details) {
        $ret = $host_details["host"];
	// Stop after first entry is found
	break;
      }
    }

  }
  return $ret;
}



class tags {
  function strip_chars($tagname) {
    $tagname = strip_tags($tagname);
    $tagname = strtoupper(preg_replace('/[^A-Za-z0-9\-]/', '', $tagname));
    return $tagname;	
  }
  function strip_underline($tagname) {
    $tagname = preg_replace('_', '', $tagname);
    return $tagname;
  }
  public function get_list($type=false) {
    global $sql;
    $query = "select id,tagtype,tagname,tagvalue from tags";
    if ($type != false) {
      $query .= " where tagtype=\"$type\"";
    }
    $query .= " order by tagname";
    $result = mysql_query($query, $sql);
    if (mysql_num_rows($result) > 0) {
      while ($r = mysql_fetch_array($result)) {
	$ret[]=$r;
      }
    }
    else {
      $ret = false;
    }
    return $ret;
  }
  function get_entry($tagid) {
    global $sql;
    $query = "select id,tagtype,tagname,tagvalue from tags where id=\"$tagid\"";
    $result = mysql_query($query, $sql);
    if (mysql_num_rows($result) > 0) {
      $ret = mysql_fetch_array($result);
    }
    else {
      $ret = false;
    }
    return $ret;
  }
  function add_edit_entry($action,$tagtype,$tagname,$tagvalue,$id=0) {
    global $sql;
    if (isset($tagtype) && isset($tagname) && isset($tagvalue)) {
      if (($tagtype == "pxe") || ($tagtype == "ks")) {
        $tagname = $this->strip_chars($tagname);
        $tagvalue = mysql_real_escape_string($tagvalue);
        if ($action == "add") $query = "insert into tags (tagtype,tagname,tagvalue) values (\"$tagtype\", \"$tagname\", \"$tagvalue\")";
        if ($action == "edit" && $id > 0) $query = "update tags set tagtype=\"$tagtype\", tagname=\"$tagname\", tagvalue=\"$tagvalue\"  where id=\"$id\"";
        if (isset($query) && (mysql_query($query, $sql))) {
          $ret = 0;
        }
        else {
	  $ret = 255;
        }
       }
       else {
         $ret = 255;
       }
    }
    else {
      $ret = 255;
    }
    return $ret;
  }
  function del_entry($id) {
    global $sql;
    $query = "delete from tags where id=\"$id\"";
    if (mysql_query($query, $sql)) {
      $ret = 0;
    }
    else {
      $ret = 255;
    }
    return $ret;
  }
  function parse_line($line,$type) {
    global $sql;
    if (isset($line) && isset($type)) {
      $query = "select tagname,tagvalue from tags where tagtype=\"$type\"";
      $result = mysql_query($query, $sql);
      if (mysql_num_rows($result) > 0) {
        while ($r = mysql_fetch_array($result)) {
          $tagname[] = "/_" . $r["tagname"] . "_/";
          $tagvalue[] = $r["tagvalue"];
        }
        $ret = preg_replace($tagname, $tagvalue, $line);
      }
      else {
	return $line;
      }
    }
    return $ret;
  }
}

?>
