<?php

class kickstart_func {
  function list_lang() {
    $r = array();
    $i = 0;
    $r[$i]["code"] = "C";
    $r[$i]["text"] = "C";
    $i++;
    $r[$i]["code"] = "en_US";
    $r[$i]["text"] = "English (US)";
    $i++;
    $r[$i]["code"] = "en_GB";
    $r[$i]["text"] = "English (UK)";
    $i++;
    $r[$i]["code"] = "fr_FR";
    $r[$i]["text"] = "French";
    $i++;
    $r[$i]["code"] = "it_IT";
    $r[$i]["text"] = "Italian";
    $i++;
    $r[$i]["code"] = "ja_JP";
    $r[$i]["text"] = "Japanese";
    $i++;
    $r[$i]["code"] = "nb_NO";
    $r[$i]["text"] = "Norwegian Bokmaal";
    $i++;
    $r[$i]["code"] = "ru_RU";
    $r[$i]["text"] = "Russian";
    $i++;
    $r[$i]["code"] = "es_ES";
    $r[$i]["text"] = "Spanish";
    $i++;

    return $r;
  }
  function list_keyb() {
    $r = array();
    $i = 0;
    $r[$i]["code"] = "us";
    $r[$i]["text"] = "English (US)";
    $i++;
    $r[$i]["code"] = "gb";
    $r[$i]["text"] = "English (UK)";
    $i++;
    $r[$i]["code"] = "fr";
    $r[$i]["text"] = "French";
    $i++;
    $r[$i]["code"] = "it";
    $r[$i]["text"] = "Italian";
    $i++;
    $r[$i]["code"] = "jp";
    $r[$i]["text"] = "Japanese";
    $i++;
    $r[$i]["code"] = "no";
    $r[$i]["text"] = "Norwegian";
    $i++;
    $r[$i]["code"] = "ru";
    $r[$i]["text"] = "Russian";
    $i++;
    $r[$i]["code"] = "es";
    $r[$i]["text"] = "Spanish";
    $i++;
    return $r;
  }
  function list_mouse() {
    $r = array();
    $i = 0;
    $r[$i]["code"] = "auto";
    $r[$i]["text"] = "Auto-detect";
    $i++;
    return $r;
  }
  function list_timezone() {
    $r = array();
    $i = 0;
    $l = list_timezones();
    $r = array_unique($l);
    sort($r);
    return $r;
  }

  function list_instmethod() {
    $r = array();
    $i = 0;
    $r[$i]["code"] = "cdrom";
    $r[$i]["text"] = "CD-ROM"; 
    $i++;
    $r[$i]["code"] = "nfs";
    $r[$i]["text"] = "NFS"; 
    $i++;
    $r[$i]["code"] = "ftp";
    $r[$i]["text"] = "FTP"; 
    $i++;
    $r[$i]["code"] = "http";
    $r[$i]["text"] = "HTTP"; 
    $i++;
    $r[$i]["code"] = "hd";
    $r[$i]["text"] = "Hard Drive"; 
    $i++;
    return($r);
  }

  function list_instmethod_cfg($code) {
    $r = array();
    $i = 0;
    if ($code == "ftp") {
      $r[$i]["code"] = "server";
      $r[$i]["text"] = "FTP Server";
      $i++;
      $r[$i]["code"] = "directory";
      $r[$i]["text"] = "FTP Directory";
      $i++;
      $r[$i]["code"] = "ftpuser";
      $r[$i]["text"] = "FTP Username";
      $i++;
      $r[$i]["code"] = "ftppasswd";
      $r[$i]["text"] = "FTP Password";
      $i++;
    }
    elseif ($code == "http") {
      $r[$i]["code"] = "server";
      $r[$i]["text"] = "HTTP Server";
      $i++;
      $r[$i]["code"] = "directory";
      $r[$i]["text"] = "HTTP Directory";
      $i++;
    }
    elseif ($code == "hd") {
      $r[$i]["code"] = "partition";
      $r[$i]["text"] = "Hard Drive Partition";
      $i++;
      $r[$i]["code"] = "directory";
      $r[$i]["text"] = "Hard Drive Directory";
      $i++;
    }
    elseif ($code == "nfs") {
      $r[$i]["code"] = "server";
      $r[$i]["text"] = "NFS Server";
      $i++;
      $r[$i]["code"] = "directory";
      $r[$i]["text"] = "NFS Directory";
      $i++;
    }
    return ($r);
  }
  function list_fs() {
    $r = array();
    $i = 0;
    if ($_SESSION["ks"]["cfg"]["ver"] >= 6) {
      $r[$i]["code"] = "ext4";
      $r[$i]["text"] = "ext4";
      $i++;
    }
    $r[$i]["code"] = "ext3";
    $r[$i]["text"] = "ext3";
    $i++;
    $r[$i]["code"] = "ext2";
    $r[$i]["text"] = "ext2";
    $i++;
    $r[$i]["code"] = "reiserfs";
    $r[$i]["text"] = "ReiserFS";
    $i++;
    $r[$i]["code"] = "vfat";
    $r[$i]["text"] = "FAT";
    $i++;
    $r[$i]["code"] = "swap";
    $r[$i]["text"] = "SWAP";
    $i++;
    return ($r);
  }

  function list_coldepth() {
    $r = array();
    $i = 0;
    if ($_SESSION["ks"]["cfg"]["ver"] >= 6) {
      $r[$i]["code"] = "auto";
      $r[$i]["text"] = "Auto";
      $i++;
    }
    $r[$i]["code"] = "32";
    $r[$i]["text"] = "32 bit";
    $i++;
    $r[$i]["code"] = "24";
    $r[$i]["text"] = "24 bit";
    $i++;
    $r[$i]["code"] = "16";
    $r[$i]["text"] = "16 bit";
    $i++;
    $r[$i]["code"] = "8";
    $r[$i]["text"] = "8 bit";
    $i++;
    return ($r);
  }

  function list_resolution() {
    $r = array();
    $i = 0;
    if ($_SESSION["ks"]["cfg"]["ver"] >= 6) {
      $r[$i]["code"] = "auto";
      $r[$i]["text"] = "Auto";
      $i++;
    }
    $r[$i]["code"] = "1280x1024";
    $r[$i]["text"] = "1280x1024";
    $i++;
    $r[$i]["code"] = "1024x768";
    $r[$i]["text"] = "1024x768";
    $i++;
    $r[$i]["code"] = "800x600";
    $r[$i]["text"] = "800x600";
    $i++;
    $r[$i]["code"] = "640x480";
    $r[$i]["text"] = "640x480";
    $i++;
    return ($r);
  }

  function parse_ks_frompost($p) {
    $c = array();
    $c["basic"] = $p["1"];
    $c["install"] = $p["2"];
    $c["install2"] = $p["3"];
    $c["boot"] = $p["4"];
    $c["disk"] = $p["5"];
    $c["net"] = $p["6"];
    $c["auth"] = $p["7"];
    $c["auth2"] = $p["8"];
    $c["x"] = $p["9"];
    $c["pkg"] = $p["10"];
    $c["prepost"] = $p["11"];
    $ks = array();
    $ks[] = "# Generated by OneClickKick web generator";
    if ($p) {
      $ks[] = "#";
      $ks[] = "# Basic configuration";
      $ks[] = "#";
      foreach ($c["basic"] as $k => $v) {
        if ($k == "reboot" || $k == "interactive" || $k == "text") {
          $ks[] = "$k";
        }
        elseif ($k == "timezone" && $c["basic"]["utc"] == "on") {
          $ks[] = "$k --utc $v";
        }
        elseif ($k == "utc" || $k == "emulate3buttons") {
        }
        elseif ($k == "key" && $v == "") {
	  $ks[] = "key --skip";
	}
        else {
          $ks[] = "$k $v";
       }
      }
      if ($c["install"]["install"] == "cdrom") $ks[] = "cdrom";
      if ($c["install"]["install"] == "nfs") $ks[] = "nfs --server ".$c["install2"]["server"]." --dir ".$c["install2"]["directory"];
      if ($c["install"]["install"] == "ftp" && $c["install2"]["ftpuser"]) $ks[] = "url --url ftp://" . $c["install2"]["ftpuser"] . ':' . $c["install2"]["ftppasswd"] . '@' . $c["install2"]["server"] . "/" . $c["install2"]["directory"]; 
      elseif ($c["install"]["install"] == "ftp") { $ks[] = "url --url ftp://".$c["install2"]["server"]."/".$c["install2"]["directory"]; }
      if ($c["install"]["install"] == "http") { $ks[] = "url --url http://".$c["install2"]["server"]."/".$c["install2"]["directory"]; }
      if ($c["install"]["install"] == "hd") { $ks[] = "harddisk --partition ".$c["install2"]["partition"]." --directory ".$c["install2"]["directory"]; }
  
      $ks[] = "#";
      $ks[] = "# Boot loader & partitions";
      $ks[] = "#";
      $btldr = "bootloader --location=" . $c["boot"]["bootloader"];
      if ($c["boot"]["append"]) $btldr .= " --append " . $c["boot"]["append"];
      $ks[] = $btldr;

      if ($c["boot"]["zerombr"] == "yes") $ks[] = "zerombr yes";

      $clearpart = "clearpart --" . $c["boot"]["clearpart"];
      if ($c["boot"]["initlabel"] == "yes") $clearpart .= " --initlabel";
      $ks[] = $clearpart;

      $ks[] = "#";
      $ks[] = "# Disk configuration";
      $ks[] = "#";
      foreach ($c["disk"]["disks"] as $k => $v) {
        unset($popt);
        if ($v["sizeopts"] == "grow") $popt .= " --grow";
        if ($v["growsize"]) $popt .= " --growsize=".$v["growsize"];
        if ($v["ondiskval"]) $popt .= " --ondisk=".$v["ondiskval"];
        if ($v["onpartval"]) $popt .= " --onpart=".$v["onpartval"];
        if ($v["asprimary"] == "on") $popt .= " --asprimary";
        if ($v["format"] != "on") $popt .= " --noformat";
	if ($v["filesystem"] == "swap") {
	  $ks[] = "part swap --size ".$v["size"].$popt;
	}
	else {
          $ks[] = "part ".$v["mountpoint"]." --fstype ".$v["filesystem"]." --size ".$v["size"].$popt;
	}
      }

      $ks[] = "#";
      $ks[] = "# Network interface configuration";
      $ks[] = "#";
      foreach ($c["net"]["iface"] as $k => $v) {
        unset($pop);
        if ($v["type"] == "dhcp") $ks[] = "network --bootproto=dhcp --device=".$v["ifname"];
        if ($v["type"] == "static") $ks[] = "network --bootproto=static --device=".$v["ifname"]." --ip=".$v["ipaddress"]." --netmask=".$v["netmask"]." --gateway=".$v["gateway"]." --nameserver=".$v["nameserver"];
      }

      $ks[] = "#";
      $ks[] = "# Authentication";
      $ks[] = "#";
      $ks[] = "rootpw --iscrypted ".crypt($c["auth"]["rootpassword"],CRYPT_MD5);
      $auth = "auth";
      if ($c["auth"]["shadow"] == "on") $auth .= " --useshadow";
      if ($c["auth"]["md5"] == "on") $auth .= " --enablemd5";
      if ($c["auth"]["nis"] == "on") {
        $auth .= " --enablenis";
        $auth .= " --nisdomain ".$c["auth2"]["nisdomain"];
        if ($c["auth2"]["nisbroadcast"] != "on") {
          $auth .= " --nisserver ".$c["auth2"]["nisserver"];
        }
      }
      if ($c["auth"]["ldap"] == "on") {
        $auth .= " --enableldap --enableldapauth";
        $auth .= " --ldapserver ".$c["auth2"]["ldapserver"];
        $auth .= " --ldapbasedn ".$c["auth2"]["ldapbase"];
      }
      if ($c["auth"]["krb5"] == "on") {
        $auth .= " --enablekrb5";
        $auth .= " --krb5realm ".$c["auth2"]["krbrealm"];
        $auth .= " --krb5kdc ".$c["auth2"]["krbkdc"];
        $auth .= " --krb5adminserver ".$c["auth2"]["krbmaster"];
      }
      if ($c["auth"]["hesiod"] == "on") {
        $auth .= " --enablehesiod";
        $auth .= " --hesiodlhs ".$c["auth2"]["hesiodlhs"];
        $auth .= " --hesiodrhs ".$c["auth2"]["hesiodrhs"];
      }
      if ($c["auth"]["smb"] == "on") {
        $auth .= " --enablesmbauth";
        $auth .= " --smbservers ".$c["auth2"]["smbservers"];
        $auth .= " --smbworkgroup ".$c["auth2"]["smbworkgroup"];
      }
      if ($c["auth"]["nscd"] == "on") $auth .= " --enablecache";
      $ks[] = $auth;

      if ($c["auth"]["firewall"] == "on") $ks[] = "firewall --enabled";
      if ($c["auth"]["firewall"] != "on") $ks[] = "firewall --disabled";

      # Firstuser
      if ($c["auth"]["user"]) $ks[] = "user ".$c["auth"]["user"]." --fullname \"".$c["auth"]["userfname"]."\" --iscrypted --password ".crypt($c["auth"]["userpassword"],CRYPT_MD5);

      $ks[] = "#";
      $ks[] = "# X Window System";
      $ks[] = "#";
      if ($c["x"]["configurex"] == "on") {
        $xconfig = "xconfig";
        if ($c["x"]["depth"] != "auto") $xconfig .= " --depth=".$c["x"]["depth"];
        if ($c["x"]["resolution"] != "auto") $xconfig .= " --resolution=".$c["x"]["resolution"];
        $xconfig .= " --defaultdesktop=".$c["x"]["desktop"];
        if ($c["x"]["startx"] == "on") $xconfig .= " --startxonboot";
        $ks[] = $xconfig;
        if ($c["x"]["xfirstboot"] == "enabled") $ks[] = "firstboot --enable";
      }

      $ks[] = "#";
      $ks[] = "# Packages";
      $ks[] = "#";
      $ks[] = "%packages";
      foreach(explode("\n", $c["pkg"]["packages"]) as $k => $v) {
        $ks[] = "$v";
      }
      if ($_SESSION["ks"]["cfg"]["ver"] >= 6) {
        $ks[] = "%end";
      }

      $ks[] = "#";
      $ks[] = "# Pre/post configuration";
      $ks[] = "#";
      $pre = "%pre";
      if ($c["prepost"]["preshell"]) $pre .= " --interpreter=".$c["prepost"]["preshell"];
      $ks[] = $pre;
      foreach(explode("\n", $c["prepost"]["prescript"]) as $k => $v) {
        $ks[] = "$v";
      }
      if ($_SESSION["ks"]["cfg"]["ver"] >= 6) {
        $ks[] = "%end";
      }

      $post = "%post";
      if ($c["prepost"]["outsidechroot"] == "on") $post .= " --nochroot";
      if ($c["prepost"]["postshell"]) $post .= " --interpreter=".$c["prepost"]["postshell"];
      $ks[] = $post;
      foreach(explode("\n", $c["prepost"]["postscript"]) as $k => $v) {
        $ks[] = "$v";
      }
      if ($_SESSION["ks"]["cfg"]["ver"] >= 6) {
        $ks[] = "%end";
      }
    }
    return $ks;
  }

}


?>
