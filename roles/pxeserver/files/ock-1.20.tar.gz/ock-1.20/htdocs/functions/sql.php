<?php

$sql = mysql_connect("$sqlhost","$sqluser","$sqlpwd");
mysql_select_db("$sqldb", $sql);

?>
