<?php

// Funnctions to execute IPA commands using the kerberos kredentials of the logged on user

class ipa {

  function verify() {
    if (isset($_SERVER["AUTH_TYPE"]) && ($_SERVER["AUTH_TYPE"] == "Negotiate" ||  $_SERVER["AUTH_TYPE"] == "Basic") && isset($_SERVER["KRB5CCNAME"])) {
      // make the kerberos cache of the currently logged on user available
      putenv("KRB5CCNAME={$_SERVER['KRB5CCNAME']}");
    }
    else {
      $ret["val"] = 255;
      $ret["txt"] = "Failed, not authenticated with kerberos";
      return $ret;
    }

    if (isset($_SESSION["CFG"]["ipacmd"]) && is_executable($_SESSION["CFG"]["ipacmd"])) {
      $ret["val"] = 0;
    }
    else {
      $ret["val"] = 255;
      $ret["txt"] = "Failed, the path to the ipa executable is not defined in the configuration, it is not found, or it is not executable.";
      return $ret;
    }

    $ret["val"] = 0;
    return $ret;
  }

  function host_find_next_ipv4($subnet, $start=0) {
    for ($i=1; $i < 256; $i++) {
      if ($start > 0 && $i < $start) continue;
      $ip = $subnet . "." . $i;
      if (gethostbyaddr("$ip") == $ip) {
        exec("ping -c 1 -W 1 $ip", $ping_result, $pr);
        if ($pr == 1) return $ip;
      }
    }
    return false;
  }

  function host_add($hostname, $input, $ipaddr=0, $autoip=0) {
    $verify = $this->verify();

    if ($verify["val"] == "0") {

      // Build ipa command to run
      $ipa_otp = rand_string(32);
      $cmd = $_SESSION["CFG"]["ipacmd"];
      $cmd .= " host-add " . escapeshellarg("$hostname");
      if ($ipaddr == "0") {
        $cmd .= " --force";
      }
      else {
        $cmd .= " --ip-address=" . escapeshellarg($ipaddr);
      }
      $cmd .= " --password=" . escapeshellarg($ipa_otp) . " 2>&1";
      $strings = array ("desc", "locality", "location", "platform", "os", "macaddress");
      foreach ($strings as $str) {
        if ($str == "macaddress") $input["macaddress"] = $input["ether"];
        if (isset($input["$str"])) $cmd .= " --$str=" . escapeshellarg($input["$str"]);
      }

      // Execute
      exec($cmd, $out, $retval);
  
      $ret["val"] = $retval;
      $ret["txt"] = $out;
      $ret["cmd"] = $cmd;
      $ret["ipa_otp"] = $ipa_otp;

      if ($retval == "0") {
        $ether = $input["ether"];
        writelog("info","Host $hostname with MAC address $ether added to the IPA database","","");
      }

      return $ret;
    }
    else {
      return $verify;
    }
  }

}

?>
