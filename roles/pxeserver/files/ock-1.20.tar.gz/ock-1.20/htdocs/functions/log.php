<?php

/*
 * Function to write a log entry
 *
 * $logname = security/kickstart/error, etc. See table logtype.
 * $data = data to enter in the log
 * $refid = id to reference, e.g. $logname=security will use a userid, $logname=kickstart will use a hostname
 * $logcomment = currently unused
*/

function writelog($logname,$data,$refid,$logcomment,$user=NULL,$remoteip=NULL) {
  global $sql;
  $q = "select id,refidcol,refidtbl from logtype where logname=\"$logname\"";
  $result = mysql_query("$q", $sql);
  $r = mysql_fetch_array($result); 
  $logtypeid = $r["id"];
  $refidcol = $r["refidcol"];
  $refidtbl = $r["refidtbl"];
  $q = "select $refidcol as ref from $refidtbl where id=$refid";
  $result = mysql_query("$q", $sql);
  if (mysql_num_rows($result) > 0) {
    $r = mysql_fetch_array($result); 
    $ref = $r["ref"];
  }
  if (!isset($comment)) $comment = NULL;
  if (is_null($user)) $user = $_SESSION["USERNAME"];
  if (is_null($remoteip) && isset($_SERVER["REMOTE_ADDR"])) $remoteip = $_SERVER["REMOTE_ADDR"];
  if (is_null($remoteip) && isset($_SERVER["HOSTNAME"])) $remoteip = gethostbyname($_SERVER["HOSTNAME"]);

  $q = "insert into log (logtypeid,data,comment,refid,ref,user,remoteip,remotehost) values 
	($logtypeid, \"$data\", \"$comment\", \"$refid\", \"$ref\", \"". $user ."\", \"" . $remoteip ."\", \"" . gethostbyaddr($remoteip) . "\")";
  $result = mysql_query("$q", $sql);
  if (mysql_affected_rows() == 1) {
    $ret = 0;
  }
  else {
    $ret = 13;
  }
  return $ret;
}

function listlog($logname,$data,$refkey,$ref,$loguser,$logremoteip,$logremotehost,$limit) {
  global $sql;
  $q = "select * from v_log where logid != ''";
  if ($logname) $q .= "and logname=\"$logname\"";
  if ($data) $q .= "and data LIKE \"$data\"";
  if ($ref) $q .= "and ref LIKE \"$ref\"";
  if ($refidcol) $q .= "and refidcol LIKE \"$refidcol\"";
  if ($loguser) $q .= "and loguser LIKE \"$loguser\"";
  if ($logremoteip) $q .= "and logremoteip LIKE \"$logremoteip\"";
  if ($logremotehost) $q .= "and logremotehost LIKE \"$logremotehost\"";
  if ($refid) $q .= "and refid LIKE \"$refid\"";
  if (isset($limit) && $limit == "all") {
    // Do nothing
  }
  elseif (isset($limit)) {
    $q .= "limit $limit";
  }
  else {
    $q .= "limit 50";
  }
  $result = mysql_query("$q", $sql);
  $ret = array();
  $i = 0;
  while ($r = mysql_fetch_array($result)) {
    foreach($r as $key => $val) {
      $ret[$i][$key] = $val;
      if ($key == "refidcol") {
	$col = $val;
      }
      elseif ($key == "refidtbl") {
        $tbl = $val;
      }
        //list($tbl, $col) = split("\.", $val, 32);
    }
    $q2 = "select $col from $tbl where $tbl.id = " . $ret[$i]["refid"];
    $result2 = mysql_query("$q2", $sql); if ($result2) $r2 = mysql_fetch_array($result2);  $ret[$i]["refdata"] = $r2[$col];
    if ($ret[$i]["refdata"] == "") $ret[$i]["refdata"] = "*" . $ret[$i]["ref"] ;
    $i++;
  }
  return $ret;
}

function listlognames() {
  global $sql;
  $q = "select id,logname,comment,refidcol from logtype";
  $result = mysql_query("$q", $sql);
  if ($result) {
    $ret = array();
    $i = 0;
    while ($r = mysql_fetch_array($result)) {
      $ret[$i]["id"] = $r["id"];
      $ret[$i]["logname"] = $r["logname"];
      $ret[$i]["comment"] = $r["comment"];
      $ret[$i]["refidcol"] = $r["refidcol"];
      $i++;
    }
  }
  if ($ret) {
    return $ret;
  }
  else {
    return 14;
  }
}

function listsearchkeys() {
  $ret = array();
  $i = 0;
  $ret[$i]["key"] = "ref";
  $ret[$i]["name"] = "Item";
  $i++;

  $ret[$i]["key"] = "user";
  $ret[$i]["name"] = "Username";
  $i++;

  $ret[$i]["key"] = "remoteip";
  $ret[$i]["name"] = "User IP";
  $i++;

  $ret[$i]["key"] = "remotehost";
  $ret[$i]["name"] = "User host";
  $i++;

  return $ret;
}

function listsearchlimit() {
  $ret = array();
  $i = 0;
  $ret[$i]["key"] = "50";
  $ret[$i]["name"] = "50";
  $i++;

  $ret[$i]["key"] = "100";
  $ret[$i]["name"] = "100";
  $i++;

  $ret[$i]["key"] = "500";
  $ret[$i]["name"] = "500";
  $i++;

  $ret[$i]["key"] = "1000";
  $ret[$i]["name"] = "1000";
  $i++;

  $ret[$i]["key"] = "all";
  $ret[$i]["name"] = "All";
  $i++;

  return $ret;
}
?>
