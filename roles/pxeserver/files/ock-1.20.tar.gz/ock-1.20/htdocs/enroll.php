<?php

session_start();

include("conf/config.php");
require("functions/log.php");
include("functions/naming.php");
include("functions/dhcp.php");
include("functions/pxe.php");
include("functions/general.php");
include("include/backports.php");
include("functions/ockd.php");
include("functions/cache.php");
include("functions/ipa.php");

$heading = "OneClickKick Enrollment";

if ($_GET["a"] == "auth") {
  include("functions/auth.php");
  if (isset($_POST["username"])) {
    $auth = auth_user($_POST["username"],$_POST["password"]);
    if ($auth == 0) {
      $_SESSION["SESSID"] = session_id();
          if (getenv("HTTP_X_FORWARDED_FOR")){
            $_SESSION["IPADDR"]=getenv("HTTP_X_FORWARDED_FOR");
          }
          else {
            $_SESSION["IPADDR"]=getenv("REMOTE_ADDR");
          }
      header("Location: " . $_SERVER["PHP_SELF"] . "?a=addhost");
    }
    else {
      header("Location: " . $_SERVER["PHP_SELF"] . "?msg=failed");
    }
  }
}
elseif ($_GET["a"] == "addhost") {

  $q = "select item,value from config where 
	item=\"enrollment_hostname_prefix\" 
	or item=\"enrollment_hostname_auto_suffix\"
	or item=\"enrollment_hostname_domain\"
	or item=\"enrollment_default_dhcp_group_id\"";
  $result = mysql_query("$q", $sql);
  if (mysql_num_rows($result) > 0) {
    while ($r = mysql_fetch_array($result)) {
      if ($r["item"] == "enrollment_hostname_prefix") $enrollment_hostname_prefix = $r["value"];
      if ($r["item"] == "enrollment_hostname_auto_suffix") $enrollment_hostname_auto_suffix = $r["value"];
      if ($r["item"] == "enrollment_hostname_domain") $enrollment_hostname_domain = $r["value"];
      if ($r["item"] == "enrollment_default_dhcp_group_id") $enrollment_default_dhcp_group_id = $r["value"];

    }
  }

  $ipa = new ipa();

  //$default_hostname = "$enrollment_hostname_prefix.$enrollment_hostname_domain";
  $default_hostname = host_get_next_default_hostname($_SESSION["get"]["system-serial-number"]);
  $pheading = "Please configure host<br>";


  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Hostname";
  $j++;
  $list[$i][$j]["type"] = "input";
  $list[$i][$j]["name"] = "hostname";
  $list[$i][$j]["data"] = $default_hostname;
  $i++;

  if ($_SESSION["CFG"]["ldap_ipa"] == "1") {
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Description";
    $j++;
    $list[$i][$j]["type"] = "input";
    $list[$i][$j]["name"] = "desc";
    $i++;
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Platform";
    $j++;
    $list[$i][$j]["type"] = "input";
    $list[$i][$j]["name"] = "platform";
    $list[$i][$j]["data"] = urldecode($_SESSION["get"]["system-name"]);
    $i++;
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "OS";
    $j++;
    $list[$i][$j]["type"] = "input";
    $list[$i][$j]["name"] = "os";
    $list[$i][$j]["data"] = urldecode($_SESSION["get"]["os"]);
    $i++;
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Location";
    $j++;
    $list[$i][$j]["type"] = "input";
    $list[$i][$j]["name"] = "location";
    $list[$i][$j]["data"] = urldecode($_SESSION["get"]["location"]);
    $i++;
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Locality";
    $j++;
    $list[$i][$j]["type"] = "input";
    $list[$i][$j]["name"] = "locality";
    $list[$i][$j]["data"] = urldecode($_SESSION["get"]["locality"]);
    $i++;
    $j=0;
  
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Assign IP in subnet";
    $j++;
    $list[$i][$j]["type"] = "dropbox";
    $list[$i][$j]["name"] = "subnetid";
    $dhcpsubnets = dhcp_subnets();
    $list[$i][$j]["data"][0]["value"] = "0";
    $list[$i][$j]["data"][0]["text"] = "Do not assign an IP address";
    for ($z=0; $z < count($dhcpsubnets); $z++) {
      if ($dhcpsubnets[$z]["id"] == 0) continue;
      $list[$i][$j]["data"][$z]["value"] = $dhcpsubnets[$z]["id"];
      $list[$i][$j]["data"][$z]["text"] = $dhcpsubnets[$z]["descr"] . " (" . $dhcpsubnets[$i]["subnet"] . "/" . $dhcpsubnets[$i]["netmask"] . ")";
  
    }
    $i++;
  }

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Ethernet card";
  $j++;
  $list[$i][$j]["type"] = "dropbox";
  $list[$i][$j]["name"] = "ether";
  $z = 0;
  foreach ($_SESSION["get"] as $key => $value) {
    if ($key == "a") continue;
    if ($key == "system-serial-number") continue;
    if ($key == "system-name") continue;
    $list[$i][$j]["data"][$z]["value"] = $value;
    $list[$i][$j]["data"][$z]["text"] = "$key ($value)";
    $z++;
  }
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "DHCP Group";
  $j++;
  $list[$i][$j]["type"] = "dropbox";
  $list[$i][$j]["name"] = "dhcpgroupid";
  $dhcp_groups = dhcp_groups();
  for ($z=0; $z < count($dhcp_groups); $z++) {
    $list[$i][$j]["data"][$z]["value"] = $dhcp_groups[$z]["id"];
    $list[$i][$j]["data"][$z]["text"] = $dhcp_groups[$z]["groupname"];
    if ($enrollment_default_dhcp_group_id == $dhcp_groups[$z]["id"]) $list[$i][$j]["data"][$z]["selected"] = 1;
  }
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Database";
  $j++;
  $list[$i][$j]["type"] = "dropbox";
  $list[$i][$j]["name"] = "database";
  $z = 0;
  if ($_SESSION["CFG"]["ldap_ipa"] == "1") {
    $list[$i][$j]["data"][$z]["value"] = "ipa";
    $list[$i][$j]["data"][$z]["text"] = "IPA";
    $z++;
  }
  $list[$i][$j]["data"][$z]["value"] = "mysql";
  $list[$i][$j]["data"][$z]["text"] = "MySQL";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "PXE enable now";
  $j++;
  $list[$i][$j]["type"] = "checkbox";
  $list[$i][$j]["name"] = "pxeenablenow";
  $list[$i][$j]["checked"] = 1;

//  echo "<pre>"; print_r($list); echo "</pre>";


  $btext = " *) Will be stored in IPA if IPA is enabled<br>";

  $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?a=verify");
  $smarty->assign('listsubmitbox', "Add host");


}
elseif ($_GET["a"] == "verify") {

  $pheading = "Please verify host enrollment details ";

  $_SESSION["host"] = $_POST;
  $dhcpgroupinfo = dhcp_groupinfo($_SESSION["host"]["dhcpgroupid"]);

  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Hostname";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = $_SESSION["host"]["hostname"];
  $i++;

  if ($_SESSION["CFG"]["ldap_ipa"] == "1") {

    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Description";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $_SESSION["host"]["desc"];
    $i++;
  
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Platform";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $_SESSION["host"]["platform"];
    $i++;
  
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "OS";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $_SESSION["host"]["os"];
    $i++;
  
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Location";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $_SESSION["host"]["location"];
    $i++;
    
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Locality";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $_SESSION["host"]["locality"];
    $i++;
   
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "Subnet";
    $j++;
    $list[$i][$j]["type"] = "text";
    if ($_SESSION["host"]["subnetid"] == "0") {
      $list[$i][$j]["data"] = "Do not assign an IP address";
    }
    else {
      $dhcpsubnets = dhcp_subnets();
      $subnetid = $_SESSION["host"]["subnetid"];
      //echo "<pre>"; print_r($dhcpsubnets); echo "</pre>";
      for($z=0; $z < count($dhcpsubnets); $z++) {
        if ($dhcpsubnets[$z]["id"] == $subnetid) $subnet=$dhcpsubnets[$z];
      }
      $list[$i][$j]["data"] = $subnet["descr"] . " (" . $subnet["subnet"] . "/" . $subnet["netmask"] . ")";
    }
  
    $i++;

  }
 
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Ethernet card";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = $_SESSION["host"]["ether"];
  $i++;
 
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "DHCP Group";
  $j++;
  $list[$i][$j]["type"] = "text";
  $dhcpgroupinfo = dhcp_groupinfo($_SESSION["host"]["dhcpgroupid"]);
  $list[$i][$j]["data"] = $dhcpgroupinfo["name"];
  $i++;
 
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Database";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = strtoupper($_SESSION["host"]["database"]);
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "PXE enable now";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = strtoupper($_SESSION["host"]["pxeenablenow"]);
  $i++;
 
  $hostdetails = host_details_byname($_SESSION["host"]["hostname"]);
  if (isset ($hostdetails["ether"])) {
    $fail = 1;
    //$text .= "ERROR: Host already exists <br />";
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "&nbsp;";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "&nbsp;";
    $i++;
 
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "&nbsp;";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<b>ERROR: Host already exists</b>";
    $i++;
 
  }

  $etherdetails = host_name_byether($_SESSION["host"]["ether"], 1);

  if (isset ($etherdetails["host"])) {
    $fail = 1;
    //$text .= "ERROR: MAC address already exists with host " . $etherdetails["host"] . " <br />";
    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "&nbsp;";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "&nbsp;";
    $i++;
 

    $j=0;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "&nbsp;";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<b>ERROR: MAC address already exists with host " . $etherdetails["host"] . "</b>";
    $i++;
 

  }

  if (isset($fail) && $fail == 1) {
    $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?a=addhost");
    $smarty->assign('listsubmitbox', "Go back");
  }
  else {
    $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?a=complete");
    $smarty->assign('listsubmitbox', "Add host");
  }

  //echo "<pre>"; print_r($etherdetails); echo "</pre>";

}
elseif ($_GET["a"] == "complete") {

  $pheading = "Result of host enrollment process ";
  $dhcpgroupinfo = dhcp_groupinfo($_SESSION["host"]["dhcpgroupid"]);

  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Hostname";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = $_SESSION["host"]["hostname"];
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Ethernet card";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = $_SESSION["host"]["ether"];
  $i++;
 
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "DHCP Group";
  $j++;
  $list[$i][$j]["type"] = "text";
  $dhcpgroupinfo = dhcp_groupinfo($_SESSION["host"]["dhcpgroupid"]);
  $list[$i][$j]["data"] = $dhcpgroupinfo["name"];
  $i++;
 
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Database";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = strtoupper($_SESSION["host"]["database"]);
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "PXE enable now";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = strtoupper($_SESSION["host"]["pxeenablenow"]);
  $i++;
 
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "RESULT";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Add host to database";
  $j++;
  $list[$i][$j]["type"] = "text";
 
  $text .= "RESULT: <br />";
  if ($_SESSION["host"]["database"] == "mysql") {
    $hostadd = host_add($_SESSION["host"]["hostname"], $_SESSION["host"]["ether"], $_SESSION["host"]["dhcpgroupid"], "sql");
    if ($hostadd == "0") {
      //$text .=  " - Host added successfully to database <br />";
      $list[$i][$j]["data"] = "OK";
      $hostaddok = 1;
    }
    else {
      //$text .=  " - ERROR: Could not add host to database: $hostadd <br />";
      $list[$i][$j]["data"] = "ERROR";
    }
  }
  elseif ($_SESSION["host"]["database"] == "ipa") {
    if ($_GET["ipacmd"] == "done") {
      $status = $_SESSION["IPACMD"]["RESULT"]["errcode"];
      if ($status == "0") {
        $hostaddok = "1";
        //$text .=  " - Host added successfully to database <br />";
        $list[$i][$j]["data"] = "OK";
      }
      else {
        $status = $_SESSION["IPACMD"]["RESULT"]["text"];
        //$text .=  " - ERROR: Could not add host to database: " . $_SESSION["IPACMD"]["RESULT"]["errcode"] . " <br />";
        $list[$i][$j]["data"] = "ERROR: " . $_SESSION["IPACMD"]["RESULT"]["errcode"];
        if (is_array($_SESSION["IPACMD"]["RESULT"]["text"])) {
          foreach ($_SESSION["IPACMD"]["RESULT"]["text"]["txt"] as $val) {
            $list[$i][$j]["data"] .= $val . "<br>";
            //$text .= $val . "<br>";
          }
        }
      }
    }
    else {
      $_SESSION["IPACMD"]["redir"] = $_SERVER["PHP_SELF"] . "?a=complete&ipacmd=done";
      //if (isset($_SESSION["pxeenablenow"])) $_SESSION["IPACMD"]["redir"] .= "&pxeenablenow=true";
     // foreach ($_SESSION["host"] as $key => $value) {
     //   $_SESSION["IPACMD"]["POST"]["$key"] = $_SESSION["host"]["$key"];
     // }
      $_SESSION["IPACMD"]["POST"] = $_SESSION["host"];
      $_SESSION["IPACMD"]["POST"]["host"] = $_SESSION["host"]["hostname"];

//echo "<pre>"; print_r($_SESSION);
      $status = host_add($_SESSION["host"]["hostname"], $_SESSION["host"]["ether"], $_SESSION["host"]["dhcpgroupid"], "ipa");
    } 
  }
  $i++;
//echo "<pre>"; print_r($_SERVER);

//echo "<pre>"; print_r($_SESSION);

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "PXE enable host";
  $j++;
  $list[$i][$j]["type"] = "text";
 
  if ($_SESSION["host"]["pxeenablenow"] == "on" && $hostaddok == "1") {
    sleep(3);
    $hostgroup = host_group($_SESSION["host"]["hostname"]);
    $pxeenable = pxe_enable_client($hostgroup["dhcpgroupmemid"],$hostgroup["pxeprofileid"]);
    if ($pxeenable == 0) {
      //$text .=  " - Host PXE enabled successfully <br />";
      $list[$i][$j]["data"] = "OK";
    }
    else {
      //$text .=  " - ERROR: Host coult not be PXE enabled: " . errormsg($pxeenable) . " <br />";
      $list[$i][$j]["data"] = "ERROR: " . errormsg($pxeenable);
    } 
  }
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<b>Please reboot your computer</b>";
  $i++;
 
  //$text .=  "<br />";
  //$text .= "Please reboot your computer <br />";

} 

else {

  $pheading = "Please log in ";
  if (isset($_GET["msg"]) && $_GET["msg"] == "failed") $pheading .= " - login failed";

  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "&nbsp;";
  $i++;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Username";
  $j++;
  $list[$i][$j]["type"] = "input";
  $list[$i][$j]["name"] = "username";
  $i++;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Password";
  $j++;
  $list[$i][$j]["type"] = "password";
  $list[$i][$j]["name"] = "password";
  $j++;


  $_SESSION["get"] =  $_GET;

  $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?a=auth");
  $smarty->assign('listsubmitbox', "Log in");

  //print_r($_GET);

}

if (!isset($btext)) $btext = "<br />";
$btext .= "<br />";
$btext .= "<br />";
$btext .= date(DATE_COOKIE) . "<br />";

$smarty->assign('heading', $heading);
$smarty->assign('htext', $htext);
$smarty->assign('pheading', $pheading);
$smarty->assign('text', $text);
$smarty->assign('btext', $btext);
$smarty->assign('list', $list);
$smarty->assign('nomenu', 'yes');


$smarty->display("$template/table.tpl");

//print_r($_SERVER);

?>
