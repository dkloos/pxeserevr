<?php

// First thing first, let's start the session
session_start();

if ((isset($_SERVER["AUTH_TYPE"]) && $_SERVER["AUTH_TYPE"] == "Negotiate") && (isset($_SERVER["REMOTE_USER"])) && (!isset($_GET["logout"]))) {
    $split_user = explode('@', $_SERVER["REMOTE_USER"]);
    $_SESSION["SSO"]["AUTH_TYPE"] = "Negotiate";
    $_SESSION["SSO"]["REMOTE_USER"] = $split_user[0];

    header("Location: ../");

}
else {
  header("Location: ../index.php?kerbauth=failed");
}
?>
