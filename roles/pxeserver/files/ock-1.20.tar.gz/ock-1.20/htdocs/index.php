<?php

//top of your page 
$gentime = microtime(); 
$gentime = explode(' ',$gentime); 
$gentime = $gentime[1] + $gentime[0]; 
$pg_start = $gentime;

// First thing first, let's start the session
session_start();

if (is_file("conf/config.php")) {
  include("conf/config.php");
}
else {
  header("location: install.php?p=1");
}
// Remember to add functions to ockd.php!
include("functions/version.php");
require("functions/log.php");
include("functions/naming.php");
include("functions/dhcp.php");
include("functions/pxe.php");
include("functions/general.php");
include("include/backports.php");
include("functions/ockd.php");
include("functions/cache.php");

$ockd_cli = new ockd_client();
$ockd_alert = $ockd_cli->check_alert();
if (isset($ockd_alert) && $ockd_alert != "") $alert[]["text"] = $ockd_alert;

$pxe_alert = pxe_check_expired_clients();
if (isset($pxe_alert) && $pxe_alert != "") $alert[]["text"] = $pxe_alert;

// Assign the OCK version number
$smarty->assign('ockversion', $ockversion);

//$alert[]["text"] = "test1";
if (isset($alert) && isset($_SESSION[USERNAME])) {
  $smarty->assign('alert', $alert);
}
else {
  if (isset($_GET["kerbauth"]) && $_GET["kerbauth"] == "failed") {
    $alert[]["text"] = "Kerberos authentication enabled but failed. Please log in using username and password.";
    $smarty->assign('alert', $alert);
  }
}

// Default of 15 min (900 sec) timeout, no less than 60 seconds timeout is allowed.
if ($webtimeout < 60) $webtimeout=900;
$SESSTIMEOUT = mktime() + $webtimeout;

// Check for, and set config defaults
config_set_defaults();


if (isset($_SESSION["SESSID"]) && isset($_SESSION["USERNAME"]) && isset($_SESSION["USERID"]) && $_SESSION["SESSKEY"] == $SESSKEY && $_SESSION["SESSTIME"] < $SESSTIMEOUT) {

  $smarty->assign('display_user', $_SESSION["USERNAME"]);

  $_SESSION["SESSTIME"] = mktime();

  // If this is the first login, generate dhcp config and pxe boot defaults
  if ($firstlogin == "yes") {
    generate_dhcpd_conf();
    pxe_defaultfile_create();
    mysql_query("update config set value=\"no\" where item=\"firstlogin\"", $sql);
  }

  if (getenv("HTTP_X_FORWARDED_FOR")){
    $remipaddr=getenv("HTTP_X_FORWARDED_FOR");
  }
  else {
    $remipaddr=$_SERVER["REMOTE_ADDR"];
  }
  if($_SESSION["IPADDR"] != $remipaddr) {
    session_destroy();
    header("Location: " . $_SERVER["PHP_SELF"]);
  }
  if ($_GET["p"] == "hosts") {
    include("include/hosts.php");
  }
  elseif ($_GET["p"] == "dhcpg") {
    include("include/dhcpg.php");
  }
  elseif ($_GET["p"] == "pxep") {
    include("include/pxep.php");
  }
  elseif ($_GET["p"] == "dhcps") {
    include("include/dhcps.php");
  }
  elseif ($_GET["p"] == "dhcpr") {
    include("include/dhcpr.php");
  }
  elseif ($_GET["p"] == "users") {
    include("functions/users.php");
    include("include/users.php");
  }
  elseif ($_GET["p"] == "log") {
    include("include/log.php");
  }
  elseif ($_GET["p"] == "config") {
    include("include/config.php");
  }
  elseif ($_GET["p"] == "logout") {
    writelog("security","User logged out",$_SESSION["USERID"],"");
    session_destroy();
    header("Location: " . $_SERVER["PHP_SELF"] . "?logout=true");
  }
  else {
    header("Location: " . $_SERVER["PHP_SELF"] . "?p=hosts");
  }
}
else {
  include("functions/auth.php");
  if (isset($_POST["username"])) {
    $auth = auth_user($_POST["username"],$_POST["password"]);
    if ($auth == 0) {
      $_SESSION["SESSID"] = session_id();
          if (getenv("HTTP_X_FORWARDED_FOR")){
            $_SESSION["IPADDR"]=getenv("HTTP_X_FORWARDED_FOR");
          }
          else {
            $_SESSION["IPADDR"]=getenv("REMOTE_ADDR");
          }
      $text = "<h1>Login</h1>";
      $text .= "<br>";
      $text .= "<br><h3>You are successfully logged in as user \"" . $_POST["username"] . "\"</h3><br>";
      $text .= "<br>";
      $text .= "<br>";
      $text .= "<br>";
      $text .= "<h3>You will be redirected within a few seconds...</h3>";
    
      $smarty->assign('text', $text);
      $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
    
      $smarty->display("$template/text.tpl");
 
    }
    else {
      header("Location: " . $_SERVER["PHP_SELF"]);
    }
  }
  //elseif ((isset($_SERVER["AUTH_TYPE"]) && $_SERVER["AUTH_TYPE"] == "Negotiate") && (isset($_SERVER["REMOTE_USER"])) && (!isset($_GET["logout"]))) {
  elseif ((isset($_SESSION["SSO"]["AUTH_TYPE"]) && $_SESSION["SSO"]["AUTH_TYPE"] == "Negotiate") && (isset($_SESSION["SSO"]["REMOTE_USER"])) && (!isset($_GET["logout"]))) {

    //$split_user = explode('@', $_SERVER["REMOTE_USER"]);

    $auth = auth_user($_SESSION["SSO"]["REMOTE_USER"]);
    if ($auth == 0) {
      $_SESSION["SESSID"] = session_id();
      if (getenv("HTTP_X_FORWARDED_FOR")){
        $_SESSION["IPADDR"]=getenv("HTTP_X_FORWARDED_FOR");
      }
      else {
        $_SESSION["IPADDR"]=getenv("REMOTE_ADDR");
      }
      $text = "<h1>Single Sign On Login</h1>";
      $text .= "<br>";
      $text .= "<br><h3>You are successfully logged in as user \"" . $_SESSION["SSO"]["REMOTE_USER"] . "\"</h3><br>";
      $text .= "<br>";
      $text .= "<br>";
      $text .= "<br>";
      $text .= "<h3>You will be redirected within a few seconds...</h3>";
    
      $smarty->assign('text', $text);
      $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
    
      $smarty->display("$template/text.tpl");
    }
    else {
      //header("Location: " . $_SERVER["PHP_SELF"]);
      echo "Kerberos auth failed for user " . $split_user[0];
    }

  }
  elseif ( 
	(isset($_SESSION["CFG"]["kerbauth"]) && $_SESSION["CFG"]["kerbauth"] == "1")
	&& 
	(!isset($_GET["kerbauth"])) 
	&& 
	(!isset($_GET["logout"])) 
	&&
	(!$_GET["p"] == "logout")
	 ) 
	{
    header("Location: kerbauth/");
  }
  else {
    $smarty->assign('pheading', "Login");
    $btext = "<script language=\"JavaScript\" type=\"text/javascript\">
function set_focus()
{
    document.forms[0].username.focus();
}

set_focus();
</script>";
    if (isset($htext)) $smarty->assign('btext', $htext);
    $list = array();
    $l = 0;
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "&nbsp;";
    $list[$l][1]["type"] = "text";
    $list[$l][1]["data"] = "&nbsp;";
    $l++;

    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "Username";
    $list[$l][1]["type"] = "input";
    $list[$l][1]["name"] = "username";
    $l++;

    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "Password";
    $list[$l][1]["type"] = "password";
    $list[$l][1]["name"] = "password";
    $l++;

    $smarty->assign('list', $list);
    $smarty->assign('listaction', $_SERVER["PHP_SELF"]);
    $smarty->assign('listsubmitbox', "Log in");

    //end of your page 
    $gentime = microtime(); 
    $gentime = explode(' ',$gentime); 
    $gentime = $gentime[1] + $gentime[0]; 
    $pg_end = $gentime; 
    $totaltime = ($pg_end - $pg_start); 
    $showtime = number_format($totaltime, 4, '.', ''); 

    $smarty->assign('nomenu', 'yes');

    $smarty->assign('showtime', "2");
    $smarty->display("$template/table.tpl");
  }
}


?>
