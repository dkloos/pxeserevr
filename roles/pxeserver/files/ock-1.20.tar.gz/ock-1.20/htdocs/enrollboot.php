#!/bin/bash
for x in $(cat /proc/cmdline); do
	case $x in
	ockenrollurl=*)
		ockenrollurl=${x#ockenrollurl=}
		;;
	esac
done

for mac in `/sbin/ifconfig -a|grep HWaddr|awk '{print $1"="$5}'`; do
  if [ -z $MACS ]; then
    MACS="$mac"
  else
    MACS="$MACS&$mac"
  fi
done

SYSTEM_SERIAL="`sudo dmidecode -s system-serial-number`"
SYSTEM_SERIAL="system-serial-number=$SYSTEM_SERIAL"

ARGS="$MACS&$SYSTEM_SERIAL"

firefox http://<?php include("conf/config.php"); echo $webui_hostname . "/" . $webroot; ?>/enroll.php?$ARGS
