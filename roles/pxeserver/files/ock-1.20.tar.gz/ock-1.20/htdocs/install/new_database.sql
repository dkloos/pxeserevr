-- MySQL dump 10.11
--
-- Host: localhost    Database: ock_em
-- ------------------------------------------------------
-- Server version	5.0.58

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boottype`
--

DROP TABLE IF EXISTS `boottype`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `boottype` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `boottype`
--

LOCK TABLES `boottype` WRITE;
/*!40000 ALTER TABLE `boottype` DISABLE KEYS */;
INSERT INTO `boottype` (`id`, `name`) VALUES (1,'No-auto-boot');
INSERT INTO `boottype` (`id`, `name`) VALUES (2,'Kickstart');
/*!40000 ALTER TABLE `boottype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `config` (
  `id` int(11) NOT NULL auto_increment,
  `item` varchar(255) NOT NULL,
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`id`, `item`, `value`) VALUES (1,'template','default');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dhcpconf`
--

DROP TABLE IF EXISTS `dhcpconf`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dhcpconf` (
  `id` int(11) NOT NULL auto_increment,
  `dhcpsubnetid` int(11) default '0',
  `item` varchar(255) NOT NULL,
  `data` varchar(255) default NULL,
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dhcpconf`
--

LOCK TABLES `dhcpconf` WRITE;
/*!40000 ALTER TABLE `dhcpconf` DISABLE KEYS */;
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (102,0,'filename','/pxelinux.0','2010-09-30 18:07:53');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (22,0,'option grubmenu code 150 = text','','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (21,0,'update-static-leases','on','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (20,0,'do-forward-updates','true','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (19,0,'ddns-updates','on','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (18,0,'authoritative','','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (17,0,'ddns-domainname','default.oneclickkick.int','2009-05-14 17:36:27');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (16,0,'use-host-decl-names','true','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (15,0,'option domain-name','default.oneclickkick.int','2009-05-14 17:36:24');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (13,0,'allow','bootp','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (12,0,'allow','booting','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (11,0,'max-lease-time','43200','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (10,0,'default-lease-time','21600','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (7,0,'option domain-name-servers','192.168.0.1, 192.168.0.2','2009-05-14 17:38:03');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (6,1,'option routers','192.168.0.1','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (52,0,'option wpad-url code 252 = text','','2009-06-12 05:08:04');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (2,0,'allow','client-updates','0000-00-00 00:00:00');
INSERT INTO `dhcpconf` (`id`, `dhcpsubnetid`, `item`, `data`, `audit`) VALUES (1,0,'ddns-update-style','interim','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `dhcpconf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dhcpgroup`
--

DROP TABLE IF EXISTS `dhcpgroup`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dhcpgroup` (
  `id` int(11) NOT NULL auto_increment,
  `groupname` varchar(255) NOT NULL,
  `statichosts` int(1) default '0',
  `descr` varchar(255) default NULL,
  `pxeprofileid` int(11) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dhcpgroup`
--

LOCK TABLES `dhcpgroup` WRITE;
/*!40000 ALTER TABLE `dhcpgroup` DISABLE KEYS */;
INSERT INTO `dhcpgroup` (`id`, `groupname`, `statichosts`, `descr`, `pxeprofileid`) VALUES (1,'First default group',0,'Default group',3);
/*!40000 ALTER TABLE `dhcpgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dhcpgroupconf`
--

DROP TABLE IF EXISTS `dhcpgroupconf`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dhcpgroupconf` (
  `id` int(11) NOT NULL auto_increment,
  `dhcpgroupid` int(11) NOT NULL default '1',
  `item` varchar(255) NOT NULL,
  `value` varchar(255) default NULL,
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dhcpgroupconf`
--

LOCK TABLES `dhcpgroupconf` WRITE;
/*!40000 ALTER TABLE `dhcpgroupconf` DISABLE KEYS */;
/*!40000 ALTER TABLE `dhcpgroupconf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dhcpgroupmem`
--

DROP TABLE IF EXISTS `dhcpgroupmem`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dhcpgroupmem` (
  `id` int(11) NOT NULL auto_increment,
  `hostname` varchar(255) NOT NULL,
  `descr` varchar(255) default NULL,
  `dhcpgroupid` int(11) NOT NULL default '0',
  `statichost` int(1) default '0',
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `hostname` (`hostname`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dhcpgroupmem`
--

LOCK TABLES `dhcpgroupmem` WRITE;
/*!40000 ALTER TABLE `dhcpgroupmem` DISABLE KEYS */;
/*!40000 ALTER TABLE `dhcpgroupmem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dhcpsubnet`
--

DROP TABLE IF EXISTS `dhcpsubnet`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dhcpsubnet` (
  `id` int(11) NOT NULL auto_increment,
  `subnet` varchar(255) NOT NULL,
  `netmask` varchar(255) default NULL,
  `statichosts` int(1) default '0',
  `descr` varchar(255) default NULL,
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dhcpsubnet`
--

LOCK TABLES `dhcpsubnet` WRITE;
/*!40000 ALTER TABLE `dhcpsubnet` DISABLE KEYS */;
INSERT INTO `dhcpsubnet` (`id`, `subnet`, `netmask`, `statichosts`, `descr`, `audit`) VALUES (1,'192.168.1.0','255.255.255.0',0,'Default subnet','2010-09-06 20:45:41');
/*!40000 ALTER TABLE `dhcpsubnet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empty`
--

DROP TABLE IF EXISTS `empty`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `empty` (
  `empty` int(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `empty`
--

LOCK TABLES `empty` WRITE;
/*!40000 ALTER TABLE `empty` DISABLE KEYS */;
/*!40000 ALTER TABLE `empty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `error`
--

DROP TABLE IF EXISTS `error`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `error` (
  `id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `error`
--

LOCK TABLES `error` WRITE;
/*!40000 ALTER TABLE `error` DISABLE KEYS */;
INSERT INTO `error` (`id`, `message`) VALUES (0,'OK');
INSERT INTO `error` (`id`, `message`) VALUES (95,'File system error');
INSERT INTO `error` (`id`, `message`) VALUES (1,'Not found');
INSERT INTO `error` (`id`, `message`) VALUES (255,'General failure');
INSERT INTO `error` (`id`, `message`) VALUES (5,'Already exists');
INSERT INTO `error` (`id`, `message`) VALUES (6,'File did not upload');
INSERT INTO `error` (`id`, `message`) VALUES (7,'File size too large');
INSERT INTO `error` (`id`, `message`) VALUES (8,'DHCP restart failed');
INSERT INTO `error` (`id`, `message`) VALUES (9,'DHCP config test failed. Please examine the output for errors.');
INSERT INTO `error` (`id`, `message`) VALUES (10,'Could not add DHCP group config');
INSERT INTO `error` (`id`, `message`) VALUES (11,'Could not update DHCP group config');
INSERT INTO `error` (`id`, `message`) VALUES (12,'Cannot delete the super-user account');
INSERT INTO `error` (`id`, `message`) VALUES (13,'Failed to write to log');
INSERT INTO `error` (`id`, `message`) VALUES (14,'Could not retreive values from database');
INSERT INTO `error` (`id`, `message`) VALUES (15,'File/folder permission error');
INSERT INTO `error` (`id`, `message`) VALUES (16,'Not a valid boot image');
INSERT INTO `error` (`id`, `message`) VALUES (17,'Boot image already exists (folder name error)');
INSERT INTO `error` (`id`, `message`) VALUES (18,'Boot image is still in use by PXE profiles');
/*!40000 ALTER TABLE `error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ethers`
--

DROP TABLE IF EXISTS `ethers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ethers` (
  `host` varchar(255) NOT NULL,
  `ether` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ethers`
--

LOCK TABLES `ethers` WRITE;
/*!40000 ALTER TABLE `ethers` DISABLE KEYS */;
/*!40000 ALTER TABLE `ethers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ksconf`
--

DROP TABLE IF EXISTS `ksconf`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ksconf` (
  `id` int(11) NOT NULL auto_increment,
  `pxeprofileid` int(11) NOT NULL default '1',
  `parent` int(11) default '0',
  `data` varchar(255) default NULL,
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5667 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ksconf`
--

LOCK TABLES `ksconf` WRITE;
/*!40000 ALTER TABLE `ksconf` DISABLE KEYS */;
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6680,3,0,'%end','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6670,3,6581,'','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6671,3,0,'%end','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6672,3,6671,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6673,3,6671,'# Pre/post configuration','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6674,3,6671,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6675,3,0,'%pre','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6676,3,6675,'','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6677,3,0,'%end','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6678,3,0,'%post','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6679,3,6678,'echo \"This system was kickstarted by OneClickKick at `date`\" > /etc/motd','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6668,3,6581,'@X Window System','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6669,3,6581,'@iSCSI Storage Client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6667,3,6581,'@Web-Based Enterprise Management','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6666,3,6581,'@Web Servlet Engine','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6664,3,6581,'@Virtualization Client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6665,3,6581,'@Virtualization Platform','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6663,3,6581,'@TurboGears application framework','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6662,3,6581,'@Technical Writing','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6661,3,6581,'@TeX support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6658,3,6581,'@Storage Availability Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6659,3,6581,'@System Management','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6660,3,6581,'@Systems Management Messaging Server support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6656,3,6581,'@Smart card support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6657,3,6581,'@Somali Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6655,3,6581,'@Server Platform Development','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6654,3,6581,'@Server Platform','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6653,3,6581,'@Security Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6652,3,6581,'@SNMP Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6651,3,6581,'@Ruby Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6650,3,6581,'@Resilient Storage','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6649,3,6581,'@Remote Desktop Clients','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6648,3,6581,'@Printing client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6647,3,6581,'@Print Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6646,3,6581,'@PostgreSQL Database server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6645,3,6581,'@PostgreSQL Database client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6644,3,6581,'@PHP Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6643,3,6581,'@Office Suite and Productivity','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6642,3,6581,'@Network Storage Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6641,3,6581,'@Network Infrastructure Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6640,3,6581,'@MySQL Database server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6639,3,6581,'@MySQL Database client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6638,3,6581,'@Messaging Client Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6637,3,6581,'@Mainframe Access','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6636,3,6581,'@Load Balancer','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6635,3,6581,'@Large Systems Performance','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6634,3,6581,'@KDE Desktop','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6632,3,6581,'@Input Methods','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6633,3,6581,'@Java Platform','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6631,3,6581,'@Infiniband Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6630,3,6581,'@Identity Management Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6629,3,6581,'@High Availability Management','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6628,3,6581,'@High Availability','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6627,3,6581,'@Graphics Creation Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6626,3,6581,'@FTP server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6625,3,6581,'@FCoE Storage Client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6624,3,6581,'@Emacs','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6623,3,6581,'@Eclipse','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6622,3,6581,'@Directory Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6621,3,6581,'@Dial-up Networking Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6619,3,6581,'@Desktop Platform Development','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6620,3,6581,'@Development tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6618,3,6581,'@Desktop Platform','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6617,3,6581,'@Desktop Debugging and Performance Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6614,3,6581,'@Compatibility libraries','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6615,3,6581,'@Debugging Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6616,3,6581,'@Desktop','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6613,3,6581,'@Client management tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6612,3,6581,'@CIFS file server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6611,3,6581,'@Backup Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6610,3,6581,'@Backup Client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6609,3,6581,'@Additional Development','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6608,3,6581,'@Web Server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6607,3,6581,'@Virtualization Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6606,3,6581,'@Virtualization','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6605,3,6581,'@System administration tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6604,3,6581,'@Scientific support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6603,3,6581,'@Perl Support','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6602,3,6581,'@Performance Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6601,3,6581,'@Networking Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6600,3,6581,'@Network file system client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6599,3,6581,'@NFS file server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6598,3,6581,'@Legacy X Window System compatibility','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6596,3,6581,'@Internet Browser','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6597,3,6581,'@Legacy UNIX compatibility','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6595,3,6581,'@Internet Applications','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6594,3,6581,'@Hardware monitoring utilities','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6593,3,6581,'@Graphical Administration Tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6592,3,6581,'@General Purpose Desktop','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6591,3,6581,'@Fonts','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6589,3,6581,'@Directory Client','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6590,3,6581,'@E-mail server','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6588,3,6581,'@Console internet tools','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6587,3,6581,'@Base','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6586,3,6581,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6585,3,6581,'# Customize to your required package selection.','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6584,3,6581,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6582,3,6581,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6583,3,6581,'# CentOS 6','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6581,3,0,'%packages','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6580,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6579,3,0,'# Packages','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6578,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6577,3,0,'firstboot --enable','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6576,3,0,'xconfig --defaultdesktop=gnome --startxonboot','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6575,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6574,3,0,'# X Window System','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6573,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6572,3,0,'firewall --enabled','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6571,3,0,'auth --useshadow --enablemd5','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6570,3,0,'rootpw --iscrypted 1$XA3AnJXEveE','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6569,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6568,3,0,'# Authentication','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6567,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6566,3,0,'network --bootproto=dhcp','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6565,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6563,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6564,3,0,'# Network interface configuration','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6562,3,0,'logvol / --fstype=ext4 --name=root --vgname=vg_root --size=1 --grow','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6560,3,0,'logvol /tmp --fstype=ext4 --name=tmp --vgname=vg_root --size=1000','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6561,3,0,'logvol /var --fstype=ext4 --name=var --vgname=vg_root --size=2000','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6559,3,0,'logvol swap --name=swap --vgname=vg_root --size=512','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6558,3,0,'volgroup vg_root pv.01','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6557,3,0,'part pv.01 --grow --size=1','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6556,3,0,'part /boot --fstype=ext4 --size=500','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6554,3,0,'# Disk configuration','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6552,3,0,'clearpart --all --initlabel','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6555,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6553,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6551,3,0,'zerombr yes','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6550,3,0,'bootloader --location=mbr','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6549,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6548,3,0,'# Boot loader & partitions','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6547,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6546,3,0,'url --url _CENTOS-VAULT_/6.3/os/i386','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6545,3,0,'text','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6543,3,0,'timezone Europe/Paris','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6544,3,0,'reboot','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6542,3,0,'keyboard us','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6541,3,0,'lang C','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6540,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6539,3,0,'# Basic configuration','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6538,3,0,'#','2013-09-15 19:14:31');
INSERT INTO `ksconf` (`id`, `pxeprofileid`, `parent`, `data`, `audit`) VALUES (6537,3,0,'# Generated by OneClickKick web generator','2013-09-15 19:14:31');
/*!40000 ALTER TABLE `ksconf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `log` (
  `id` int(11) NOT NULL auto_increment,
  `logtypeid` int(11) NOT NULL,
  `data` varchar(255) NOT NULL,
  `comment` blob,
  `refid` int(11) default NULL,
  `ref` varchar(255) default NULL,
  `user` varchar(64) default NULL,
  `remoteip` varchar(64) default NULL,
  `remotehost` varchar(255) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1584 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logtype`
--

DROP TABLE IF EXISTS `logtype`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `logtype` (
  `id` int(11) NOT NULL auto_increment,
  `logname` varchar(16) NOT NULL,
  `comment` varchar(255) default NULL,
  `refidcol` varchar(128) default NULL,
  `refidtbl` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `logname` (`logname`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `logtype`
--

LOCK TABLES `logtype` WRITE;
/*!40000 ALTER TABLE `logtype` DISABLE KEYS */;
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (1,'security','Security','username','users');
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (3,'kickstart','Kickstart','hostname','dhcpgroupmem');
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (4,'hostconfig','Host','hostname','dhcpgroupmem');
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (5,'dhcpsconfig','DHCP subnet','descr','dhcpsubnet');
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (6,'dhcpgconfig','DHCP group','groupname','dhcpgroup');
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (7,'dhcpconfig','DHCP general',NULL,NULL);
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (8,'pxepconfig','PXE profile','name','pxeprofile');
INSERT INTO `logtype` (`id`, `logname`, `comment`, `refidcol`, `refidtbl`) VALUES (9,'error','General error','message','error');
/*!40000 ALTER TABLE `logtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `os`
--

DROP TABLE IF EXISTS `os`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `os` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `os`
--

LOCK TABLES `os` WRITE;
/*!40000 ALTER TABLE `os` DISABLE KEYS */;
INSERT INTO `os` (`id`, `name`) VALUES (1,'Other');
INSERT INTO `os` (`id`, `name`) VALUES (2,'DOS');
INSERT INTO `os` (`id`, `name`) VALUES (3,'Red Hat');
INSERT INTO `os` (`id`, `name`) VALUES (4,'SUSE');
INSERT INTO `os` (`id`, `name`) VALUES (5,'Debian');
INSERT INTO `os` (`id`, `name`) VALUES (6,'Ubuntu');
INSERT INTO `os` (`id`, `name`) VALUES (7,'CentOS');
INSERT INTO `os` (`id`, `name`) VALUES (8,'Slackware');
INSERT INTO `os` (`id`, `name`) VALUES (9,'Mandriva');
/*!40000 ALTER TABLE `os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pxeactive`
--

DROP TABLE IF EXISTS `pxeactive`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pxeactive` (
  `id` int(11) NOT NULL auto_increment,
  `dhcpgroupmemid` int(11) NOT NULL,
  `pxeprofileid` int(11) NOT NULL default '1',
  `auth` varchar(128) NOT NULL,
  `gotksfile` int(1) default '0',
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=233 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pxeactive`
--

LOCK TABLES `pxeactive` WRITE;
/*!40000 ALTER TABLE `pxeactive` DISABLE KEYS */;
/*!40000 ALTER TABLE `pxeactive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pxeconf`
--

DROP TABLE IF EXISTS `pxeconf`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pxeconf` (
  `id` int(11) NOT NULL auto_increment,
  `item` varchar(255) NOT NULL,
  `value` varchar(255) default NULL,
  `descr` varchar(255) default NULL,
  `pxeprofileid` int(11) default '1',
  `parent` int(11) default '0',
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=527 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pxeconf`
--

LOCK TABLES `pxeconf` WRITE;
/*!40000 ALTER TABLE `pxeconf` DISABLE KEYS */;
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (429,'IPAPPEND','2',NULL,3,426,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (428,'APPEND','initrd=img/centos63-i386/initrd.img ks=_KS_ kssendmac kssendsn ksdevice=BOOTIF',NULL,3,427,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (427,'KERNEL','img/centos63-i386/vmlinuz',NULL,3,426,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (426,'MENU LABEL','CentOS 6 i386 installation',NULL,3,425,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (425,'LABEL','install',NULL,3,0,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (424,'PROMPT','0',NULL,3,0,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (423,'DEFAULT','install',NULL,3,0,'2010-09-30 18:20:17');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (412,'DEFAULT','memtest',NULL,2,0,'2010-09-30 18:22:16');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (413,'PROMPT','0',NULL,2,0,'2010-09-30 18:22:16');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (414,'LABEL','memtest',NULL,2,0,'2010-09-30 18:22:16');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (415,'MENU LABEL','Memory Test',NULL,2,414,'2010-09-30 18:22:16');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (416,'KERNEL','img/memtest86plus-1.26/memtest.img',NULL,2,415,'2010-09-30 18:22:16');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (527,'LABEL','ockenrollauto',NULL,4,0,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (528,'MENU LABEL','Enrollment (Auto detect display)',NULL,4,527,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (529,'KERNEL','img/ockenroller-2.0/vmlinuz',NULL,4,528,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (530,'APPEND','initrd=img/ockenroller-2.0/core.gz loglevel=3 cde httplist=_WEBUI_HOSTNAME_/ockimg/ockenroller-2.0/tce/ock-enroller.lst ockenrollboot=_OCKENROLLBOOT_',NULL,4,529,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (531,'LABEL','ockenrollmanual',NULL,4,0,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (532,'MENU LABEL','Enrollment (Manual display configuration)',NULL,4,531,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (533,'KERNEL','img/ockenroller-2.0/vmlinuz',NULL,4,532,'2013-09-15 18:48:13');
INSERT INTO `pxeconf` (`id`, `item`, `value`, `descr`, `pxeprofileid`, `parent`, `audit`) VALUES (534,'APPEND','initrd=img/ockenroller-2.0/core.gz loglevel=3 cde httplist=_WEBUI_HOSTNAME_/ockimg/ockenroller-2.0/tce/ock-enroller.lst xsetup ockenrollboot=_OCKENROLLBOOT_',NULL,4,533,'2013-09-15 18:48:13');
/*!40000 ALTER TABLE `pxeconf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pxeprofile`
--

DROP TABLE IF EXISTS `pxeprofile`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `pxeprofile` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  `imagedir` varchar(255) NOT NULL,
  `imagereadme` blob,
  `descr` varchar(255) default NULL,
  `osid` int(11) default NULL,
  `boottypeid` int(11) default NULL,
  `defpxe` int(1) default '0',
  `defpxepwd` int(1) default '0',
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `pxeprofile`
--

LOCK TABLES `pxeprofile` WRITE;
/*!40000 ALTER TABLE `pxeprofile` DISABLE KEYS */;
INSERT INTO `pxeprofile` (`id`, `name`, `imagedir`, `imagereadme`, `descr`, `osid`, `boottypeid`, `defpxe`, `defpxepwd`, `audit`) VALUES (1,'Boot Local','localboot',NULL,'',1,1,0,0,'2010-09-21 22:08:00');
INSERT INTO `pxeprofile` (`id`, `name`, `imagedir`, `imagereadme`, `descr`, `osid`, `boottypeid`, `defpxe`, `defpxepwd`, `audit`) VALUES (2,'Memtest 86+ v1.26','memtest86plus-1.26',NULL,'',1,1,1,0,'2010-09-21 22:07:29');
INSERT INTO `pxeprofile` (`id`, `name`, `imagedir`, `imagereadme`, `descr`, `osid`, `boottypeid`, `defpxe`, `defpxepwd`, `audit`) VALUES (3,'CentOS 6.3 i386','centos55-i386',NULL,'',7,2,1,0,'2010-09-30 17:44:19');
INSERT INTO `pxeprofile` (`id`, `name`, `imagedir`, `imagereadme`, `descr`, `osid`, `boottypeid`, `defpxe`, `defpxepwd`, `audit`) VALUES (4,'Enroll new machine','ockenroller-2.0','HTTP support for the tftpboot/img directory must be enabled for this boot image to work properly.\n\nYour OneClickKick tftpboot/img directory must be available as http://webserver.your.corp/ockimg/.\n\n','Enroll a new machine using PXE boot',1,1,1,0,'2013-09-15 18:44:07');
/*!40000 ALTER TABLE `pxeprofile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights`
--

DROP TABLE IF EXISTS `rights`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `rights` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  `descr` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `rights`
--

LOCK TABLES `rights` WRITE;
/*!40000 ALTER TABLE `rights` DISABLE KEYS */;
INSERT INTO `rights` (`id`, `name`, `descr`) VALUES (1,'users','User administration');
INSERT INTO `rights` (`id`, `name`, `descr`) VALUES (2,'hosts','Host modification and pxe boot initiation');
INSERT INTO `rights` (`id`, `name`, `descr`) VALUES (3,'dhcpg','DHCP Group Administration');
INSERT INTO `rights` (`id`, `name`, `descr`) VALUES (4,'pxep','PXE Profile Adminisration');
INSERT INTO `rights` (`id`, `name`, `descr`) VALUES (5,'dhcps','DHCP Subnet Administration');
INSERT INTO `rights` (`id`, `name`, `descr`) VALUES (6,'dhcpr','DHCP config regeneration');
/*!40000 ALTER TABLE `rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(128) NOT NULL,
  `password` blob,
  `name` varchar(255) default NULL,
  `audit` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`, `name`, `audit`) VALUES (1,'admin','','Default admin user','2010-09-21 22:08:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cache` (
  `ctype` varchar(10) NOT NULL,
  `ckey` varchar(255) NOT NULL,
  `cval` varchar(255) NOT NULL,
  `csource` varchar(64) default NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `plock` int(11) default '0',
  KEY `ctype` (`ctype`,`ckey`,`cval`),
  KEY `ckey` (`ckey`),
  KEY `cval` (`cval`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `jobs` (
  `id` int(11) NOT NULL auto_increment,
  `job_function` varchar(128) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `plock` int(11) default '0',
  `plock_host` varchar(255) default NULL,
  `user` varchar(255) NOT NULL,
  `userip` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5427 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;


--
-- Table structure for table `os`
--

DROP TABLE IF EXISTS `os`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `os` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `os`
--

LOCK TABLES `os` WRITE;
/*!40000 ALTER TABLE `os` DISABLE KEYS */;
INSERT INTO `os` VALUES (1,'Other');
INSERT INTO `os` VALUES (2,'DOS');
INSERT INTO `os` VALUES (3,'Red Hat');
INSERT INTO `os` VALUES (4,'Fedora');
INSERT INTO `os` VALUES (5,'Debian');
INSERT INTO `os` VALUES (6,'Ubuntu');
INSERT INTO `os` VALUES (7,'CentOS');
INSERT INTO `os` VALUES (8,'Slackware');
INSERT INTO `os` VALUES (9,'Mandriva');
INSERT INTO `os` VALUES (10,'Scientific Linux');
INSERT INTO `os` VALUES (11,'Linux Mint');
INSERT INTO `os` VALUES (12,'Solaris');
INSERT INTO `os` VALUES (13,'OpenSolaris');
INSERT INTO `os` VALUES (14,'OpenIndiana');
INSERT INTO `os` VALUES (15,'SUSE');
INSERT INTO `os` VALUES (16,'FreeBSD');
INSERT INTO `os` VALUES (17,'OpenBSD');
INSERT INTO `os` VALUES (18,'PCLinuxOS');
INSERT INTO `os` VALUES (19,'ArchLinux');
INSERT INTO `os` VALUES (20,'Puppy Linux');
/*!40000 ALTER TABLE `os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logtype`
--

DROP TABLE IF EXISTS `logtype`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `logtype` (
  `id` int(11) NOT NULL auto_increment,
  `logname` varchar(16) NOT NULL,
  `comment` varchar(255) default NULL,
  `refidcol` varchar(128) default NULL,
  `refidtbl` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `logname` (`logname`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `logtype`
--

LOCK TABLES `logtype` WRITE;
/*!40000 ALTER TABLE `logtype` DISABLE KEYS */;
INSERT INTO `logtype` VALUES (1,'security','Security','username','users');
INSERT INTO `logtype` VALUES (3,'kickstart','Kickstart','hostname','dhcpgroupmem');
INSERT INTO `logtype` VALUES (4,'hostconfig','Host','hostname','dhcpgroupmem');
INSERT INTO `logtype` VALUES (5,'dhcpsconfig','DHCP subnet','descr','dhcpsubnet');
INSERT INTO `logtype` VALUES (6,'dhcpgconfig','DHCP group','groupname','dhcpgroup');
INSERT INTO `logtype` VALUES (7,'dhcpconfig','DHCP general',NULL,NULL);
INSERT INTO `logtype` VALUES (8,'pxepconfig','PXE profile','name','pxeprofile');
INSERT INTO `logtype` VALUES (9,'error','General error','message','error');
INSERT INTO `logtype` VALUES (10,'info','General info','message','error');
/*!40000 ALTER TABLE `logtype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;


--
-- Table structure for table `error`
--

DROP TABLE IF EXISTS `error`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `error` (
  `id` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `error`
--

LOCK TABLES `error` WRITE;
/*!40000 ALTER TABLE `error` DISABLE KEYS */;
INSERT INTO `error` VALUES (0,'OK');
INSERT INTO `error` VALUES (95,'File system error');
INSERT INTO `error` VALUES (1,'Not found');
INSERT INTO `error` VALUES (255,'General failure');
INSERT INTO `error` VALUES (5,'Already exists');
INSERT INTO `error` VALUES (6,'File did not upload');
INSERT INTO `error` VALUES (7,'File size too large');
INSERT INTO `error` VALUES (8,'DHCP restart failed');
INSERT INTO `error` VALUES (9,'DHCP config test failed. Please examine the output for errors.');
INSERT INTO `error` VALUES (10,'Could not add DHCP group config');
INSERT INTO `error` VALUES (11,'Could not update DHCP group config');
INSERT INTO `error` VALUES (12,'Cannot delete the super-user account');
INSERT INTO `error` VALUES (13,'Failed to write to log');
INSERT INTO `error` VALUES (14,'Could not retreive values from database');
INSERT INTO `error` VALUES (15,'File/folder permission error');
INSERT INTO `error` VALUES (16,'Not a valid boot image');
INSERT INTO `error` VALUES (17,'Boot image already exists (folder name error)');
INSERT INTO `error` VALUES (18,'Boot image is still in use by PXE profiles');
INSERT INTO `error` VALUES (19,'Failed to update config with default settings');
/*!40000 ALTER TABLE `error` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;




--
-- Temporary table structure for view `v_log`
--

DROP TABLE IF EXISTS `v_log`;
/*!50001 DROP VIEW IF EXISTS `v_log`*/;
/*!50001 CREATE TABLE `v_log` (
  `logid` int(11),
  `logname` varchar(16),
  `logdata` varchar(255),
  `logcomment` blob,
  `refid` int(11),
  `refidcol` varchar(128),
  `refidtbl` varchar(255),
  `ref` varchar(255),
  `logtypecomment` varchar(255),
  `loguser` varchar(64),
  `logremoteip` varchar(64),
  `logremotehost` varchar(255),
  `timestamp` timestamp
) */;

--
-- Final view structure for view `v_log`
--

/*!50001 DROP TABLE `v_log`*/;
/*!50001 DROP VIEW IF EXISTS `v_log`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50001 VIEW `v_log` AS select `log`.`id` AS `logid`,`logtype`.`logname` AS `logname`,`log`.`data` AS `logdata`,`log`.`comment` AS `logcomment`,`log`.`refid` AS `refid`,`logtype`.`refidcol` AS `refidcol`,`logtype`.`refidtbl` AS `refidtbl`,`log`.`ref` AS `ref`,`logtype`.`comment` AS `logtypecomment`,`log`.`user` AS `loguser`,`log`.`remoteip` AS `logremoteip`,`log`.`remotehost` AS `logremotehost`,`log`.`timestamp` AS `timestamp` from (`log` join `logtype`) where (`log`.`logtypeid` = `logtype`.`id`) order by `log`.`id` desc */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

alter table dhcpsubnet add autoip_offset int(255) default NULL after descr;

alter table dhcpgroupmem add ipa_otp varchar(255) default NULL after statichost;

alter table dhcpgroup add hostfqdn int(1) default 0 after statichosts;

DROP TABLE IF EXISTS `tags`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tagtype` varchar(64) NOT NULL,
  `tagname` varchar(255) NOT NULL,
  `tagvalue` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` (`id`, `tagtype`, `tagname`, `tagvalue`) VALUES (1,'ks','CENTOS-VAULT','http://vault.centos.org');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
