<?php

// Script to execute IPA commands using the kerberos kredentials of the logged on user

// First start the session
session_start();

include("conf/config.php");
require("functions/log.php");
include("functions/naming.php");
include("functions/dhcp.php");
include("functions/pxe.php");
include("functions/general.php");
include("include/backports.php");
include("functions/ockd.php");
include("functions/cache.php");
include("functions/ipa.php");


$ipa = new ipa();

//echo "<pre>"; print_r($_SERVER);

if (isset($_SERVER["AUTH_TYPE"]) && ($_SERVER["AUTH_TYPE"] == "Negotiate" || $_SERVER["AUTH_TYPE"] == "Basic")) {

  if (isset($_SESSION["IPACMD"]["POST"]["subnetid"]) && $_SESSION["IPACMD"]["POST"]["subnetid"] == "0") {
    $ipaddr = "0";
  }
  else {
    $subnetinfo = dhcp_subnetinfo($_SESSION["IPACMD"]["POST"]["subnetid"]);
    //preg_match('/(\d{1,3}\.\d{1,3}\.\d{1,3})\.\d{1,3}/', $subnetinfo["subnet"], $subnet);
    $ipaddr = $ipa->host_find_next_ipv4($subnetinfo["3octets"], $subnetinfo["autoip_offset"]);
  }


  $result = $ipa->host_add($_SESSION["IPACMD"]["POST"]["host"], $_SESSION["IPACMD"]["POST"], $ipaddr, 0);

  $_SESSION["IPACMD"]["RESULT"]["errcode"] = $result["val"];
  $_SESSION["IPACMD"]["RESULT"]["text"] = $result;


/*
  echo "3octets: " . $subnetinfo["3octets"] . " offset: " .  $subnetinfo["autoip_offset"] . "<br><br>";
  echo "subnetinfo: <br>";
  print_r($subnetinfo);


  echo "<pre>SESSION: <br>";
  print_r($_SESSION);
  echo "<br>RESULT: <br>";
  print_r($result);
  echo "</pre> <br>";
*/

  if ($_SESSION["IPACMD"]["POST"]["dhcpgroupid"] > 0) {
    $dhcpgres = host_group_update($_SESSION["IPACMD"]["POST"]["host"], $_SESSION["IPACMD"]["POST"]["dhcpgroupid"], 0, $result["ipa_otp"]);
    $_SESSION["IPACMD"]["DHCPRESULT"]["text"] = $dhcpgres;
  }

  $redir = $_SESSION["IPACMD"]["redir"];
  if ($_SESSION["IPACMD"]["POST"]["pxeenablenow"] == true) $redir .= "&pxeenablenow=true&host=" . $_SESSION["IPACMD"]["POST"]["host"];

  // Finished, get rid of the old data from the session
//  unset($_SESSION["IPACMD"]["POST"]);
  header("Location: $redir");
}
else {
  $_SESSION["IPACMD"]["RESULT"]["errcode"] = 255;
  $_SESSION["IPACMD"]["RESULT"]["text"] = "Failed, not authenticated with kerberos";
  if (isset($_SESSION["IPACMD"]["redir"])) {
    $redir = $_SESSION["IPACMD"]["redir"];
  }
  else {
    $redir = "index.php";
  }
  header("Location: $redir");
}


?>
