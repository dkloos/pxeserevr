<?php

$expl = "<h1>Info</h1>At this page you can configure DHCP groups, and assign PXE profiles to the DHCP groups.<br>
<br>
Click on the <img src='images/btn_edit.gif' width='24' height='24'> to modify group configuration, or <img src='images/btn_delete.gif' width='24' height='24'> delete group configuration.<br>
<br>
Group name, profile setting, and description is found under \"Mod\". Boot server and boot filename is set under \"Mod Cfg\"
<br><br> The \"Static IP for members\" option will assign a static IP for all hosts within this subnet. The IP will be looked up from DNS.
";

$smarty->assign('expl', $expl);

if ($_GET["a"] == "groupmod") {
  $list = array();
  $l=0;
  $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "DHCP group name";

  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "name";
  $hostgroup = dhcp_groupinfo($_GET["dhcpgroupid"]);
  $list[$l][$c]["data"] = $hostgroup["name"];
  $list[$l][$c]["formid"] = make_formid("name");
  $list[$l][$c]["validate"] = "present";
  $list[$l][$c]["required"] = "true";
  $l++;
  $c=0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "PXE Profile";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "pxeprofile";
  $pxeprofiles = pxe_profiles();
  $pxeprofile = pxe_profile($_GET["dhcpgroupid"]);
  for ($i=0; $i < count($pxeprofiles); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $pxeprofiles[$i]["id"];
    $list[$l][$c]["data"][$i]["text"] = $pxeprofiles[$i]["name"];
    if ($pxeprofile["id"] == $pxeprofiles[$i]["id"]) {
      $list[$l][$c]["data"][$i]["selected"] = 1;
    }
  }
  $l++;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Description";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["data"] = $hostgroup["descr"];
  $list[$l][$c]["name"] = "descr";
  $l++;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Static IP for members?";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["checked"] = $hostgroup["statichosts"];
  $list[$l][$c]["name"] = "statichosts";
  $l++;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Send full/short hostname to the client";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "hostfqdn";
  $i=0;
  $list[$l][$c]["data"][$i]["value"] = $i;
  $list[$l][$c]["data"][$i]["text"] = "Use global setting";
  if ($hostgroup["hostfqdn"] == $i) $list[$l][$c]["data"][$i]["selected"] = 1;
  $i++;
  $list[$l][$c]["data"][$i]["value"] = $i;
  $list[$l][$c]["data"][$i]["text"] = "Always send FQDN as hostname";
  if ($hostgroup["hostfqdn"] == $i) $list[$l][$c]["data"][$i]["selected"] = 1;
  $i++;
  $list[$l][$c]["data"][$i]["value"] = $i;
  $list[$l][$c]["data"][$i]["text"] = "Always send short hostname with no domain";
  if ($hostgroup["hostfqdn"] == $i) $list[$l][$c]["data"][$i]["selected"] = 1;

  $l++;
  $c=0;



  $smarty->assign('validate', "yes");
  $smarty->assign('pheading', "Modify dhcp group");
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=dhcpg&a=groupmodf&dhcpgroupid=".$_GET["dhcpgroupid"]);
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Submit modification");
  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "groupmodf") {
  $smarty->assign('pheading', "Result of host group modification");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpg");
  $status = dhcp_group_update($_GET["dhcpgroupid"],$_POST["name"],$_POST["pxeprofile"],$_POST["descr"],$_POST["hostfqdn"]);
  if ($status == 0) {
    $smarty->assign('text', "The update was successfull.");
  }
  else {
    $smarty->assign('text', "The update failed. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "groupconfmod") {
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $c = 0;
  $l++;
  $sopts = dhcp_groupconfig_avail_options();
  for ($i=0; $i < count($sopts); $i++) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $sopts[$i]["desc"];
    $c++;
    $list[$l][$c]["type"] = $sopts[$i]["type"];
    $list[$l][$c]["name"] = $sopts[$i]["item"];
    unset ($optval);
    $optval = dhcp_groupconfig_get_optvalue($_GET["dhcpgroupid"],$sopts[$i]["item"]);
    $list[$l][$c]["data"] = $optval;

    $list[$l][$c]["formid"] = make_formid($sopts[$i]["item"]);
    $list[$l][$c]["validate"] = $sopts[$i]["validate"];
    $list[$l][$c]["required"] = $sopts[$i]["required"];

    $c = 0;
    $l++;
  } 
  $smarty->assign('validate', "yes");
  $smarty->assign('pheading', "Modify dhcp group");
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=dhcpg&a=groupconfmodf&dhcpgroupid=".$_GET["dhcpgroupid"]);
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Submit modification");
  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "groupconfmodf") {
  $smarty->assign('pheading', "Result of host group modification");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpg");
  $status = dhcp_groupconf_update($_GET["dhcpgroupid"],$_POST);
  if ($status == 0) {
    $smarty->assign('text', "The update was successfull.");
  }
  else {
    $smarty->assign('text', "The update failed. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "groupadd") {
  $smarty->assign('pheading', "Add a DHCP group");
  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = "Item";
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "Value";
  $list[1][0]["type"] = "text";
  $list[1][0]["data"] = "Group name";
  $list[1][1]["type"] = "input";
  $list[1][1]["name"] = "groupname";
  $l=1; $c=1;
  $list[$l][$c]["formid"] = make_formid("groupname");
  $list[$l][$c]["validate"] = "present";
  $list[$l][$c]["required"] = "true";

  $list[2][0]["type"] = "text";
  $list[2][0]["data"] = "PXE profile";
  $list[2][1]["type"] = "dropbox";
  $list[2][1]["name"] = "pxeprofileid";
  $pxeprofiles = pxe_profiles();
  for ($i=0; $i < count($pxeprofiles); $i++) {
    $list[2][1]["data"][$i]["value"] = $pxeprofiles[$i]["id"];
    $list[2][1]["data"][$i]["text"] = $pxeprofiles[$i]["name"];
  }
  $list[3][0]["type"] = "text";
  $list[3][0]["data"] = "Template";
  $list[3][1]["type"] = "dropbox";
  $list[3][1]["name"] = "templateid";
  $dhcpgroups = dhcp_groups();
  $j=0;
  for ($i=0; $i < count($dhcpgroups); $i++) {
    $list[3][1]["data"][$j]["value"] = $dhcpgroups[$i]["id"];
    $list[3][1]["data"][$j]["text"] = $dhcpgroups[$i]["groupname"];
    $j++;
  }
  $list[4][0]["type"] = "text";
  $list[4][0]["data"] = "Description";
  $list[4][1]["type"] = "input";
  $list[4][1]["name"] = "descr";

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=dhcpg&a=groupaddf");

  $smarty->assign('list', $list);
  $smarty->assign('validate', "yes");
  $smarty->assign('listsubmitbox', "Add group");

  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "groupaddf") {
  $smarty->assign('pheading', "Result of add group");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpg");
  $status = dhcp_group_add($_POST);
  if ($status == 0) {
    $smarty->assign('text', "The group was added successfully.");
  }
  else {
    $smarty->assign('text', "The failed to be added. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "groupdel") {
  $smarty->assign('pheading', "Add a DHCP group");
  $groupinfo = dhcp_groupinfo($_GET["dhcpgroupid"]);
  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = "Item";
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "Value";
  $list[1][0]["type"] = "text";
  $list[1][0]["data"] = "Group name";
  $list[1][1]["type"] = "text";
  $list[1][1]["data"] = $groupinfo["name"];

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=dhcpg&a=groupdelf&dhcpgroupid=".$_GET["dhcpgroupid"]);

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Confirm group deletion");

  $smarty->display("$template/table.tpl");

}
elseif ($_GET["a"] == "groupdelf") {
  $smarty->assign('pheading', "Result of group deletion");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpg");
  $status = dhcp_group_del($_GET["dhcpgroupid"]);
  if ($status == 0) {
    $smarty->assign('text', "The group was added successfully.");
  }
  else {
    $smarty->assign('text', "The failed to be added. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "enablepxe") {
  $smarty->assign('pheading', "Enable DHCP group for PXE boot");
  $pxeprofile = pxe_profile($_GET["dhcpgroupid"]);
  $dhcpgroupinfo = dhcp_groupinfo($_GET["dhcpgroupid"]);
  $dhcpgroupmembers = dhcp_groupmembers($_GET["dhcpgroupid"]);
  $pxeprofiles = pxe_profiles();


  $htext = "<h3>DHCP Group: " .  $dhcpgroupinfo["name"] . "</h3";

  $list = array();
  $l=0;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $c++;
  $c=0;
  $l++;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "PXE Profile";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "pxeprofileid";
    for ($i=0; $i < count($pxeprofiles); $i++) {
      $list[$l][$c]["data"][$i]["value"] = $pxeprofiles[$i]["id"];
      $list[$l][$c]["data"][$i]["text"] = $pxeprofiles[$i]["name"];
      if ($pxeprofile["id"] == $pxeprofiles[$i]["id"]) $list[$l][$c]["data"][$i]["selected"] = 1;
    }
  $c++;
  $c=0;
  $l++;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $c++;
  $c=0;
  $l++;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<b>Member name</b>";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<b>Ethernet/IP Address found</b>";
  $c++;
  $c=0;
  $l++;

  for ($i=0; $i < count($dhcpgroupmembers); $i++) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $dhcpgroupmembers[$i][hostname];
    $c++;
  $list[$l][$c]["type"] = "text";
  $h=host_details_byname($dhcpgroupmembers[$i][hostname]);
  if (isset($h["ip"]) && isset($h["ether"])) {
    $list[$l][$c]["data"] = "OK";
  }
  else {
    $list[$l][$c]["data"] = "Not available";
  }
    $c++;
    $c=0;
    $l++;
  }


  $smarty->assign('htext', $htext);
  $smarty->assign('list', $list);
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=dhcpg&a=enablepxef&dhcpgroupid=".$_GET["dhcpgroupid"]);
  $smarty->assign('listsubmitbox', "PXE Enable Group");

  $smarty->display("$template/table.tpl");
}



elseif ($_GET["a"] == "enablepxef") {
  $smarty->assign('pheading', "Result of PXE Enable Group");
  //$smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpg");
  $status = pxe_enable_group($_GET["dhcpgroupid"],$_POST[pxeprofileid],1);

  $list = array();
  $l=0;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Hostname";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Status";
  $c++;
  $c=0;
  $l++;

  for($i=0; $i < count($status); $i++) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $status[$i][hostname];
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = errormsg($status[$i][result]);
    $c++;
    $c=0;
    $l++;
  }

  $smarty->assign('list', $list);
  $smarty->display("$template/table.tpl");
}


elseif ($_GET["a"] == "disablepxe") {
  $smarty->assign('pheading', "Result of PXE Disable Group");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpg");
  $status = pxe_disable_group($_GET["dhcpgroupid"]);

  $list = array();
  $l=0;
  $c=0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Hostname";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Status";
  $c++;
  $c=0;
  $l++;

  for($i=0; $i < count($status); $i++) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $status[$i][hostname];
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = errormsg($status[$i][result]);
    $c++;
    $c=0;
    $l++;
  }

  $smarty->assign('list', $list);
  $smarty->display("$template/table.tpl");
}




else {
  $list = array();
  $l=0;
  $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "DHCP group (# members)";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "PXE profile";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<center>Kickstart</center>";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<center>Stop kickstart</center>";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<center>Modify</center>";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<center>Modify Cfg</center>";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "<center>Delete</center>";
  $c=0;
  $l++;

  $dhcpgroups = dhcp_groups();
  for ($j=0; $j < count($dhcpgroups); $j++) {
    $dhcp_group_info = dhcp_groupinfo($dhcpgroups[$j]["id"]);
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $dhcpgroups[$j]["groupname"] . " (" . $dhcp_group_info["num_members"] .")";
    $c++;
    $pxegroup = pxe_profile($dhcpgroups[$j]["id"]);
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $pxegroup["name"];
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=dhcpg&a=enablepxe&dhcpgroupid=" . $dhcpgroups[$j]["id"] . "\"><img src='images/btn_power_green.png' width='24' height='24'></a></center>";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=dhcpg&a=disablepxe&dhcpgroupid=" . $dhcpgroups[$j]["id"] . "\"><img src='images/btn_power_red.png' width='24' height='24'></a></center>";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=dhcpg&a=groupmod&dhcpgroupid=" . $dhcpgroups[$j]["id"] . "\"><img src='images/btn_edit.gif' width='24' height='24'></a></center>";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=dhcpg&a=groupconfmod&dhcpgroupid=" . $dhcpgroups[$j]["id"] . "\"><img src='images/btn_wrench.png' width='24' height='24'></a></center>";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=dhcpg&a=groupdel&dhcpgroupid=" . $dhcpgroups[$j]["id"] . "\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";
    $c=0;
    $l++; 
  }
  $smarty->assign('btext', "<a href=\"$_SERVER[PHP_SELF]?p=dhcpg&a=groupadd\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Add group</a>");
  $smarty->assign('list', $list);
  $smarty->assign('tablecycle', true);
  $smarty->assign('pheading', "DHCP groups");
  $smarty->display("$template/table.tpl");
}

?>
