<?php
$expl = "<h1>Info</h1>Kickstart configurator";
$smarty->assign('expl', $expl);

include("functions/kickstart.php");



/*
 *  Warning - development 
 */

if ($_GET["pg"] == "0") {

  $smarty->assign('pheading', "Under development");
  
  $text = "";
  $text .= "This kickstart web generator is under development.";
  $text .= "<br><br><br>";
  $text .= "It's currently modelled around CentOS 5, but is usable for any distribution that supports kickstart scripts. ";
  $text .= "However kickstart scripts do not have a set standard across platform which is why it's so hard to model a kickstart generator ";
  $text .= "who works across distributions. This is a ongoing development.";
  $text .= "<br><br><br>";
  $text .= "There is currently no logic built into this generator, i.e. if you specify an invalid IP address for your NIC, ";
  $text .= "it won't complain. However your Linux distribution will.";
  $text .= "<br><br><br>";
  $text .= "This kickstart generator is currently known to work with the following distributions:<br><br>";
  $text .= "<li> Red Hat / CentOS 6";
  $text .= "<li> Red Hat / CentOS 5";
  $text .= "<li> Red Hat / CentOS 4";
  $text .= "<li> Red Hat / CentOS 3 (Some support)";
  $text .= "<li> Ubuntu 10 (See: <a href=\"https://help.ubuntu.com/10.04/installation-guide/i386/automatic-install.html\" target=\"_blank\"> https://help.ubuntu.com/10.04/installation-guide/i386/automatic-install.html) </a>";
  $text .= "<br><br><br>";
  $text .= "<br><br><br>";
  $text .= "";
  $text .= "<a href=\"".$_SERVER["PHP_SELF"]."?p=pxep&a=kickstart&pxepid=".$_GET["pxepid"]."&pg=1&ver=6\">Continue with RHEL / CentOS 6</a><br>";
  $text .= "<a href=\"".$_SERVER["PHP_SELF"]."?p=pxep&a=kickstart&pxepid=".$_GET["pxepid"]."&pg=1&ver=5\">Continue with RHEL / CentOS 5 or earlier</a><br>";

  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");
}


/*
 *  Basic configuration
 */

if ($_GET["pg"] == "1") {
  unset($_SESSION["ks"]);
  if (isset($_GET["ver"])) $_SESSION["ks"]["cfg"]["ver"] = $_GET["ver"];
  $smarty->assign('pheading', "Kickstart - Basic Configuration");
  $kf = new kickstart_func();
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Default Language";
  $c++;
  $ls = $kf->list_lang();
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "lang";
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
    $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
  }
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Keyboard";
  $c++;
  $ls = $kf->list_keyb();
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "keyboard";
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
    $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
  }
  $l++; $c = 0;

  if ($_SESSION["ks"]["cfg"]["ver"] <= 5) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Mouse";
    $c++;
    $ls = $kf->list_mouse();
    $list[$l][$c]["type"] = "dropbox";
    $list[$l][$c]["name"] = "mouse";
    for ($i = 0; $i < count($ls); $i++) {
      $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
      $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
    }
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;&nbsp;-- Emulate 3 Buttons";
    $c++;
    $list[$l][$c]["type"] = "checkbox";
    $list[$l][$c]["name"] = "emulate3buttons";
    $l++; $c = 0;
  }

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Timezone";
  $c++;
  $ls = $kf->list_timezone();
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "timezone";
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $ls[$i];
    $list[$l][$c]["data"][$i]["text"] = $ls[$i];
    if ($ls[$i] == "Europe/Paris") {
      $list[$l][$c]["data"][$i]["selected"] = 1;
    }
  }
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;&nbsp;-- Use UTC clock";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "utc";
  $l++; $c = 0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Reboot system after installation";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "reboot";
  $list[$l][$c]["checked"] = 1;
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Perform installation in text mode";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "text";
  $list[$l][$c]["checked"] = 1;
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Perform installation in interactive mode";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "interactive";
  $l++; $c = 0;

  if ($_SESSION["ks"]["cfg"]["ver"] == 5) {

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Key (Red Hat 5 only)";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "key";
    $l++; $c = 0;
  }

  $nextpage = $_GET["pg"] + 1;

  $smarty->assign('list', $list);
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");
}




/*
 * Installation Method
 */ 

elseif ($_GET["pg"] == "2") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $smarty->assign('pheading', "Kickstart - Installation Method");
  $kf = new kickstart_func(); 
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Choose the installation method";
  $c++;
  $ls = $kf->list_instmethod();
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "install";
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
    $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
  }
  $l++; $c = 0;

  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");
}



/*
 * Installation Method - Part 2
 */

elseif ($_GET["pg"] == "3") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $smarty->assign('pheading', "Kickstart - Installation Method, continued");
  $kf = new kickstart_func();
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Method chosen";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = $_POST["install"];
  $l++; $c = 0;

  $ls = $kf->list_instmethod_cfg($_POST["install"]);
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = $ls[$i]["text"];
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = $ls[$i]["code"];
    $l++; $c = 0;
  }

  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");
}




/*
 * Boot Loader Options
 */

elseif ($_GET["pg"] == "4") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $smarty->assign('pheading', "Kickstart - Boot Loader & Partition config");
  $kf = new kickstart_func();
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Boot loader";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "bootloader";
  $list[$l][$c]["data"]["0"]["value"] = "mbr";
  $list[$l][$c]["data"]["0"]["text"] = "Install new boot loader on Master Boot Record";
  $list[$l][$c]["data"]["1"]["value"] = "partition";
  $list[$l][$c]["data"]["1"]["text"] = "Install new boot loader on first sector of the boot partition";
  $list[$l][$c]["data"]["2"]["value"] = "none";
  $list[$l][$c]["data"]["2"]["text"] = "Do not install a boot loader";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Kernel parameters";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "append";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "MBR";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "zerombr";
  $list[$l][$c]["data"]["0"]["value"] = "yes";
  $list[$l][$c]["data"]["0"]["text"] = "Clear master boot record";
  $list[$l][$c]["data"]["1"]["value"] = "no";
  $list[$l][$c]["data"]["1"]["text"] = "Do not clear Master Boot Record";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Existing partitions";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "clearpart";
  $list[$l][$c]["data"]["0"]["value"] = "all";
  $list[$l][$c]["data"]["0"]["text"] = "Remove all existing partitions";
  $list[$l][$c]["data"]["1"]["value"] = "linux";
  $list[$l][$c]["data"]["1"]["text"] = "Remove existing Linux partitions";
  $list[$l][$c]["data"]["2"]["value"] = "none";
  $list[$l][$c]["data"]["2"]["text"] = "Preserve existing partitions";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Disk label";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "initlabel";
  $list[$l][$c]["data"]["0"]["value"] = "yes";
  $list[$l][$c]["data"]["0"]["text"] = "Initialize the disk label";
  $list[$l][$c]["data"]["1"]["value"] = "no";
  $list[$l][$c]["data"]["1"]["text"] = "Do not initialize the disk label";
  $l++; $c = 0;

  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");
}

/*
 * Partitions
 */

elseif ($_GET["pg"] == "5") {
  $disk = count($_SESSION["ks"]["5"]["disks"]);
  // Save last pages post data to session
  if ($_POST && !$_GET["partf"]) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  // Save added disk to session
  if ($_POST && $_GET["partf"]) $_SESSION["ks"][$_GET["pg"]]["disks"][] = $_POST;
  // Remove a disk from session
  if ($_GET["rmdisk"]) unset ($_SESSION["ks"][$_GET["pg"]]["disks"][$_GET["rmdisk"]]);
  $smarty->assign('pheading', "Kickstart - Partitions");
  $list = array();
  $kf = new kickstart_func();
  $l = 0;
  $c = 0;

  if ($_GET["add"] == 1) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;";
    $l++; $c = 0;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Mount point";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "mountpoint";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;
   
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "File system type";
    $c++;
    $list[$l][$c]["type"] = "dropbox";
    $list[$l][$c]["name"] = "filesystem";
    $ls = $kf->list_fs();
    for ($i = 0; $i < count($ls); $i++) {
      $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
      $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
    }
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Size (MB)";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "size";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;&nbsp; --Fixed size";
    $c++;
    $list[$l][$c]["type"] = "radio";
    $list[$l][$c]["name"] = "sizeopts";
    $list[$l][$c]["value"] = "fixed";
    $list[$l][$c]["checked"] = 1;
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;&nbsp; --Grow to fill";
    $c++;
    $list[$l][$c]["type"] = "radio";
    $list[$l][$c]["name"] = "sizeopts";
    $list[$l][$c]["value"] = "grow";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "growsize";
    $list[$l][$c]["size"] = "3";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;&nbsp; --Fill all unused space on disk";
    $c++;
    $list[$l][$c]["type"] = "radio";
    $list[$l][$c]["name"] = "sizeopts";
    $list[$l][$c]["value"] = "fill";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Force to be a primary partition";
    $c++;
    $list[$l][$c]["type"] = "checkbox";
    $list[$l][$c]["name"] = "asprimary";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Make partition on specific drive";
    $c++;
    $list[$l][$c]["type"] = "checkbox";
    $list[$l][$c]["name"] = "ondisk";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "ondiskval";
    $list[$l][$c]["size"] = "3";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Use existing partition";
    $c++;
    $list[$l][$c]["type"] = "checkbox";
    $list[$l][$c]["name"] = "onpart";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "onpartval";
    $list[$l][$c]["size"] = "3";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Format";
    $c++;
    $list[$l][$c]["type"] = "checkbox";
    $list[$l][$c]["name"] = "format";
    $list[$l][$c]["checked"] = "1";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["value"] = "&nbsp;";
    $l++; $c = 0;

    $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&partf=1");
    $smarty->assign('listsubmitbox', "Add");

  }
  else {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Partition";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Filesystem";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Size (MB)";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Delete";
    $l++; $c = 0;
    //$j = 1;
    //for ($i = 0; $i < count($_SESSION["ks"][$_GET["pg"]]["disks"]); $i++) {
    foreach ($_SESSION["ks"][$_GET["pg"]]["disks"] as $j => $val) {
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = $_SESSION["ks"][$_GET["pg"]]["disks"][$j]["mountpoint"];
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = $_SESSION["ks"][$_GET["pg"]]["disks"][$j]["filesystem"];
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = $_SESSION["ks"][$_GET["pg"]]["disks"][$j]["size"];
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&rmdisk=$j\">Remove</a>";
      $l++; $c = 0;
      //$j++;
    }

    $btext = "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&add=1\">Add partition</a>";

    $nextpage = $_GET["pg"] + 1;
    $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");
    $smarty->assign('listsubmitbox', "Next");
  }

  $smarty->assign('list', $list);
  $smarty->assign('btext', $btext);

  $smarty->display("$template/table.tpl");
}


/*
 * Network Configurations
 */

elseif ($_GET["pg"] == "6") {
  //$_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  // Save added interface to session
  if ($_GET["netf"]) {
    if ($_GET["type"] == "dhcp") {
       $newif = array();
       $newif["ifname"] = $_GET["ifname"];
       $newif["type"] = $_GET["type"];
       $_SESSION["ks"][$_GET["pg"]]["iface"][] = $newif;
    }
    else {
      if ($_POST) $_SESSION["ks"][$_GET["pg"]]["iface"][] = $_POST;
    }
    header("Location: $_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"]);
  }
  // Remove a interface from session
  if ($_GET["rmnet"]) unset ($_SESSION["ks"][$_GET["pg"]]["iface"][$_GET["rmnet"]]);


  $smarty->assign('pheading', "Kickstart - Network Configuration");
  $list = array();
  $l = 0;
  $c = 0;

  if ($_GET["add"] == 1) {
    if ($_POST["type"] == "static") {
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "Interface";
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = $_POST["ifname"];
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "<input type=\"hidden\" name=\"ifname\" value=\"" . $_POST["ifname"] . "\">";
      $list[$l][$c]["data"] .= "<input type=\"hidden\" name=\"type\" value=\"static\">";
      $l++; $c = 0;


      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "IP Address";
      $c++;
      $list[$l][$c]["type"] = "input";
      $list[$l][$c]["name"] = "ipaddress";
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["name"] = "&nbsp;";
      $l++; $c = 0;

      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "Subnet mask";
      $c++;
      $list[$l][$c]["type"] = "input";
      $list[$l][$c]["name"] = "netmask";
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["name"] = "&nbsp;";
      $l++; $c = 0;

      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "Gateway";
      $c++;
      $list[$l][$c]["type"] = "input";
      $list[$l][$c]["name"] = "gateway";
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["name"] = "&nbsp;";
      $l++; $c = 0;
  
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "Nameserver (dns)";
      $c++;
      $list[$l][$c]["type"] = "input";
      $list[$l][$c]["name"] = "nameserver";
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["name"] = "&nbsp;";
      $l++; $c = 0;

      $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&netf=1");
      $smarty->assign('listsubmitbox', "Add");
    }
    else {
      header("Location: $_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&netf=1&type=dhcp&ifname=" . $_POST["ifname"]);
    }
  }
  else {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Interface";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Type";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "IP (Netmask)";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Delete";
    $l++; $c = 0;
    foreach ($_SESSION["ks"][$_GET["pg"]]["iface"] as $j => $val) {
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = $_SESSION["ks"][$_GET["pg"]]["iface"][$j]["ifname"];
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = $_SESSION["ks"][$_GET["pg"]]["iface"][$j]["type"];
      $c++;
      $list[$l][$c]["type"] = "text";
      if ($_SESSION["ks"][$_GET["pg"]]["iface"][$j]["type"] == "static") {
        $list[$l][$c]["data"] = $_SESSION["ks"][$_GET["pg"]]["iface"][$j]["ipaddress"] . " (" . $_SESSION["ks"][$_GET["pg"]]["iface"][$j]["netmask"] . ")";
      }
      else {
        $list[$l][$c]["data"] = "auto (auto)";
      }
      $c++;
      $list[$l][$c]["type"] = "text";
      $list[$l][$c]["data"] = "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&rmnet=$j\">Remove</a>";
      $l++; $c = 0;
    }

    $btext = "<form method=\"POST\" action=\"" . $_SERVER[PHP_SELF] . "?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=" . $_GET["pg"] . "&add=1\">";
    $btext .= "Add interface: <select name=\"ifname\">"; 
    for($i=0; $i < 10; $i++) {
      $btext .= "<option value=\"eth$i\">eth$i</option>";
    }
    $btext .= "</select>";
    $btext .= "&nbsp; &nbsp; Type: <select name=\"type\"> <option value=\"dhcp\">DHCP</option> <option value=\"static\">Static IP</option> </select>";
    $btext .= "&nbsp; &nbsp; <input type=\"submit\" value=\"Add\"></form>";

    $nextpage = $_GET["pg"] + 1;
    $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");
    $smarty->assign('listsubmitbox', "Next");
  }

  $smarty->assign('list', $list);
  $smarty->assign('btext', $btext);

  $smarty->display("$template/table.tpl");
}

/*
 * Authentication, root password, firewall
 */


elseif ($_GET["pg"] == "7") {
  $smarty->assign('pheading', "Kickstart - Auth, root password, firewall");
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Enable NIS authentication";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "nis";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Enable LDAP authentication";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "ldap";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Enable Kerberos 5 authentication";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "krb5";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Enable Hesiod authentication";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "hesiod";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Enable SMB authentication";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "smb";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Enable Name Switch Cache";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "nscd";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Use Shadow Passwords";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "shadow";
  $list[$l][$c]["checked"] = "1";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Use MD5";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "md5";
  $list[$l][$c]["checked"] = "1";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Root Password";
  $c++;
  $list[$l][$c]["type"] = "password";
  $list[$l][$c]["name"] = "rootpassword";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Inital user login";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "user";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Initial user password";
  $c++;
  $list[$l][$c]["type"] = "password";
  $list[$l][$c]["name"] = "rootpassword";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Initial user full name";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "userfname";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Firewall enabled";
  $c++;

  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "firewall";
  $l++; $c = 0;

  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");

}


/*
 * Authentication contd
 */ 
elseif ($_GET["pg"] == "8") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $smarty->assign('pheading', "Kickstart - Auth, contd");
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;


  if ($_SESSION["ks"]["7"]["nis"] == "on") {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "NIS Domain";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "nisdomain";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "NIS Server";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "nisserver";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Use broadcast to find NIS server";
    $c++;
    $list[$l][$c]["type"] = "checkbox";
    $list[$l][$c]["name"] = "nisbroadcast";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;
    }
  
  if ($_SESSION["ks"]["7"]["ldap"] == "on") {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "LDAP Server";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "ldapserver";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "LDAP Base Name";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "ldapbase";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;
  }
  

  if ($_SESSION["ks"]["7"]["krb5"] == "on") {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Kerberos Realm";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "krbrealm";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Kerberos Domain Controller (KDC)";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "krbkdc";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Kerberos Master Server";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "krbmaster";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;
  } 
  
  if ($_SESSION["ks"]["7"]["hesiod"] == "on") {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Hesiod LHS";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "hesiodlhs";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Hesiod RHS";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "hesiodrhs";
    $l++; $c = 0;
  
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "&nbsp;";
    $c++;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["name"] = "&nbsp;";
    $l++; $c = 0;
  } 
  
  if ($_SESSION["ks"]["7"]["smb"] == "on") {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "SMB Servers:";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "smbservers";
    $l++; $c = 0;

    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "SMB Workgroup";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "smbworkgroup";
    $l++; $c = 0;
  }
  $nextpage = $_GET["pg"] + 1;
  if (!$_SESSION["ks"]["7"]["nis"] && !$_SESSION["ks"]["7"]["ldap"] && !$_SESSION["ks"]["7"]["krb5"] && !$_SESSION["ks"]["7"]["heiod"] && !$_SESSION["ks"]["7"]["smb"]) {
    header("Location: " . $_SERVER["PHP_SELF"] . "?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");
  }
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");

}


/*
 * X Window System
 */ 

elseif ($_GET["pg"] == "9") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $smarty->assign('pheading', "Kickstart - X Window System");
  $kf = new kickstart_func();
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Configure the X Window System";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "configurex";
  $list[$l][$c]["checked"] = "1";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Color depth";
  $c++;
  $ls = $kf->list_coldepth();
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "depth";
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
    $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
  }
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Resolution";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "resolution";
  $ls = $kf->list_resolution();
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "resolution";
  for ($i = 0; $i < count($ls); $i++) {
    $list[$l][$c]["data"][$i]["value"] = $ls[$i]["code"];
    $list[$l][$c]["data"][$i]["text"] = $ls[$i]["text"];
  }
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Default desktop";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "desktop";
  $list[$l][$c]["data"]["0"]["value"] = "gnome";
  $list[$l][$c]["data"]["0"]["text"] = "GNOME";
  $list[$l][$c]["data"]["1"]["value"] = "kde";
  $list[$l][$c]["data"]["1"]["text"] = "KDE";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Start the X Window System on boot";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "startx";
  $list[$l][$c]["checked"] = "1";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "On first boot, Setup Agent is";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "xfirstboot";
  $list[$l][$c]["data"]["0"]["value"] = "enabled";
  $list[$l][$c]["data"]["0"]["text"] = "Enabled";
  $list[$l][$c]["data"]["1"]["value"] = "disabled";
  $list[$l][$c]["data"]["1"]["text"] = "Disabled";
  $l++; $c = 0;



  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");

}

/*
 * Package selection
 */

elseif ($_GET["pg"] == "10") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $pxeprofileinfo = pxe_profileinfo($_GET["pxepid"]);
  $osid = $pxeprofileinfo["osid"];
  $osver = $_SESSION["ks"]["cfg"]["ver"];
  $smarty->assign('pheading', "Kickstart - Packages");
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Packages";
  $c++;
  $list[$l][$c]["type"] = "textarea";
  $list[$l][$c]["name"] = "packages";
  $list[$l][$c]["rows"] = "32";
  $list[$l][$c]["cols"] = "80";
  if (is_file("include/ks_pkg_$osid-$osver.txt")) {
    $ksfile = "include/ks_pkg_$osid-$osver.txt";
  }
  elseif (is_file("include/ks_pkg_$osid.txt")) {
    $ksfile = "include/ks_pkg_$osid.txt";
  }
  if (isset($ksfile)) {
    $lines = file($ksfile);
    foreach ($lines as $line) {
      $list[$l][$c]["data"] .= $line;
    }
  }
  else {
    $list[$l][$c]["data"] = "#\n";
    $list[$l][$c]["data"] .= "# No predefined package file was found for your distribution\n";
    $list[$l][$c]["data"] .= "# Please create your own custom package list\n";
    $list[$l][$c]["data"] .= "#\n";
    $list[$l][$c]["data"] .= "# For CentOS/Red Hat based system a list can be\n";
    $list[$l][$c]["data"] .= "# found with yum grouplist for groups of packages\n";
    $list[$l][$c]["data"] .= "# and yum list for individual packages\n";
    $list[$l][$c]["data"] .= "# \n";
    $list[$l][$c]["data"] .= "# \n";
  }
  $l++; $c = 0;


  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");

}


/*
 * Pre/post scripts
 */

elseif ($_GET["pg"] == "11") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $smarty->assign('pheading', "Kickstart - Pre/Post scripts");
  $list = array();
  $l = 0;
  $c = 0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Item";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Value";
  $l++; $c = 0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Prescript shell";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "preshell";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Pre-installation script";
  $c++;
  $list[$l][$c]["type"] = "textarea";
  $list[$l][$c]["name"] = "prescript";
  $list[$l][$c]["rows"] = "10";
  $list[$l][$c]["cols"] = "50";
  $list[$l][$c]["data"] = "";
  $l++; $c = 0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["name"] = "&nbsp;";
  $l++; $c = 0;


  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Postscript shell";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "postshell";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Run outside of the chroot environment";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "outsidechroot";
  $l++; $c = 0;

  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Post-installation script";
  $c++;
  $list[$l][$c]["type"] = "textarea";
  $list[$l][$c]["name"] = "postscript";
  $list[$l][$c]["rows"] = "10";
  $list[$l][$c]["cols"] = "50";
  $list[$l][$c]["data"] = "";
  $l++; $c = 0;


  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Next");

  $smarty->display("$template/table.tpl");

}


elseif ($_GET["pg"] == "12") {
  if ($_POST) $_SESSION["ks"][($_GET["pg"]-1)] = $_POST;
  $kf = new kickstart_func();
  $smarty->assign('pheading', "Kickstart - Finish");
  $list = array();
  $l = 0;
  $c = 0;
  $ks = $kf->parse_ks_frompost($_SESSION["ks"]);
  foreach ($ks as $k => $v) {
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "$v";
    $l++; $c = 0;
  }
  $list[$l][$c]["type"] = "text";
  //$list[$l][$c]["data"] = "<pre>" . print_r($_SESSION["ks"], TRUE) . "</pre>";
  $l++; $c = 0;


  $nextpage = $_GET["pg"] + 1;
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=" . $_GET["pxepid"] . "&pg=$nextpage");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Finish");

  $smarty->display("$template/table.tpl");

}

elseif ($_GET["pg"] == "13") {
  $kf = new kickstart_func();
  $ks = $kf->parse_ks_frompost($_SESSION["ks"]);
  $status = pxe_ks_upload($_GET["pxepid"],$ks,1,1);
  $smarty->assign('pheading', "Result of install kickstart");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep");

  $status = pxe_profile_add($_POST);
  if ($status == 0) {
    $smarty->assign('text', "The kickstart script was added successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The kickstart script failed to be added. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}



?>
