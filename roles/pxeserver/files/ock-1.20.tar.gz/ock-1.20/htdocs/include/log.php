<?php

$expl = "<h1>Log Viewer</h1> Search trough logs for events. You can look for events including kickstart logs, security logs, and configuration modification
logs.<br><br>Use the percentage character (%) as wildcard when searching for log entries.";
$smarty->assign('expl', $expl);

if ($_GET[a] == "modify") {
  $smarty->assign('pheading', "Modify");
}

else {
  $smarty->assign('pheading', "View logs");
  $htext = "<form action=\"$_SERVER[PHP_SELF]?p=log\" method=\"post\">";
  $htext .= "Log: <select name=\"logname\">";
  $htext .= "<option value=\"\">[all]</option>";
  $lognames =  listlognames();
  for ($i = 0; $i < count($lognames); $i++) {
    $htext .= "<option value=\"" . $lognames[$i]["logname"] . "\"";
    if ($lognames[$i]["logname"] == $_POST["logname"]) $htext .= " SELECTED"; 
    $htext .= ">" . $lognames[$i]["comment"] . "</option>";
    $htext .= "\n";
  }
  $htext .= "</select> &nbsp;";
  $htext .= "Key: <select name=\"key\">";
  $htext .= "<option value=\"\">[none]</option>";
  $keys = listsearchkeys();
  for ($i = 0; $i < count($keys); $i++) {
    $htext .= "<option value=\"" . $keys[$i]["key"] . "\"";
    if ($keys[$i]["key"] == $_POST["key"]) $htext .= " SELECTED"; 
    $htext .= ">" . $keys[$i]["name"] . "</option>";
    $htext .= "\n";
  }
  $htext .= "</select> &nbsp;";
  $htext .= "Word: <input type=\"text\" name=\"word\" value=\"" . $_POST["word"] . "\" size=\"8\"> &nbsp;";
  $htext .= "<select name=\"limit\">";
  $keys = listsearchlimit();
  for ($i = 0; $i < count($keys); $i++) {
    $htext .= "<option value=\"" . $keys[$i]["key"] . "\"";
    if ($keys[$i]["key"] == $_POST["limit"]) $htext .= " SELECTED";
    $htext .= ">" . $keys[$i]["name"] . " lines</option>";
    $htext .= "\n";
  }

  $htext .= "</select>";
  $htext .= "<input type=\"submit\" value=\"Update\">";
  $htext .= "</form>";
  $smarty->assign('htext', "$htext");
  $list = array();
  $j=0;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Log";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = "Item";
  $list[$j][2]["type"] = "text";
  $list[$j][2]["data"] = "User @ Client";
  $list[$j][3]["type"] = "text";
  $list[$j][3]["data"] = "Stamp";
  $j++;
  $logname=$_POST["logname"];
  $limit=$_POST["limit"];
  if ($_POST["key"] == "user") {
    $loguser = $_POST["word"];
  }
  elseif ($_POST["key"] == "remoteip") {
    $logremoteip = $_POST["word"];
  }
  elseif ($_POST["key"] == "remotehost") {
    $logremotehost = $_POST["word"];
  }
  elseif ($_POST["key"] == "ref") {
    $refkey = $_POST["key"];
    $ref = $_POST["word"];
  }
  $log = listlog($logname,$data,$refkey,$ref,$loguser,$logremoteip,$logremotehost,$limit);
  for ($i=0; $i < count($log); $i++) {
    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = $log[$i]["logtypecomment"];
    $list[$j][1]["type"] = "text";
    if (!$log[$i]["refdata"]) {  $log[$i]["refdata"] = "N/A"; }
    $list[$j][1]["data"] = $log[$i]["refdata"];
    $list[$j][2]["type"] = "text";
    $list[$j][2]["data"] = $log[$i]["loguser"] . " @ " . $log[$i]["logremotehost"];
    $list[$j][3]["type"] = "text";
    $list[$j][3]["data"] = $log[$i]["timestamp"];
    $j++;
    $list[$j][0]["type"] = "text";
    $list[$j][0]["span"] = "4";
    $list[$j][0]["data"] = "<i>" . $log[$i]["logdata"] . "</i>";

    $j++; 
    $list[$j][0]["type"] = "text";  
    $list[$j][0]["data"] = "<hr>"; 
    $list[$j][0]["span"] = "4"; 
    $j++;
  }

//  $smarty->assign('btext', "<a href=\"$_SERVER[PHP_SELF]?p=users&a=add\">Add user</a>");
  $smarty->assign('list', $list);
  $smarty->display("$template/table.tpl");

}


?>
