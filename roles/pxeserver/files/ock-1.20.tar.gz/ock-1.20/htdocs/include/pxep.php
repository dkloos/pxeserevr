<?php

$expl = "<h1>Info</h1>At this page you can configure PXE boot profiles, and Kickstart configurations.<br>
<br>
Click on the pencil button <img src='images/btn_edit.gif' width='24' height='24'> to change configration or, or the red x button <img src='images/btn_delete.gif' width='24' height='24'> to delete profiles.<br>
<br>
Profile name and desription is set under \"Mod\". Configuration of the PXE settings such as kernel and initrd image is set under \"PXE\". The kickstart script is modified in \"Kickstart\".<br>
<br>
An indication to if a profile already has a kickstart script can be seen under \"Got KS\"";

$smarty->assign('expl', $expl);

// PXE Main menu text
$pxe_main_menu_text = "<a href=\"$_SERVER[PHP_SELF]?p=pxep\"><img src=\"images/poweron-24x24.png\" width=\"24\" valign=\"center\">PXE boot profiles</a>";
$pxe_main_menu_text .= "&nbsp;|&nbsp;";
$pxe_main_menu_text .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=showimages\"><img src=\"images/world_globe-24x24.png\" width=\"24\" valign=\"center\">PXE boot images</a>";
$pxe_main_menu_text .= "&nbsp;|&nbsp;";
$pxe_main_menu_text .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=showtags\"><img src=\"images/tags-24x24.png\" width=\"24\" valign=\"center\">PXE & kickstart tags</a>";
$pxe_main_menu_text .= "<br>";



if ($_GET["a"] == "pxemod") {
  $l=0;
  $c=0;
  $list = array();
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;"; 
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;"; 
  $l++; $c=0;
  $pxeprofile = pxe_profileinfo($_GET[pxeprofileid]);
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "PXE profile name";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "name";
  $list[$l][$c]["data"] = $pxeprofile["name"];
  $list[$l][$c]["formid"] = make_formid("name");
  $list[$l][$c]["validate"] = "present";
  $list[$l][$c]["required"] = "true";

  $l++; $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Profile description";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "descr";
  $list[$l][$c]["data"] = $pxeprofile[descr];
  $l++; $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Appear in default boot?";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "defpxe";
  $list[$l][$c][checked] = $pxeprofile[defpxe];
  $l++; $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "--- Password protected?";
  $c++;
  $list[$l][$c]["type"] = "checkbox";
  $list[$l][$c]["name"] = "defpxepwd";
  $list[$l][$c][checked] = $pxeprofile["defpxepwd"];

 if ($pxeprofile["imagereadme"] != "") {
    $text .= "<br><br><br>";
    $text .= "<h3>README:</h3>";
    $text .= "<br>";
    $text .= nl2br($pxeprofile["imagereadme"]);
    $text .= "<br><br>";
    if ($pxeprofile["imagedir"] != "") $text .= "The boot image files for this PXE profile is located at: " . $tftpimagedir . "/" . $pxeprofile["imagedir"];
    $smarty->assign('btext', $text);
  }


  $smarty->assign('pheading', "Modify PXE profile");
  $smarty->assign('validate', "true");
  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=pxemodf&pxeprofileid=$_GET[pxeprofileid]");
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Submit modification");
  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "pxemodf") {
  $smarty->assign('pheading', "Result of PXE profile modification");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep");
  $status = pxe_profile_update($_GET[pxeprofileid], $_POST);
  if ($status == 0) {
    $smarty->assign('text', "The update was successfull.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The update failed. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "pxeadd" && !$_GET[pg]) {
  $smarty->assign('pheading', "Add a PXE Profile");
  $list = array();
  $l=0;
  $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $c++;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "&nbsp;";
  $l++;
  $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Profile name";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["formid"] = make_formid("name");
  $list[$l][$c]["validate"] = "present";
  $list[$l][$c]["required"] = "true";
  $list[$l][$c]["name"] = "profilename";
  $l++;
  $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Description";
  $c++;
  $list[$l][$c]["type"] = "input";
  $list[$l][$c]["name"] = "descr";
  $l++;
  $c=0;
  $list[$l][$c]["type"] = "text";
  $list[$l][$c]["data"] = "Boot image";
  $c++;
  $list[$l][$c]["type"] = "dropbox";
  $list[$l][$c]["name"] = "template";
  $pxeprofiles = pxe_imagefile_list();
  for ($i=0; $i < count($pxeprofiles); $i++) {
    $list[$l][$c]["data"][$i][value] = $pxeprofiles[$i]["id"];
    $list[$l][$c]["data"][$i][text] = $pxeprofiles[$i]["name"];
  }

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=pxeaddf");

  $smarty->assign('list', $list);
  $smarty->assign('validate', "true");
  $smarty->assign('listsubmitbox', "Add profile");

  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "imageupload") {
  $smarty->assign('pheading', "Upload boot image");

  $text = "<form method=\"post\" action=\"$_SERVER[PHP_SELF]?p=pxep&a=imageuploadf\" enctype=\"multipart/form-data\">";
  $text .= "Please select the boot image to upload. You can upload your custom image or see the OneClickKick website for a list of available images.";
  $text .= "<br><br>";
  $text .= "Image file <input type=\"file\" name=\"imagefile\"><br>";
  $text .= "<br><br>";
  $text .= "<input type=\"submit\" value=\"Send\">";
  $text .= "</form>";
  $text .= "<br><br>";
  $text .= "<i>If you experience issues uploading images, make sure php.ini setting upload_max_filesize & post_max_size is set adequately.";
  $text .= " \"upload_max_filesize\" is currently set to " . ini_get('upload_max_filesize') . ", and \"post_max_size\" is currently set to " . ini_get('post_max_size') . ".</i>";
  $smarty->assign('text', $text);

  $smarty->display("$template/text.tpl");

}


elseif ($_GET["a"] == "pxeadd" && $_GET[pg] == "2") {
  $smarty->assign('pheading', "Add a PXE Profile");
  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = "&nbsp;";
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "&nbsp;";
  $list[1][0]["type"] = "text";
  $list[1][0]["data"] = "Profile name";
  $list[1][1]["type"] = "input";
  $list[1][1]["name"] = "profilename";
  $list[1][1]["data"] = $_POST[profilename];
  $list[2][0]["type"] = "text";
  $list[2][0]["data"] = "Description";
  $list[2][1]["type"] = "input";
  $list[2][1]["name"] = "descr";
  $list[2][1]["data"] = $_POST[descr];
  if ($_POST[template] == "0") {
    $list[3][0]["type"] = "text";
    $list[3][0]["data"] = "DEFAULT";
    $list[3][1]["name"] = "DEFAULT";
    $list[3][1]["type"] = "input";
    $list[3][1]["data"] = "install";

    $list[4][0]["type"] = "text";
    $list[4][0]["data"] = "PROMPT";
    $list[4][1]["name"] = "PROMPT";
    $list[4][1]["type"] = "input";
    $list[4][1]["data"] = "0";

    $list[5][0]["type"] = "text";
    $list[5][0]["data"] = "LABEL";
    $list[5][1]["name"] = "LABEL";
    $list[5][1]["type"] = "input";
    $list[5][1]["data"] = "install";

    $list[6][0]["type"] = "text";
    $list[6][0]["data"] = "MENU LABEL <input type=\"hidden\" name=\"pMENU LABEL\" value=\"LABEL\">";
    $list[6][1]["name"] = "MENU LABEL";
    $list[6][1]["type"] = "input";
    $list[6][1]["data"] = "Redhat 5 x86_64 installation";

    $list[7][0]["type"] = "text";
    $list[7][0]["data"] = "KERNEL";
    $list[7][1]["name"] = "KERNEL";
    $list[7][1]["type"] = "input";
    $list[7][1]["data"] = "img/rhel5/x86_64/vmlinuz";

    $list[8][0]["type"] = "text";
    $list[8][0]["data"] = "APPEND";
    $list[8][1]["name"] = "APPEND";
    $list[8][1]["type"] = "input";
    $list[8][1]["data"] = "initrd=img/rhel5/x86_64/initrd.img ks=_KS_ ksdevice=eth0";
  }


  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=pxeaddf");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Add PXE profile");
//  $smarty->assign('hidden', "<input type=\"hidden\" name=\"templateid\" value=\"$_POST[templateid]\">");

  $smarty->display("$template/table.tpl");


}

elseif ($_GET["a"] == "pxeaddf") {
  $smarty->assign('pheading', "Result of add profile");
  $status = pxe_profile_add($_POST);
  if ($status == 0) {
    $text = "The profile was added successfully.";

    if (pxe_image_get_readme($_POST["template"])) {
      $readme = pxe_image_get_readme($_POST["template"]);
      $text .= "<br><br><br>";
      $text .= "<h3>README!!</h3>";
      $text .= "<br>";
      $text .= nl2br($readme);
    }
    else {
      $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep");
    }
  }
  else {
    $status = errormsg($status);
    $text = "The profile failed to be added. \"$status\"";
  }

  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "pxemodcfg") {
  $smarty->assign('pheading', "Modify a PXE profile");
  $pxeinfo = pxe_profileinfo($_GET[pxeprofileid]);
  $pxeconf = pxe_profile_getconf($_GET[pxeprofileid]);

  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = $pxeinfo["name"];
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "&nbsp;";
  $j = 1;
  for ($i=0; $i < count ($pxeconf); $i++) {
    $list[$j][0]["type"] = "text";
    if ($pxeconf[$i][parent] != "0") { 
      $list[$j][0]["data"] = "&nbsp;&nbsp;&nbsp;--"; 
    }
    $list[$j][0]["data"] .= $pxeconf[$i][item];
    $list[$j][1]["type"] = "input";
    $list[$j][1]["name"] = $pxeconf[$i]["id"];
    $list[$j][1]["data"] = $pxeconf[$i][value];
    $j++;
  }

  if ($pxeinfo["imagereadme"] != "") {
    $text .= "<br><br><br>";
    $text .= "<h3>README:</h3>";
    $text .= "<br>";
    $text .= nl2br($pxeinfo["imagereadme"]);
    $text .= "<br><br>";
    if ($pxeinfo["imagedir"] != "")  $text .= "The boot image files for this PXE profile is located at: " . $tftpimagedir . "/" . $pxeinfo["imagedir"];
    $smarty->assign('btext', $text);
  }


  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=pxemodcfgf");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Update PXE profile");


  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "pxemodcfgf") {
	$smarty->assign('pheading', "Result of update PXE profile config");
	$smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep");

	$status = pxe_profile_updconf($_POST);
	if ($status == 0) {
		$smarty->assign('text', "The profile was updated successfully.");
	}
	else {
		$status = errormsg($status);
		$smarty->assign('text', "The profile failed to be updated. \"$status\"");
	}
	$smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "pxedel") {
  $smarty->assign('pheading', "Confirm removal of PXE Profile");
  $pxeinfo = pxe_profileinfo($_GET[pxeprofileid]);
  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = "&nbsp;";
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "&nbsp;";
  $list[1][0]["type"] = "text";
  $list[1][0]["data"] = "PXE profile name";
  $list[1][1]["type"] = "text";
  $list[1][1]["data"] = $pxeinfo["name"];

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=pxedelf&pxeprofileid=$_GET[pxeprofileid]");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Confirm");

  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "pxedelf") {
  $smarty->assign('pheading', "Result of PXE Profile removal");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep");
  $status = pxe_profile_del($_GET[pxeprofileid]);
  if ($status == 0) {
    $smarty->assign('text', "The PXE Profile was removed successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "Failed to remove the PXE Profile. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "imagedel" && !$_GET[pg]) {
  $smarty->assign('pheading', "Choose boot image to delete");
  $bimg = pxe_imagefile_list();

  $list = array();
  $i=0;
  $list[$i][0]["type"] = "text";
  $list[$i][0]["data"] = "&nbsp;";
  $list[$i][1]["type"] = "text";
  $list[$i][1]["data"] = "&nbsp;";
  $i++;
  $list[$i][0]["type"] = "text";
  $list[$i][0]["data"] = "Boot image";
  $list[$i][1]["type"] = "dropbox";
  $list[$i][1]["name"] = "image";

  for ($j=0; $j < count($bimg); $j++) {
    $list[$i][1]["data"][$j][value] = $bimg[$j]["id"];
    $list[$i][1]["data"][$j][text] = $bimg[$j]["name"];
  }
  $i++;

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=imagedel&pg=2");

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Delete image");

  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "imagedel" && $_GET[pg] == "2") {
  if (isset($_POST["image"])) $image = $_POST["image"];
  if (isset($_GET["image"])) $image = $_GET["image"];
  $smarty->assign('pheading', "Confirm boot image removal");
  $bimgi = pxe_ockimage_parse("$image");
  $text = "<form method=\"post\" action=\"$_SERVER[PHP_SELF]?p=pxep&a=imagedelf&image=$image\">";
  $text .= "Please confirm removal of boot image \"" . $bimgi[info]["name"] . "\"";
  $text .= "<br><br><br>";
  $text .= "<input type=\"submit\" value=\"Confirm\"></form>";
  $smarty->assign('text', "$text");
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "imagedelf") {
  $smarty->assign('pheading', "Result of boot image removal");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep");
  $status = pxe_imagefile_del($_GET[image]);
  if ($status == 0) {
    $smarty->assign('text', "The boot image was removed successfully.");
  }
  else {
    $inuseby = pxe_imagefile_in_use($_GET["image"]);
    $status = errormsg($status);
    $text .= "Failed to remove the boot image. \"$status\"";
    $text  .= "<br><br><br>";
    $text  .= "The PXE profiles currently using this boot image is:<br>";
    $text  .= "<ul>";
    foreach ($inuseby as $k) {
      $text .= "<li> $k</li>";
    }
    $text .= "</ul>";
    $smarty->assign('text', $text);
  }
  $smarty->display("$template/text.tpl");
}



elseif ($_GET["a"] == "ksmod" && $_GET["pg"] == "newks") {
  $smarty->assign('pheading', "Modify a Kickstart profile");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=" . $_GET["pxepid"]);
  if ($_POST["selact"] == "upload") {
    $status = pxe_ks_upload($_GET["pxepid"],$_FILES,$_GET["update"]);
  }
  elseif ($_POST["selact"] == "generate") {
    header("Location: $_SERVER[PHP_SELF]?p=pxep&a=kickstart&pxepid=$_GET[pxepid]&pg=0");
  }
  elseif ($_POST["selact"] == "copy") {
    $ks = pxe_ks_getconf($_POST["pxeprofileid"],0);
    for ($i=0; $i < count($ks) ; $i++) {
      $ksdata[] = $ks[$i]["data"];
    }
    $status = pxe_ks_upload($_GET["pxepid"],$ksdata,1,1);
  }
  else {
    header("Location: $_SERVER[PHP_SELF]?p=pxep");
  }
  if ($status == 0) {
    $smarty->assign('text', "The Kickstart file was loaded successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The Kickstart file did not load. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "ksmod") {
  $smarty->assign('pheading', "Modify Kickstart profile");
  $gotks = pxe_gotks($_GET[pxepid]);
  $info = pxe_profileinfo($_GET[pxepid]);
  $ks = pxe_ks_getconf($_GET[pxepid]);
  if ($_GET["ksdownload"] == 1) {
    $pxe_profileinfo = pxe_profileinfo($_GET[pxepid]);
    header('Content-type: text/plain');
    header('Content-Disposition: attachment; filename="ks-' . str_replace(' ', '_', strtolower($pxe_profileinfo["name"])) . '.cfg"');
    $ks = pxe_ks_getconf($_GET[pxepid],0);
    for ($i=0; $i < count($ks) ; $i++) {
      print $ks[$i]["data"] . "\n";
    }
    exit();
  }
  if ($_GET["edit"] == "1") {
    $j = 0;
    $list = array();

    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "<b>Kickstart for PXE profile:</b> " . $info["name"];
    $j++;

    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "&nbsp;";
    $j++;   

    $list[$j][0]["type"] = "textarea";
    $list[$j][0]["name"] = "kickstartdata";
    $list[$j][0]["rows"] = 40;
    $list[$j][0]["cols"] = 90;

    for ($i=0; $i < count($ks) ; $i++) {
      $list[$j][0]["data"] .= $ks[$i]["data"]. "\n";
    }
    $j++;

    $t = new tags();
    $tag_list = $t->get_list("ks");

    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "<b>Available kickstart tags: </b>";
    $j++;
//echo "<pre>";print_r($tag_list);
    for ($i=0; $i < count($tag_list); $i++) {
      $list[$j][0]["type"] = "text";
      $list[$j][0]["data"] = $tag_list[$i]["tagname"] . " => " . $tag_list[$i]["tagvalue"];
      $j++;
    }

    $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=ksmodff&pxepid=$_GET[pxepid]");
    $smarty->assign('list', $list);
    $smarty->assign('listsubmitbox', "Save");
    $smarty->display("$template/table.tpl");

  }
  elseif (($gotks == 0) && ($_GET[update] != "1")) {
    //$smarty->assign('btext', "<p><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=$_GET[pxepid]&update=1\">Replace kickstart</a></p>");
    $j = 0;
    $list = array();
    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "<p><img src=\"images/btn_replace.png\" width=\"24\" height=\"24\"><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=$_GET[pxepid]&update=1\">Replace kickstart</a> &nbsp;|&nbsp;";
    //$list[$j][0]["data"] .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=$_GET[pxepid]&edit=1\">Edit kickstart</a> &nbsp;|&nbsp;";
    $list[$j][0]["data"] .= "<img src=\"images/btn_edit.gif\" width=\"24\" height=\"24\"><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=$_GET[pxepid]&edit=1\">Edit kickstart</a> &nbsp;|&nbsp;";
    $list[$j][0]["data"] .= "<img src=\"images/btn_download.png\" width=\"24\" height=\"24\"><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=$_GET[pxepid]&ksdownload=1\" target=\"_blank\">Download kickstart file</a></p>";
    $j++;

    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "&nbsp;";
    $j++;


    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "<b>Kickstart for PXE profile:</b> " . $info["name"];
    $j++;

    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = "&nbsp;";
    $j++;   

    for ($i=0; $i < count($ks) ; $i++) {
      $list[$j][0]["type"] = "text";
      $list[$j][0]["name"] = $ks[$i]["id"];
      $list[$j][0]["data"] = $ks[$i]["data"];
      $list[$j][0]["size"] = 60;
      $j++;
    }

    $smarty->assign('list', $list);

    $smarty->display("$template/table.tpl");


  }
  else {
    if ($_GET[update] != "1") {
      $text = "<form method=\"post\" action=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=" . $_GET[pxepid] . "&pg=newks\" enctype=\"multipart/form-data\">";
      $text .= "This PXE profile does not currently have a kickstart script. "; 
    }
    else {
      $text = "<form method=\"post\" action=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=" . $_GET[pxepid] . "&pg=newks&update=1\" enctype=\"multipart/form-data\">";
      $text .= "This will replace current kickstart script for this PXE profile. ";
    }
    $text .= "Do you want to upload a kickstart file, or run the Kickstart generator? <br>";
    $text .= "<br>";
    $text .= "<input type=\"radio\" name=\"selact\" value=\"generate\" size=\"2\" checked>Kickstart generator<br>";
    $text .= "<input type=\"radio\" name=\"selact\" value=\"upload\"> Upload file <input type=\"file\" name=\"ksfile\"><br>";
    $text .= "<input type=\"radio\" name=\"selact\" value=\"copy\"> Copy from profile: <select name=\"pxeprofileid\">";
    $text .= "<option value=\"0\">---</option>";
    $pxeprofiles = pxe_profiles();
    for ($i=0; $i < count($pxeprofiles); $i++) {
      if (pxe_gotks($pxeprofiles[$i]["id"]) == "0") {
        $text .= "<option value=\"" . $pxeprofiles[$i]["id"] . "\">" . $pxeprofiles[$i]["name"] . "</option>";
      }
    }
    $text .= "</select>";
    $text .= "<br>";
    $text .= "<br><br>";
    $text .= "<input type=\"submit\" value=\"Next\">"; 
    $text .= "</form>";
    $smarty->assign('text', $text);
 

    $smarty->display("$template/text.tpl");
  }
}


elseif ($_GET["a"] == "ksmodff") {
  $smarty->assign('pheading', "Result of kickstart modification");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=" . $_GET["pxepid"]);

  foreach(explode("\n", $_POST["kickstartdata"]) as $k => $v) {
    $ks[] = "$v";
  }

  //$status = pxe_ks_updconf($_GET["pxepid"],$ks);
  $status = pxe_ks_upload($_GET["pxepid"],$ks,1,1);


  if ($status == 0) {
    $smarty->assign('text', "The kickstart script was updated successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The kickstart failed to be updated. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "imageuploadf") {
  $smarty->assign('pheading', "Result of boot image upload");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep&a=showimages");
  $status = pxe_imagefile_upload();
  if ($status == 0) {
    $smarty->assign('text', "The boot image was installed successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The boot image failed to be installed. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "kickstart") {
  include("include/kickstart.php");

}

elseif ($_GET["a"] == "showimages") {
  $htext = $pxe_main_menu_text;
  $smarty->assign('htext', $htext);

  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "OS";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Boot Image Name";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Delete</center>";
  $i++;

  $pxeimages = pxe_imagefile_list();

  for ($k=0; $k < count($pxeimages); $k++) {
    $os = os_info($pxeimages[$k]["osid"]);
    if (isset($os[0]["filename"])) $icon = $os[0]["filename"];
    if ($os == 255) $icon ="other";


    $j=0;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<img src=\"images/osicon_" . $icon . ".png\" width=\"20\">";
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $pxeimages[$k]["name"];
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=imagedel&pg=2&image=" . $pxeimages[$k]["id"] . "\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";

    $i++;
  }
  $btext .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=imageupload\"><img src=\"images/upload.gif\" width=\"24\" valign=\"center\">Upload boot image</a>";
  $btext .= "&nbsp;|&nbsp;";
  $btext .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=imagedel\"><img src=\"images/btn_delete.gif\" width=\"24\" valign=\"center\">Delete boot image</a>";
  $btext .= "<br>";
 
  $smarty->assign('btext', $btext);
  $smarty->assign('list', $list);
  $smarty->assign('tablecycle', true);
  $smarty->assign('pheading', "PXE Boot Images");
  $smarty->display("$template/table.tpl");

}

elseif ($_GET["a"] == "showtags") {
  $smarty->assign('pheading', "PXE & Kickstart tags");

  $htext = $pxe_main_menu_text;
  $smarty->assign('htext', $htext);
  $t = new tags();

  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Type";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Tag";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Value";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Modify</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Delete</center>";
  $i++;


  $taglist = $t->get_list();


//echo "<pre>"; print_r($taglist); echo "</pre>";

  for ($k=0; $k < count($taglist); $k++) {
    if ($taglist[$k]["tagtype"] == "pxe") $icon = "images/btn_terminal.png";
    if ($taglist[$k]["tagtype"] == "ks") $icon = "images/btn_wrench.png";


    $j=0;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<img src=\"" . $icon . "\" width=\"24\">";
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "_" . $taglist[$k]["tagname"] . "_";
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = nl2br($taglist[$k]["tagvalue"]);
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=tagedit&e=edit&tagid=" . $taglist[$k]["id"] . "\"><img src='images/btn_edit.gif' width='24' height='24'></a></center>";
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=tagdel&tagid=" . $taglist[$k]["id"] . "\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";
    $j++;

    $i++;
  }

  $btext = "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=tagedit&e=add\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Add new tag</a> <br>";
  $btext .= "<br>";
  $btext .= "<br>";
  $btext .= "Legend: PXE = <img src=\"images/btn_terminal.png\" width=\"24\"> and Kickstart = <img src=\"images/btn_wrench.png\" width=\"24\">.";
  $smarty->assign('btext', $btext);
  $smarty->assign('list', $list);
  $smarty->assign('tablecycle', true);
  $smarty->display("$template/table.tpl");

}

elseif ($_GET["a"] == "tagedit") {

  if ($_GET["e"] == "add") {
    $smarty->assign('pheading', "PXE & Kickstart tags - Add");
    $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=tageditf&e=add");
  }
  elseif ($_GET["e"] == "edit") {
    $smarty->assign('pheading', "PXE & Kickstart tags - Edit");
    $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=tageditf&e=edit&tagid=" . $_GET["tagid"]);
    $t = new tags();
    $taginfo = $t->get_entry($_GET["tagid"]);
  }
  $htext = "<li>Enter the tagname excluding the underlines. They will be added automatically. </li>"; 
  $htext .= "<li>The only allowed chars in the tagname is A-Z 0-9 and - </li>";
  $htext .= "<li>Choose tag type for kickstart or pxe use.";
  $smarty->assign('htext', $htext);


  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Item";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Value";
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Tag type";
  $j++;
  $list[$i][$j]["type"] = "dropbox";
  $list[$i][$j]["name"] = "tagtype";
  $k=0;
  $list[$i][$j]["data"][$k]["value"] = "ks";
  $list[$i][$j]["data"][$k]["text"] = "Kickstart";
  if ($_GET["e"] == "edit" && $taginfo["tagtype"] == "ks") $list[$i][$j]["data"][$k]["selected"] = "1";
  $k++;
  $list[$i][$j]["data"][$k]["value"] = "pxe";
  $list[$i][$j]["data"][$k]["text"] = "PXE";
  if ($_GET["e"] == "edit" && $taginfo["tagtype"] == "pxe") $list[$i][$j]["data"][$k]["selected"] = "1";
  $i++;


  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Tag name";
  $j++;
  $list[$i][$j]["type"] = "input";
  $list[$i][$j]["name"] = "tagname";
  if ($_GET["e"] == "edit") $list[$i][$j]["data"] = $taginfo["tagname"];
  $i++;

  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "Tagvalue";
  $j++;
  $list[$i][$j]["type"] = "textarea";
  $list[$i][$j]["rows"] = "10";
  $list[$i][$j]["cols"] = "60";
  if ($_GET["e"] == "edit") $list[$i][$j]["data"] = $taginfo["tagvalue"];
  $list[$i][$j]["name"] = "tagvalue";
  $i++;

  $smarty->assign('listsubmitbox', "Submit");
  $smarty->assign('list', $list);
  $smarty->display("$template/table.tpl");

}

elseif ($_GET["a"] == "tagdel") {
  $smarty->assign('pheading', "Confirm removal of tag");
  $t = new tags();
  $info = $t->get_entry($_GET["tagid"]);
  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = "&nbsp;";
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "&nbsp;";

  $list[1][0]["type"] = "text";
  $list[1][0]["data"] = "Tag name";
  $list[1][1]["type"] = "text";
  $list[1][1]["data"] = $info["tagname"];

  $list[2][0]["type"] = "text";
  $list[2][0]["data"] = "Tag value";
  $list[2][1]["type"] = "text";
  $list[2][1]["data"] = $info["tagvalue"];

  $list[3][0]["type"] = "text";
  $list[3][0]["data"] = "Tag type";
  $list[3][1]["type"] = "text";
  $list[3][1]["data"] = $info["tagtype"];

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=pxep&a=tageditf&e=del&tagid=" .$_GET["tagid"]);

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Confirm");

  $smarty->display("$template/table.tpl");
}



elseif ($_GET["a"] == "tageditf") {
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=pxep&a=showtags");
  $t = new tags();

  if ($_GET["e"] == "add") {
    $smarty->assign('pheading', "PXE & Kickstart tags - Add - Result");
    $status = $t->add_edit_entry("add",$_POST["tagtype"], $_POST["tagname"], $_POST["tagvalue"]);
  }
  elseif ($_GET["e"] == "edit") {
    $smarty->assign('pheading', "PXE & Kickstart tags - Edit - Result");
    $status = $t->add_edit_entry("edit",$_POST["tagtype"], $_POST["tagname"], $_POST["tagvalue"], $_GET["tagid"]);
  }
  elseif ($_GET["e"] == "del") {
    $smarty->assign('pheading', "PXE & Kickstart tags - Delete - Result");
    $status = $t->del_entry($_GET["tagid"]);
  }
 
  //$smarty->assign('htext', $htext);


  if ($status == 0) {
    $smarty->assign('text', "The tag was added/edited successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "Could not add/edit this tag. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}




else {

  $htext = $pxe_main_menu_text;
  $smarty->assign('htext', $htext);

  $list = array();
  $i=0;
  $j=0;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "OS";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "PXE Profile";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Kickstart</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Default Boot</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Password</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Modify</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>PXE</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Kickstart</center>";
  $j++;
  $list[$i][$j]["type"] = "text";
  $list[$i][$j]["data"] = "<center>Delete</center>";
  $i++;


  $pxeprofiles = pxe_profiles();
  for ($k=0; $k < count($pxeprofiles); $k++) {
    unset($ksinfo, $ks, $os); 
    $ks = pxe_gotks($pxeprofiles[$k]["id"]);
    $os = os_info($pxeprofiles[$k]["osid"]);
    if (isset($os[0]["filename"])) $icon = $os[0]["filename"];
    if ($os == 255) $icon ="other";
    
    $ksinfo = pxe_profileinfo($pxeprofiles[$k]["id"]);

    $j=0;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<img src=\"images/osicon_" . $icon . ".png\" width=\"20\">";
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $pxeprofiles[$k]["name"];
    $j++;


    if ($ksinfo["boottypeid"] < "2") {
      $ks="<center>n/a</center>"; 
    } 
    elseif ($ks == 0) { 
      $ks="<center>Yes</center>"; 
    } 
    else { 
      $ks="<center>No</center>"; 
    }
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $ks;
    $j++;

    if ($ksinfo["defpxe"] == 1) {
      $bootmenu="<center>Yes</center>"; 
    } 
    else { 
      $bootmenu="<center>No</center>"; 
    }
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $bootmenu;
    $j++;

    if ($ksinfo["defpxepwd"] == 1) {
      $bootmenupwd="<center>Yes</center>"; 
    } 
    else { 
      $bootmenupwd="<center>No</center>"; 
    }
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = $bootmenupwd;
    $j++;

    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=pxemod&pxeprofileid=" . $pxeprofiles[$k]["id"] . "\"><img src='images/btn_edit.gif' width='24' height='24'></a></center>";
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=pxemodcfg&pxeprofileid=" . $pxeprofiles[$k]["id"] . "\"><img src='images/btn_terminal.png' width='24' height='24'></a></center>";
    $j++;
    $list[$i][$j]["type"] = "text";
    if ($ksinfo["boottypeid"] == "2") {
      $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=ksmod&pxepid=" . $pxeprofiles[$k]["id"] . "\"><img src='images/btn_wrench.png' width='24' height='24'></a></center>";
    }
    else {
      $list[$i][$j]["data"] = "<center>&nbsp;</center>";
    }
    $j++;
    $list[$i][$j]["type"] = "text";
    $list[$i][$j]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=pxep&a=pxedel&pxeprofileid=" . $pxeprofiles[$k]["id"] . "\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";
    $i++;
  }
  $btext = "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=pxeadd\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Add PXE Profile</a>";
  $btext .= "&nbsp;|&nbsp;";
  $btext .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=imageupload\"><img src=\"images/upload.gif\" width=\"24\" valign=\"center\">Upload boot image</a>";
  $btext .= "&nbsp;|&nbsp;";
  $btext .= "<a href=\"$_SERVER[PHP_SELF]?p=pxep&a=imagedel\"><img src=\"images/btn_delete.gif\" width=\"24\" valign=\"center\">Delete boot image</a>";
  $btext .= "<br>";
  
  $smarty->assign('btext', $btext);
  $smarty->assign('list', $list);
  $smarty->assign('tablecycle', true);
  $smarty->assign('pheading', "PXE boot profiles");
  $smarty->display("$template/table.tpl");
}
?>
