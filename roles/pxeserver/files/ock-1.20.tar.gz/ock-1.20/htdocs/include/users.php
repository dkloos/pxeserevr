<?php

$expl = "<h1>Info</h1> User administration";
$smarty->assign('expl', $expl);

if ($_GET["a"] == "modify") {
  $smarty->assign('pheading', "Modify user account");
  $list = array();
  $j=0;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Item";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = "Value";
  $userinfo = user_info($_GET["id"]);
  $j++;

  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Username";
  $list[$j][1]["type"] = "input";
  $list[$j][1]["name"] = "username";
  $list[$j][1]["data"] = $userinfo["username"];
  $j++;

  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Name";
  $list[$j][1]["type"] = "input";
  $list[$j][1]["name"] = "name";
  $list[$j][1]["data"] = $userinfo["name"];
  $j++;

  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Password";
  $list[$j][1]["type"] = "password";
  $list[$j][1]["name"] = "password";
  $list[$j][1]["data"] = "nochange";
  $j++;

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=users&a=modifyf&id=".$_GET["id"]);
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Submit modification");
  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "modifyf") {
  $smarty->assign('pheading', "Result of add user modification");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=users");
  $status = user_modify($_GET["id"],$_POST);
  if ($status == 0) {
    $smarty->assign('text', "The user was modified successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The user failed to be modified. $status");
  }
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "add") {
  $smarty->assign('pheading', "Add an user account");
  $list = array();
  $j=0;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Item";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = "Value";
  $j++;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Username";
  $list[$j][1]["type"] = "input";
  $list[$j][1]["name"] = "username";
  $j++;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Name";
  $list[$j][1]["type"] = "input";
  $list[$j][1]["name"] = "name";
  $j++;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Password";
  $list[$j][1]["type"] = "password";
  $list[$j][1]["name"] = "password";
  $smarty->assign('listaction', $_SERVER[PHP_SELF]."?p=users&a=addf");
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Add user");
  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "addf") {
  $smarty->assign('pheading', "Result of add user account");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=users");
  $status = user_add($_POST);
  if ($status == 0) {
    $smarty->assign('text', "The user was added successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The user failed to be added. $status");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "delete") {
  $smarty->assign('pheading', "Delete an user account");
  $list = array();
  $j=0;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Item";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = "Value";
  $j++;
  $userinfo = user_info($_GET["id"]);
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Username";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = $userinfo[username];
  $j++;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Name";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = $userinfo["name"];

  $smarty->assign('listaction', "$_SERVER[PHP_SELF]?p=users&a=deletef&id=".$_GET["id"]);

  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Confirm");

  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "deletef") {
  $smarty->assign('pheading', "Result of delete user account");
  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=users");
  $status = user_delete($_GET["id"]);
  if ($status == 0) {
    $smarty->assign('text', "The user was deleted successfully.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "The user failed to be deleted. $status");
  }
  $smarty->display("$template/text.tpl");
}


else {
  $list = array();
  $j=0;
  $list[$j][0]["type"] = "text";
  $list[$j][0]["data"] = "Username";
  $list[$j][1]["type"] = "text";
  $list[$j][1]["data"] = "Name";
  $list[$j][2]["type"] = "text";
  $list[$j][2]["data"] = "<center>Modify";
  $list[$j][3]["type"] = "text";
  $list[$j][3]["data"] = "<center>Delete";
  $j++;
  $users = users_list();

  for ($i=0; $i < count($users); $i++) {
    $list[$j][0]["type"] = "text";
    $list[$j][0]["data"] = $users[$i][username];
    $list[$j][1]["type"] = "text";
    $list[$j][1]["data"] = $users[$i]["name"];
    $list[$j][2]["type"] = "text";
    $list[$j][2]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=users&a=modify&id=" . $users[$i]["id"] . "\"><img src='images/btn_edit.gif' width='24' height='24'></a></center>";
    $list[$j][3]["type"] = "text";
    $list[$j][3]["data"] = "<center><a href=\"$_SERVER[PHP_SELF]?p=users&a=delete&id=" . $users[$i]["id"] . "\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";
    $j++;
  }
 
  $users_ldapstrings = users_ldapstring_list();


  for ($i=0; $i < count($users_ldapstrings); $i++) {
    $users = users_ldap_list($users_ldapstrings[$i]["ldapstringid"]);

    //$users = users_ldap_list();
/*
echo "<pre>";      print_r($users);    echo "</pre>";
    for ($m=O; $m < count($users); $m++) {
      $list[$j][0]["type"] = "text";
      //$list[$j][0]["data"] = $users[$m]["username"];
      $list[$j][1]["type"] = "text";
      //$list[$j][1]["data"] = $users[$m]["name"];
      $list[$j][2]["type"] = "text";
      $list[$j][2]["data"] = "LDAP";
      $list[$j][3]["type"] = "text";
      $list[$j][3]["data"] = "LDAP";
      $j++;
    }
*/
  }

  $smarty->assign('pheading', "User administration");
  $smarty->assign('btext', "<a href=\"$_SERVER[PHP_SELF]?p=users&a=add\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Add user</a>");
  $smarty->assign('list', $list);
  $smarty->assign('tablecycle', true);
  $smarty->display("$template/table.tpl");

}
?>
