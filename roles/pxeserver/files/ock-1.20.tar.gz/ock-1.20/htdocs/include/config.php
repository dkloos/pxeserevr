<?php

$smarty->assign('expl', "<h1>Info</h1>These are the global configuration settings. ");

if ($_GET["a"] == "save") {
  $smarty->assign('pheading', "Save confguration");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=config");
  $status = config_update($_POST);
  $pxe_status = pxe_defaultfile_create();
  if ($status == "0" && $pxe_status == "0") {
    $smarty->assign('text', "The configuration was saved.");
  }
  else {
    $status = errormsg($status);
    $smarty->assign('text', "An error occoured. $status");
  }
  $smarty->display("$template/text.tpl");
}
else {
  $smarty->assign('pheading', "Configuration");
  $list = array();
  $l = 0;
  $list[$l][0]["type"] = "text";
  $list[$l][0]["data"] = "Item";
  $list[$l][1]["type"] = "text";
  $list[$l][1]["data"] = "Value";
  $l++;

  $sopts = config_avail_options();

  for ($i=0; $i < count($sopts); $i++) {
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = $sopts[$i]["desc"];
    $list[$l][1]["type"] = $sopts[$i]["type"];
    $list[$l][1]["name"] = $sopts[$i]["item"];
    unset ($optval);
    $optval = config_get_optvalue($sopts[$i]["item"]);
    $list[$l][1]["data"] = $optval;
    $l++;
  }
  $smarty->assign('list', $list);
  $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?p=config&a=save");
  $smarty->assign('listsubmitbox', "Submit changes");

  $smarty->display("$template/table.tpl");
}



?>
