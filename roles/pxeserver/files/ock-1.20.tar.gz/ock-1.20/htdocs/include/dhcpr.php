<?php



if ($_GET[a] == "regen") {
  $smarty->assign('pheading', "Regenerate DHCP conf");
//  $smarty->assign('redir', "$_SERVER[PHP_SELF]?p=dhcpr");

  // Regenerate DHCP config file and restart DHCP:
  $dhcp_status = generate_dhcpd_conf();
  if ($dhcp_status > 0) {
    $dhcp_status_text = errormsg("$dhcp_status");
  }
  else {
    $dhcp_status_text = "DHCP daemon restart OK.";
  }

  $dhcpd_version = dhcp_get_dhcpd_version();

  $text = "";
  $text .= "<h3>DHCP daemon version:</h3>";
  $text .= $dhcpd_version;
  $text .= "<br><br>";
  $text .= "<h3>DHCP daemon status:</h3>";
  $text .= $dhcp_status_text;
  if ($dhcp_status > 0) {
    $text .= "<br><br>";
    $text .= "<h3>Output from dhcpd:</h3>";
    $text .= "<pre>";
    foreach ($_SESSION[tmp][lastdhcpdoutput] as $line) {
      $text .= $line . "<br>";
    }
    $text .= "</pre>";
  }
  $text .= "<br><br>";
  $text .= "<h3>Contents of the last dhcpd.conf build:</h3>";
  $text .= "<pre>";
//  $text .= file_get_contents("$f_dhcpd_conf" . ".tmp");
  $text .= $_SESSION[tmp][lastdhcpdconf];
  $text .= "</pre>";

  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");
}
else {
  $smarty->assign('pheading', "Regenerate DHCP conf");
  $text = "Do you wish to regenerate the DHCP daemon configuration file?";
  $text .= "<br><br>";
  $text .= "<a href=\"$_SERVER[PHP_SELF]?p=dhcpr&a=regen\"> Yes </a> &nbsp; &nbsp;";
  $text .= "<a href=\"$_SERVER[PHP_SELF]?p=hosts\"> No </a>";
  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");
}


?>
