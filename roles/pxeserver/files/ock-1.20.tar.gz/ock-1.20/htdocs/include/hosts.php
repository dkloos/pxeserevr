<?php

$expl = "<h1>Info</h1>In this page you can configure each hosts dhcpgroup, and enable machines for PXE boot. <br>
<br>
Press the this button <img src=\"images/btn_edit.gif\" width=\"24\" height=\"24\"> to change a hosts group membership, and ethernet address if the host is in the local database.<br>
<br>
Press the green power on button <img src=\"images/btn_power_green.png\" width=\"24\" height=\"24\"> to enable a host for PXE boot using the profile assigned to the hosts DHCP group. Click on the hostname to view advanced PXE boot options.<br>
<br>
While a machine is enabled for PXE booting, the machine will be shown with a red power off button. Press this button to stop the machine from kickstart. <img src=\"images/btn_power_red.png\" width=\"24\" height=\"24\"><br>
<br>
If the machine is not member of a group, the machine cannot be enabled for PXE boot. <br>
<br>
If the machines IP address cannot be looked up from its hostname (forward lookup), a red exclamantion mark <img src=\"images/red_excl_mark.gif\" width=\"16\"> notification will appear. You will not be able to assign a static IP address to this machine. You will not be able to kickstart this machine from the PXE boot menu, unless a the kssendmac is specified in the PXE profile and supported by the boot image.<br>
<br>
If the machines hostname cannot be looked up from its IP address (reverse lookup), a yellow exclamation mark <img src=\"images/yellow_excl_mark.gif\" width=\"16\"> will appear. You will not be able to kickstart this machine from the PXE boot menu, unless a the kssendmac is specified in the PXE profile and supported by the boot image.<br>
<br>
If the machines mac address cannot be looked up, a network card symbol <img src=\"images/mac-address.gif\" width=\"16\"> will appear. These machines will not be included in any assigned dhcp group, and per group or per host settings will not be applied to this host.<br>
";
$smarty->assign('expl', $expl);

if ($_GET["a"] == "groupmod") {
  $hdetails = host_details_byname($_GET["host"],1);
  $hgdetails = host_group($_GET["host"]);
  $list = array();
  $l = 0;
  $c = 0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Item";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Value";
  $l++;

  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Hostname";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = $_GET["host"];
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "Naming source";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = strtoupper($hdetails["type"]);
  $l++;

  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "DHCP Group";
  $c++;
  $list["$l"]["$c"]["type"] = "dropbox";
  $list["$l"]["$c"]["name"] = "dhcpgroup";
  $dhcpgroups = dhcp_groups();
  $hostgroup = host_group($_GET["host"]);
  $j = 0;
  $list["$l"]["$c"]["data"]["$j"]["value"] = "0";
  $list["$l"]["$c"]["data"]["$j"]["text"] = "None";
  $j++;
  for ($i=0; $i < count($dhcpgroups); $i++) {
    $list["$l"]["$c"]["data"]["$j"]["value"] = $dhcpgroups["$i"]["id"];
    $list["$l"]["$c"]["data"]["$j"]["text"] = $dhcpgroups["$i"]["groupname"];
    if ($hostgroup["id"] == $dhcpgroups["$i"]["id"]) {
      $list["$l"]["$c"]["data"]["$j"]["selected"] = 1;
    }
    $j++;
  }
  $l++;
  if ($hdetails["type"] == "mysql" || ($_SESSION["CFG"]["ldap_ipa"] == 1 && $hdetails["type"] == "ldap")) {
    $c=0;
    $list[$l][$c]["type"] = "text";
    $list[$l][$c]["data"] = "Ethernet address";
    $c++;
    $list[$l][$c]["type"] = "input";
    $list[$l][$c]["name"] = "ether";
    $list[$l][$c]["data"] = $hdetails["ether"];
    $list[$l][$c]["formid"] = make_formid("ether");
    $l++;

  }

  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Use static IP for this host?";
  $c++;
  $list["$l"]["$c"]["type"] = "checkbox";
  $list["$l"]["$c"]["name"] = "statichost";
  $list["$l"]["$c"]["checked"] = $hgdetails["statichost"];
  $l++;

  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "PXE enable host NOW?";
  $c++;
  $list["$l"]["$c"]["type"] = "checkbox";
  $list["$l"]["$c"]["name"] = "pxeenablenow";
  $l++;

  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Comments";
  $c++;
  $list["$l"]["$c"]["type"] = "input";
  $list["$l"]["$c"]["name"] = "descr";
  $list["$l"]["$c"]["data"] = $hgdetails["descr"];
  $l++;

  $btext = "<i>Please note that a host can only have a static IP and comments attached if its assigned to a host group. Hosts not assigned to a host group cannot contain a comment, nor have a static ip address. Please see the subnets tab for assiging static ip's to non-dhcp-grouped hosts.</i>";
  $smarty->assign('btext', $btext);
  $smarty->assign('pheading', "Modify host");
  $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?p=hosts&a=groupmodf&host=" . $_GET["host"]);
  $smarty->assign('list', $list);
  $smarty->assign('validate', "yes");
  $smarty->assign('listsubmitbox', "Submit modification");
  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "groupmodf") {
  $bg = new ockd_client();
  $smarty->assign('pheading', "Result of host group modification");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
  $status = host_group_update($_GET["host"],$_POST["dhcpgroup"]);
  if ($status == 0) {
    $text = "The group update was successfull. <br>";
  }
  else {
    $text = "The group update failed. \"$status\" <br>";
  }
  if (isset($_POST["ether"])) {
    $text .= "<br><br>";
    $status = host_ether_update($_GET["host"], $_POST["ether"]);
    if ($status == 0) {
      $text .= "The ethers update was successfull. <br>";
    }
    else {
      $text .= "The ethers update failed. \"$status\" <br>";
    }
  }
  if ($_POST["dhcpgroup"] != "0") {
    $text .= "<br><br>";
    $status = host_details_update($_GET["host"]);
    if ($status == 0) {
      $text .= "The host details update was successfull. <br>";
    }
    else {
      $text .= "The host details update failed. \"$status\" <br>";
    }
  }
  if ($_POST["pxeenablenow"] == true) {
    $text .= "<br><br>";

    $host_group = host_group($_GET["host"]);
    $host_group_id = $host_group["dhcpgroupmemid"];
    $host_group_pxeprofileid = $host_group["pxeprofileid"];
    $status = pxe_enable_client($host_group_id,$host_group_pxeprofileid,1);

    if ($status == 0) {
      $text .= "The host was PXE enabled successfully. <br>";
    }
    else {
      $text .= "Could not PXE enable host. \"$status\" <br>";
    }
  }


  $text .= "<br><br>";
  $status = $bg->run(generate_dhcpd_conf);
  if ($status == 0) {
    $text .= "The DHCP config was successfully updated. <br>";
  }
  else {
    $text .= "Update of DHCP config failed. " . errormsg($status) . " <br>";
  }


  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "delhostsql") {
  $smarty->assign('pheading', "Delete host " . $_GET["host"]);
  $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?p=hosts&a=delhostsqlf&host=" . $_GET["host"]);
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Confirm host");
  $smarty->display("$template/table.tpl");
}

elseif ($_GET["a"] == "delhostsqlf") {
  $smarty->assign('pheading', "Result of delete host");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
  $status = host_delete_sql($_GET["host"],$_POST["dhcpgroup"]);
  if ($status == 0) {
    $text = "Delete host " . $_GET["host"] . " was successfull. <br>";
  }
  else {
    $text = "Delete host " . $_GET["host"] . " failed. \"$status\" <br>";
  }
  $text .= "<br><br>";

  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");

}

elseif ($_GET["a"] == "addhost" || $_GET["a"] == "addhostbulk") {
  $list = array();
  $l = 0;
  $c = 0;

  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Item";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Value";
  $l++;

  if ($_GET["a"] == "addhost") {
    $default_hostname = host_get_next_default_hostname($_SESSION["get"]["system-serial-number"]);

    $smarty->assign('pheading', "Add a host");
    $smarty->assign('validate', "macaddr");
    $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?p=hosts&a=addhostf&host=" . $_GET["host"]);
    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Hostname";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "host";
    $list["$l"]["$c"]["data"] = $default_hostname;
    $list["$l"]["$c"]["validate"] = "present";
    $list["$l"]["$c"]["required"] = "true";
    $list["$l"]["$c"]["formid"] = make_formid("host");
    $l++;

    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Ethernet address (00:11:22:33:44:55)";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "ether";
    if ($_POST["ether"]) {
      $list["$l"]["$c"]["data"] = $_POST["ether"];
    }
    $list["$l"]["$c"]["validate"] = "ether";
    $list["$l"]["$c"]["required"] = "true";
    $list["$l"]["$c"]["formid"] = make_formid("ether");
    $l++;

  }
  elseif ($_GET["a"] == "addhostbulk") {
    $smarty->assign('pheading', "Host bulk import");
    $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?p=hosts&a=addhostbulkf");
    $htext = "Hosts found in the LDAP naming service will have it's mac address set and added to the requested group. Hosts not found in a NIS or LDAP naming service will be added to the local MySQL server before adding to the requested group.<br>";
    $htext .= "<br>";
    $htext .= "<br>";
    $htext .= "Format of the bulk import file:<br />";
    $htext .= "hostname;mac-address <br />";
    $htext .= "Example: hostnumberone;00:11:22:33:44:55 <br />";
    $smarty->assign('htext', $htext);
    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "File to upload";
    $c++;
    $list["$l"]["$c"]["type"] = "file";
    $list["$l"]["$c"]["name"] = "hostfile";
    $l++;
  }

  if ($_SESSION["CFG"]["ldap_ipa"] == "1" && $_GET["a"] != "addhostbulk") {

    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Description";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "desc";
    $l++;

    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Platform";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "platform";
    $l++;

    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "OS";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "os";
    $l++;


    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Location";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "location";
    $l++;

    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Locality";
    $c++;
    $list["$l"]["$c"]["type"] = "input";
    $list["$l"]["$c"]["name"] = "locality";
    $l++;




    $c=0;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "Assign IP in subnet";
    $c++;
    $list["$l"]["$c"]["type"] = "dropbox";
    $list["$l"]["$c"]["name"] = "subnetid";
   
    $dhcpsubnets = dhcp_subnets();

    $j = 0;
    $list["$l"]["$c"]["data"]["$j"]["value"] = "0";
    $list["$l"]["$c"]["data"]["$j"]["text"] = "Do not assign an IP address";
    $j++;
    for ($k=0; $k < count($dhcpsubnets); $k++) {
      if ($dhcpsubnets["$k"]["id"] == "0") continue;
      $list["$l"]["$c"]["data"]["$j"]["value"] = $dhcpsubnets["$k"]["id"];
      $list["$l"]["$c"]["data"]["$j"]["text"] = $dhcpsubnets["$k"]["descr"] . " (" . $dhcpsubnets["$k"]["subnet"] . "/" . $dhcpsubnets["$k"]["netmask"] . ")";
      $j++;
    }

    $l++;
   
  }
  
  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Database";
  $c++;
  $list["$l"]["$c"]["type"] = "dropbox";
  $list["$l"]["$c"]["name"] = "database";

  $j=0;
  if ($_SESSION["CFG"]["ldap_ipa"] == "1" && $_GET["a"] != "addhostbulk") {
    $list["$l"]["$c"]["data"]["$j"]["value"] = "ipa";
    $list["$l"]["$c"]["data"]["$j"]["text"] = "IPA";
    $j++;
  }

  $list["$l"]["$c"]["data"]["$j"]["value"] = "mysql";
  $list["$l"]["$c"]["data"]["$j"]["text"] = "MySQL";
  $j++;
  $l++;
 
  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "DHCP Group";
  $c++;
  $list["$l"]["$c"]["type"] = "dropbox";
  $list["$l"]["$c"]["name"] = "dhcpgroupid";
  $dhcpgroups = dhcp_groups();
  $j = 0;
  $list["$l"]["$c"]["data"]["$j"]["value"] = "0";
  $list["$l"]["$c"]["data"]["$j"]["text"] = "None";
  $j++;
  for ($i=0; $i < count($dhcpgroups); $i++) {
    $list["$l"]["$c"]["data"]["$j"]["value"] = $dhcpgroups["$i"]["id"];
    $list["$l"]["$c"]["data"]["$j"]["text"] = $dhcpgroups["$i"]["groupname"];
    if (isset($hostgroup["id"]) && ($hostgroup["id"] == $dhcpgroups["$i"]["id"])) {
      $list["$l"]["$c"]["data"]["$j"]["selected"] = 1;
    }
    $j++;
  }
  $l++;

  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "PXE enable host(s) NOW?";
  $c++;
  $list["$l"]["$c"]["type"] = "checkbox";
  $list["$l"]["$c"]["name"] = "pxeenablenow";
  $l++;

  $validate["ether"] = true;
  $smarty->assign('list', $list);
  $smarty->assign('listsubmitbox', "Add host");
  $smarty->display("$template/table.tpl");


}


elseif ($_GET["a"] == "addhostf") {
  $smarty->assign('pheading', "Result of add host");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
  if ($_POST["database"] == "mysql") {
    $status = host_add($_POST["host"], $_POST["ether"], $_POST["dhcpgroupid"], "sql");
  }
  elseif ($_POST["database"] == "ipa") {
    $_SESSION["IPACMD"]["redir"] = $_SERVER["PHP_SELF"] . "?p=hosts&a=addhostf&database=ipa";
    if (isset($_POST["pxeenablenow"])) $_SESSION["IPACMD"]["redir"] .= "&pxeenablenow=true";
    $status = host_add($_POST["host"], $_POST["ether"], $_POST["dhcpgroupid"], "ipa");
  }
  elseif ($_GET["database"] == "ipa") {
    $status = $_SESSION["IPACMD"]["RESULT"]["errcode"];
    if ($status != "0") $status = $_SESSION["IPACMD"]["RESULT"]["text"];
  }
  if ($status == "0") {
    $text = "Add host " . $_POST["host"] . " was successfull. <br>";
  }
  else {
    $text = "Add host " . $_POST["host"] . " failed. \"$status\" <br>";
  }

  if (is_array($_SESSION["IPACMD"]["RESULT"]["text"])) {
    foreach ($_SESSION["IPACMD"]["RESULT"]["text"]["txt"] as $val) {
      $text .= $val . "<br>";
    }
  }

  // PXE enable host if this was requested.

  if ($_POST["pxeenablenow"] == true || $_GET["pxeenablenow"] == true) {
    $text .= "<br><br>";

    if (isset($_POST["host"])) {
      $host = $_POST["host"];
    }
    elseif (isset($_GET["host"])) {
      $host = $_GET["host"];
    }

    $host_group = host_group($host);
    $host_group_id = $host_group["dhcpgroupmemid"];
    $host_group_pxeprofileid = $host_group["pxeprofileid"];
    $status = pxe_enable_client($host_group_id,$host_group_pxeprofileid);

    if ($status == 0) {
      $text .= "The host was PXE enabled successfully. <br>";
    }
    else {
      $text .= "Could not PXE enable host. \"$status\" <br>";
    }
  }


  $text .= "<br><br>";
  $status = generate_dhcpd_conf();
  if ($status == 0) {
    $text .= "The DHCP config was successfully updated. <br>";
  }
  else {
    $statusmsg = errormsg($status);
    $text .= "Update of DHCP config failed. \"$statusmsg\" <br>";
  }


  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");

  if ($_GET["database"] == "ipa") {
    unset($_SESSION["IPACMD"]);
  }

}


elseif ($_GET["a"] == "addhostbulkf") {
  $bg = new ockd_client();
  $smarty->assign('pheading', "Result of bulk add host");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
  $status = host_add_bulk($_POST["pxeenablenow"]);
  if (is_array($status)) {
    $text = "Status of host bulk import: <br>";
    for ($i=0; $i < count($status); $i++) {
      $text .= "Hostname: " . $status[$i]["host"] . ": " . $status[$i]["status"] .  "<br>";
    }
  }
  else {
    $text = "Host bulk import failed. \"$status\" <br>";
  }

  $text .= "<br><br>";
  $status = $bg->run(generate_dhcpd_conf);
  if ($status == 0) {
    $text .= "The DHCP config was successfully updated. <br>";
  }
  else {
    $text .= "Update of DHCP config failed. \"$status\" <br>";
  }

  $smarty->assign('text', $text);
  $smarty->display("$template/text.tpl");

}




elseif ($_GET["a"] == "enablepxe") {
  $smarty->assign('pheading', "Result of host enable pxe");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
  $status = pxe_enable_client($_GET["dhcpgroupmemid"],$_GET["pxeprofileid"]);
  if ($status == 0) {
    $smarty->assign('text', "The host was successfully enabled for PXE boot.");
  }
  elseif ($status == 1) {
    $smarty->assign('text', "The update failed. This host is already PXE disabled");
  }
  elseif ($status == 95) {
    $smarty->assign('text', "The update failed. File system permission errors.");
  }
  else {
    $smarty->assign('text', "The update failed. ");
  }
  $smarty->display("$template/text.tpl");
}
elseif ($_GET["a"] == "disablepxe") {
  $smarty->assign('pheading', "Result of host disable pxe");
  $smarty->assign('redir', $_SERVER["PHP_SELF"] . "?p=hosts");
  if ($_GET["forcedisable"] == "1") {
    $status = pxe_disable_client($_GET["dhcpgroupmemid"], 1);
  }
  else {
    $status = pxe_disable_client($_GET["dhcpgroupmemid"]);
  }
  if ($status == 0) {
    $smarty->assign('text', "The host was successfully disabled for PXE boot.");
  }
  elseif ($status == 1) {
    $smarty->assign('text', "The update failed. This host is already PXE enabled");
  }
  elseif ($status == 95) {
    $smarty->assign('text', "The update failed. File system permission errors.");
  }
  else {
    $smarty->assign('text', "The update failed. ");
  }
  $smarty->display("$template/text.tpl");
}

elseif ($_GET["a"] == "info") {
  $hinfo = host_group($_GET["host"]);
  // Get extended info
  $hdetails = host_details_byname($_GET["host"],1,1);
  $hgdetails = host_group($_GET["host"]);
  $active = pxe_checkactive($hinfo["dhcpgroupmemid"]);
  $gpxei = pxe_profile($hinfo["id"]);
  $smarty->assign('pheading', "Host info");


  $list = array();
  $l = 0;
  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "Hostname";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = $_GET["host"];
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "IP address";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = $hdetails["ip"];
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "MAC address";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = $hdetails["ether"];
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "Naming source";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = strtoupper($hdetails["type"]);
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "PXE Active";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = strtoupper($active);
  $l++;

  if ($hgdetails["statichost"] == 0) $statichost="No";
  if ($hgdetails["statichost"] == 1) $statichost="Yes";
  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "Static IP";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = strtoupper($statichost);
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "Comments";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = $hgdetails["descr"];
  $l++;

  
  if ($active == "yes") {
    $gpxeci = pxe_host_curprofile($hinfo["dhcpgroupmemid"]);
    $gotks = pxe_host_gotks($hinfo["dhcpgroupmemid"]);
    $hostgroup = host_group($_GET["host"]);
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Host downloaded kickstart script";
    $list["$l"]["1"]["type"] = "text";
    if ($gotks == 0) $list["$l"]["1"]["data"] = "yes (not longer PXE bootable)"; else $list["$l"]["1"]["data"] = "no";
    $l++;
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Current PXE profile";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = $gpxeci["name"];
    $l++;
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Disable PXE boot";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = "
<a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=disablepxe&dhcpgroupmemid=" . $hostgroup["dhcpgroupmemid"] . "&pxeprofileid=" . $hostgroup["pxeprofileid"] . "\"><img src='images/btn_power_red.png' width='24' height='24'></a>";
    $l++;


    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Force disable PXE boot (update DB only)";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = "
<a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=disablepxe&dhcpgroupmemid=" . $hostgroup["dhcpgroupmemid"] . "&pxeprofileid=" . $hostgroup["pxeprofileid"] . "&forcedisable=1\"><img src='images/btn_power_red.png' width='24' height='24'></a>";
    $l++;

  }



  if ($hinfo["id"]) {
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Default hostgroup";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = $hinfo["name"];
    $l++;

    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Default PXE profile";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = $gpxei["name"];
    $l++;
  }

  if ($_SESSION["CFG"]["ldap_ipa"] == "1" && isset($hdetails["extended"])) {
    //echo "<pre>"; print_r($hdetails); echo "</pre>";
    if (isset($hdetails["extended"]["krblastpwdchange"])) {
      $list["$l"]["0"]["type"] = "text";
      $list["$l"]["0"]["data"] = "[IPA] Enrolled";
      $list["$l"]["1"]["type"] = "text";
      $list["$l"]["1"]["data"] = date(DATE_RFC822, strtotime($hdetails["extended"]["krblastpwdchange"]));
      $l++;
    }
    if (isset($hdetails["extended"]["nshardwareplatform"])) {
      $list["$l"]["0"]["type"] = "text";
      $list["$l"]["0"]["data"] = "[IPA] Hardware Platform";
      $list["$l"]["1"]["type"] = "text";
      $list["$l"]["1"]["data"] = $hdetails["extended"]["nshardwareplatform"];
      $l++;
    }
    if (isset($hdetails["extended"]["nsosversion"])) {
      $list["$l"]["0"]["type"] = "text";
      $list["$l"]["0"]["data"] = "[IPA] OS Version";
      $list["$l"]["1"]["type"] = "text";
      $list["$l"]["1"]["data"] = $hdetails["extended"]["nsosversion"];
      $l++;
    }
    if (isset($hdetails["extended"]["description"])) {
      $list["$l"]["0"]["type"] = "text";
      $list["$l"]["0"]["data"] = "[IPA] Description";
      $list["$l"]["1"]["type"] = "text";
      $list["$l"]["1"]["data"] = $hdetails["extended"]["description"];
      $l++;
    }
    if (isset($hdetails["extended"]["nshostlocation"])) {
      $list["$l"]["0"]["type"] = "text";
      $list["$l"]["0"]["data"] = "[IPA] Location";
      $list["$l"]["1"]["type"] = "text";
      $list["$l"]["1"]["data"] = $hdetails["extended"]["nshostlocation"];
      $l++;
    }
    if (isset($hdetails["extended"]["l"])) {
      $list["$l"]["0"]["type"] = "text";
      $list["$l"]["0"]["data"] = "[IPA] Locality";
      $list["$l"]["1"]["type"] = "text";
      $list["$l"]["1"]["data"] = $hdetails["extended"]["l"];
      $l++;
    }
  }
  if ($active == "no" && $hinfo["dhcpgroupmemid"]) {
    $gotks = pxe_host_gotks($hinfo["dhcpgroupmemid"]);
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "PXE enable using profile <form method=\"GET\" action=\"" . $_SERVER["PHP_SELF"] . "\">";
    $list["$l"]["1"]["type"] = "dropbox";
    $list["$l"]["1"]["name"] = "pxeprofileid";
    $pxeprofiles = pxe_profiles();
    for ($i=0; $i < count($pxeprofiles); $i++) {
      $list["$l"]["1"]["data"]["$i"]["value"] = $pxeprofiles["$i"]["id"];
      $list["$l"]["1"]["data"]["$i"]["text"] = $pxeprofiles["$i"]["name"];
      if ($hinfo["pxeprofileid"] == $pxeprofiles["$i"]["id"]) $list["$l"]["1"]["data"]["$i"]["selected"] = 1;
    }
    $l++;
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "&nbsp;";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = "<input type=\"submit\" value=\"PXE enable now\"> <input type=\"hidden\" name=\"p\" value=\"hosts\"><input type=\"hidden\" name=\"a\" value=\"enablepxe\"><input type=\"hidden\" name=\"dhcpgroupmemid\" value=" . $hinfo["dhcpgroupmemid"] . "></form>";

    $l++;
  }

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "&nbsp;";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = "&nbsp;";
  $l++;


  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "Edit";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = "<button onClick=window.location=\"?p=hosts&a=groupmod&host=" . $_GET["host"] . "\">Edit host</button>";
  $l++;

  if ($hdetails["type"] == "mysql") {
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "Delete";
    $list["$l"]["1"]["type"] = "text";
    $list["$l"]["1"]["data"] = "<button onClick=window.location=\"?p=hosts&a=delhostsql&host=" . $_GET["host"] . "\">Delete host</button>";
    $l++;
  }

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "&nbsp;";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = "&nbsp;";
  $l++;

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "&nbsp;";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = "&nbsp;";
  $l++;

  // Output last 5 log entries for this host

  $log = listlog($logname,$data,$refkey,$_GET["host"],$loguser,$logremoteip,$logremotehost,5);

  $list["$l"]["0"]["type"] = "text";
  $list["$l"]["0"]["data"] = "&nbsp; ";
  $list["$l"]["1"]["type"] = "text";
  $list["$l"]["1"]["data"] = "&nbsp;";
  $l++;

  for ($i=0; $i < count($log); $i++) {
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = $log["$i"]["logtypecomment"];
    $list["$l"]["1"]["type"] = "text";
    if (!$log["$i"]["refdata"]) {  $log["$i"]["refdata"] = "N/A"; }
    $list["$l"]["1"]["data"] = $log["$i"]["refdata"];
    $list["$l"]["2"]["type"] = "text";
    $list["$l"]["2"]["data"] = $log["$i"]["loguser"] . " @ " . $log["$i"]["logremotehost"];
    $list["$l"]["3"]["type"] = "text";
    $list["$l"]["3"]["data"] = $log["$i"]["timestamp"];
    $l++;
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["span"] = "4";
    $list["$l"]["0"]["data"] = "<i>" . $log["$i"]["logdata"] . "</i>";

    $l++;
    $list["$l"]["0"]["type"] = "text";
    $list["$l"]["0"]["data"] = "<hr>";
    $list["$l"]["0"]["span"] = "4";
    $l++;
  }

  $smarty->assign('list', $list);

  $smarty->display("$template/table.tpl");
}



elseif ($_GET["a"] == "addsyslog") {
  $list = array();
  $l = 0;
  $c = 0;
  $smarty->assign('pheading', "Add a host from syslog");
  $smarty->assign('htext', "These hosts has been seen in the dhcp daemon syslog file since the log file was last rotated, but are not currently known in any of the configured name sources.");
  $smarty->assign('validate', "macaddr");
  $smarty->assign('listaction', $_SERVER["PHP_SELF"] . "?p=hosts&a=addhost");
  $smarty->assign('listsubmitbox', "Add host");

  $syslog_hosts = host_parse_syslog();

  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "<nlbr>";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "MAC Address";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Last seen";
  $c++;
/*
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Last seen with IP";
  $c++;
*/
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Resolves to";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "From";
  $l++;

  foreach ($syslog_hosts as $ether => $ip) {
    $c=0;
    $list["$l"]["$c"]["type"] = "radio";
    $list["$l"]["$c"]["name"] = "ether";
    $list["$l"]["$c"]["value"] = $ether;
    $c++;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = $ether;
    $c++;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = $syslog_hosts[$ether]["date"];
    $c++;
/*
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = $syslog_hosts[$ether]["ip"];
    $c++;
*/
    if ($syslog_hosts[$ether]["noip"] == "0") {
      $list["$l"]["$c"]["type"] = "text";
      $list["$l"]["$c"]["data"] = gethostbyaddr($syslog_hosts[$ether]["ip"]);
    }
    else {
      $list["$l"]["$c"]["type"] = "text";
      $list["$l"]["$c"]["data"] = "no-free-leases";
    }
    $c++;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = $syslog_hosts[$ether]["from"];
    $l++;

  }

  $smarty->assign('list', $list);

  $smarty->display("$template/table.tpl");
}



else {
  $hosts = hosts_list();
  sort($hosts);
  $i=0;

  $l=0;
  $c=0;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Hostname";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "Current group";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "<center>Kickstart</center>";
  $c++;
  $list["$l"]["$c"]["type"] = "text";
  $list["$l"]["$c"]["data"] = "<center>Modify</center>";
  if ($mysqlenabled == 1) {
    $c++;
    $list["$l"]["$c"]["type"] = "text";
    $list["$l"]["$c"]["data"] = "<center>Delete</center>";
  }
  $c=0;
  $l++;



  while (list($hostid, $host) = each ($hosts)) {
    $hostdetails = host_details_byname($host);
    unset($notification, $notification2);
    //if ($hostdetails["ether"] != "") {
      $hostgroup = host_group($host);
      if (isset($hostgroup["dhcpgroupmemid"])) $active = pxe_checkactive($hostgroup["dhcpgroupmemid"]);
      if ($hostfqdn != "1") {
        $show_hostname = explode(".", $host);
	$show_hostname = $show_hostname["0"];
      }
      else {
        $show_hostname = $host;
      }
      // Check if an IP address was returned
      if (!preg_match("/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\$/", $hostdetails["ip"])) {
        $notification="<img src=\"images/red_excl_mark.gif\" width=\"16\">";
      }
      elseif ($hostdetails["iprev"] != $hostdetails["host"]) {
        $notification="<img src=\"images/yellow_excl_mark.gif\" width=\"16\">";
      }
      if (!isset($hostdetails["ether"])) $notification2 = "<img src=\"images/mac-address.gif\" width=\"16\">";
      $list["$l"]["$c"]["type"] = "text";
      $list["$l"]["$c"]["data"] = "<a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=info&host=$host\">$show_hostname</a>&nbsp;"; 
        if (isset($notification) || isset($notification2)) $list["$l"]["$c"]["data"] .= " $notification $notification2";
      $c++;
      $list["$l"]["$c"]["type"] = "text";
      if (isset($hostgroup["name"])) $list["$l"]["$c"]["data"] = $hostgroup["name"];
      $c++;
      $list["$l"]["$c"]["type"] = "text";
      if ((isset($hostgroup["name"])) && ($active == "no")) { 
	$list["$l"]["$c"]["data"] = "<center><a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=enablepxe&dhcpgroupmemid=" . $hostgroup["dhcpgroupmemid"] . "&pxeprofileid=" . $hostgroup["pxeprofileid"] . "\"><img src='images/btn_power_green.png' width='24' height='24'></a></center>"; 
      }
      elseif ((isset($hostgroup["name"])) && ($active == "yes")) { 
        $list["$l"]["$c"]["data"] = "<center><a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=disablepxe&dhcpgroupmemid=" . $hostgroup["dhcpgroupmemid"] . "&pxeprofileid=" . $hostgroup["pxeprofileid"] . "\"><img src='images/btn_power_red.png' width='24' height='24'></a></center>"; 
      }
      $c++;
      $list["$l"]["$c"]["type"] = "text";
      $list["$l"]["$c"]["data"] = "<center><a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=groupmod&host=$host\"><img src='images/btn_edit.gif' width='24' height='24'></a></center>";
      if ($mysqlenabled == 1) {
        $c++;
        $list["$l"]["$c"]["type"] = "text";
        if ($hostdetails["type"] == "mysql") {
          $list["$l"]["$c"]["data"] = "<center><a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=delhostsql&host=$host\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";
        }
        else {
  	  $list["$l"]["$c"]["data"] = "&nbsp;";
        }
      }
      $c=0;
      $l++;
      $i++; 
    //}
  }
  $c++;

  $smarty->assign('pheading', "Hosts");
  $smarty->assign('list', $list);
  $smarty->assign('tablecycle', true);

  $btext = "";
  if ($_SESSION["CFG"]["mysqlenabled"] == "1" || $_SESSION["CFG"]["ldap_ipa"] == "1") {
    $btext .= "<a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=addhost\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Add host</a>";
    $btext .= " | ";
  }
  $btext .= "<a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=addhostbulk\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Host bulk import</a>";
  $btext .= " | <a href=\"" . $_SERVER["PHP_SELF"] . "?p=hosts&a=addsyslog\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Host syslog import</a>";
  $smarty->assign('btext', $btext);

  $smarty->display("$template/table.tpl");
}

?>
