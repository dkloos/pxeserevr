<?php

$expl = "<h1>Info</h1>At this page you can configure DHCP subnets.
<br><br>
Please keep in mind that configured global settings override non-configured local settings such as Dynamic DNS Updates and Authorative DHCP 
<br><br> 
Utilize the \"Include config file\" option to manually configure setings such as failover and certificates for dynamic dns update. Failover peer can be configured on a per subnet basis (Failover peer option). 
<br><br> 
The \"Static IP for members\" option will assign a static IP for all hosts within this subnet, that's not already been assigned to a DHCP group. The IP will be looked up from DNS. For hosts added to a DHCP group, please see the \"groups\" tab.
<br><br> 
The \"DNS lookup client ip address for D-DNS updates\" will look up the clients host name from DNS when doing D-DNS updates. <br><br> \"Authorative DHCP\" will make this DHCP server authorative for this subnet.";
$smarty->assign('expl', $expl);


if ($_GET["a"] == "add") {
  $smarty->assign('pheading', "Add DHCP Subnet");
  $list = array();
  $l = 0;
  $list[$l][0]["type"] = "text";
  $list[$l][0]["data"] = "Item";
  $list[$l][1]["type"] = "text";
  $list[$l][1]["data"] = "Value";
  $l++;

  $list[$l][0]["type"] = "text";
  $list[$l][0]["data"] = "Subnet";
  $list[$l][1]["type"] = "input";
  $list[$l][1]["name"] = "subnet";
  $list[$l][1]["data"] = "";
  $c=1;
  $list[$l][$c]["formid"] = make_formid("subnet");
  $list[$l][$c]["validate"] = "ipv4";
  $list[$l][$c]["required"] = "true";

  $l++;

  $list[$l][0]["type"] = "text";
  $list[$l][0]["data"] = "Netmask";
  $list[$l][1]["type"] = "input";
  $list[$l][1]["name"] = "netmask";
  $list[$l][1]["data"] = "";
  $c=1;
  $list[$l][$c]["formid"] = make_formid("netmask");
  $list[$l][$c]["validate"] = "ipv4";
  $list[$l][$c]["required"] = "true";
  $l++;

  $list[$l][0]["type"] = "text";
  $list[$l][0]["data"] = "Description";
  $list[$l][1]["type"] = "input";
  $list[$l][1]["name"] = "descr";
  $list[$l][1]["data"] = "";
  $c=1;
  $list[$l][$c]["formid"] = make_formid("descr");
  $list[$l][$c]["validate"] = "present";
  $list[$l][$c]["required"] = "true";
  $l++;

  $smarty->assign('list', $list);
  $smarty->assign('validate', "yes");
  $smarty->assign('listaction', $_SERVER["PHP_SELF"]."?p=dhcps&a=addf");
  $smarty->assign('listsubmitbox', "Add subnet");

  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "addf") {
  $smarty->assign('pheading', "Result of add subnet");
  $smarty->assign('redir', $_SERVER["PHP_SELF"]."?p=dhcps");
  $status = dhcp_subnetadd($_POST);
  if ($status == 0) {
    $smarty->assign('text', "The subnet was added successfully.");
  }
  else {
    $smarty->assign('text', "The subnet failed to be added. \"$status\"");
  }
  $smarty->display("$template/text.tpl");
}


elseif ($_GET["a"] == "mod") {
  $smarty->assign('pheading', "Modify DHCP Subnet");
  $list = array();
  $l = 0;
  $list[$l][0]["type"] = "text";
  $list[$l][0]["data"] = "Item";
  $list[$l][1]["type"] = "text";
  $list[$l][1]["data"] = "Value";
  $l++;

  // Get details for the selected subnet
  $sinfo = dhcp_subnetinfo($_GET["dhcpsid"]);

  // Get available options for the selected subnet
  $sopts = dhcp_avail_options($_GET["dhcpsid"]);
  for ($i=0; $i < count($sopts); $i++) {
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = $sopts[$i]["desc"];
    unset ($optval);
    $optval = dhcp_get_optvalue($_GET["dhcpsid"],$sopts[$i]["item"]);
    if ($sopts[$i]["type"] == "checkbox") {
      $list[$l][1]["type"] = "checkbox";
      $list[$l][1]["name"] = $sopts[$i]["item"];
      if ($optval == "#on") 	$list[$l][1][checked] = 1;
      if ($optval == "on") 	$list[$l][1][checked] = 1;
      if ($optval == "true") 	$list[$l][1][checked] = 1;
      if ($optval == "1") 	$list[$l][1][checked] = 1;
    }
    elseif ($sopts[$i]["type"] == "text") {
      $list[$l][1]["type"] = "text";
      $list[$l][1]["name"] = $sopts[$i]["item"];
      $list[$l][1]["data"] = "<b>" . $sopts[$i]["value"] . "</b>&nbsp;&nbsp;<i>(Pre-set)</i>" . "<input type=\"hidden\" name=\"" . $sopts[$i]["item"] . "\" value=\"" . $sopts[$i]["value"] . "\" " ;
    }
    else {
      $list[$l][1]["type"] = "input";
      $list[$l][1]["name"] = $sopts[$i]["item"];
      $list[$l][1]["data"] = $optval;
    }

    $list[$l][1]["formid"] = make_formid($sopts[$i]["item"]);
    $list[$l][1]["validate"] = $sopts[$i]["validate"];
    $list[$l][1]["required"] = $sopts[$i]["required"];
    $l++;
  }
  if ($_GET["dhcpsid"] > 0) {
    $smarty->assign('htext', "Leave item blank to use the global DHCP setting for the item. These settings will override global DHCP settings. Subnet, netmask and description cannot be left blank.");
  }
  else {
    $smarty->assign('htext', "These are the global DHCP settings. These settings will be overridden if subnet specific settings are set. ");
  }
  $smarty->assign('list', $list);
  $smarty->assign('validate', "yes");
  $smarty->assign('listaction', $_SERVER["PHP_SELF"]."?p=dhcps&a=modf&dhcpsid=".$_GET["dhcpsid"]);
  $smarty->assign('listsubmitbox', "Submit modification");

  $smarty->display("$template/table.tpl");
}
elseif ($_GET["a"] == "modf") {
  $smarty->assign('pheading', "Result of subnet modification");
  $smarty->assign('redir', $_SERVER["PHP_SELF"]."?p=dhcps");
  $status = dhcp_subnetupdate($_GET["dhcpsid"],$_POST);
  if ($status == 0) {
    $smarty->assign('text', "The update was successfull.");
  }
  else {
    $smarty->assign('text', "The update failed. \"$status\"");
  }
  $smarty->display("$template/text.tpl");


}

elseif ($_GET["a"] == "del") {
  $smarty->assign('pheading', "Delete DHCP Subnet");
  if ($_GET["dhcpsid"] > 0) {
    $list = array();
    $l = 0;
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "Item";
    $list[$l][1]["type"] = "text";
    $list[$l][1]["data"] = "Value";
    $l++;
  
    $sinfo = dhcp_subnetinfo($_GET["dhcpsid"]);
  
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "Subnet";
    $list[$l][1]["type"] = "text";
    $list[$l][1]["name"] = "subnet";
    $list[$l][1]["validate"] = "validatipv4";
    $list[$l][1]["data"] = $sinfo["subnet"];
    $l++;
  
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "Netmask";
    $list[$l][1]["type"] = "text";
    $list[$l][1]["name"] = "netmask";
    $list[$l][1]["data"] = $sinfo["netmask"];
    $l++;
  
    $list[$l][0]["type"] = "text";
    $list[$l][0]["data"] = "Description";
    $list[$l][1]["type"] = "text";
    $list[$l][1]["name"] = "descr";
    $list[$l][1]["data"] = $sinfo["descr"];
    $l++;
  
    $smarty->assign('list', $list);
    $smarty->assign('listaction',$_SERVER["PHP_SELF"]."?p=dhcps&a=delf&dhcpsid=".$_GET["dhcpsid"]);
    $smarty->assign('listsubmitbox', "Confirm deletion");
   }
   else {
     $smarty->assign('htext', "The global settings is not a scope you can delete");
     $smarty->assign('listaction', $_SERVER["PHP_SELF"]."?p=dhcps");
     $smarty->assign('listsubmitbox', "Back"); 
   }
  $smarty->display("$template/table.tpl");

}

elseif ($_GET["a"] == "delf") {
  $smarty->assign('pheading', "Result of delete subnet");
  $smarty->assign('redir', $_SERVER["PHP_SELF"]."?p=dhcps");
  $status = dhcp_subnetdel($_GET["dhcpsid"],$_POST);
  if ($status == 0) {
    $smarty->assign('text', "The removal was successfull.");
  }
  else {
    $smarty->assign('text', "The removal failed. \"$status\"");
  }
  $smarty->display("$template/text.tpl");


}


else {

  $list = array();
  $list[0][0]["type"] = "text";
  $list[0][0]["data"] = "Subnet";
  $list[0][1]["type"] = "text";
  $list[0][1]["data"] = "Description";
  $list[0][2]["type"] = "text";
  $list[0][2]["data"] = "<center>Modify</center>";
  $list[0][3]["type"] = "text";
  $list[0][3]["data"] = "<center>Delete</center>";

  $dhcpsubnets = dhcp_subnets();
  $i=1;
  for ($j=0; $j < count($dhcpsubnets); $j++) {
    $list[$i][0]["type"] = "text";
    $list[$i][0]["data"] = $dhcpsubnets[$j]["subnet"] . " / " . $dhcpsubnets[$j]["netmask"];
    $list[$i][1]["type"] = "text";
    $list[$i][1]["data"] = $dhcpsubnets[$j]["descr"];
    $list[$i][2]["type"] = "text";
    $list[$i][2]["data"] = "<center><a href=\"".$_SERVER["PHP_SELF"]."?p=dhcps&a=mod&dhcpsid=" . $dhcpsubnets[$j]["id"] . "\"><img src='images/btn_edit.gif' width='24' height='24'></a></center>";
    $list[$i][3]["type"] = "text";
    $list[$i][3]["data"] = "<center><a href=\"".$_SERVER["PHP_SELF"]."?p=dhcps&a=del&dhcpsid=" . $dhcpsubnets[$j]["id"] . "\"><img src='images/btn_delete.gif' width='24' height='24'></a></center>";

    $i++;
  }
  $smarty->assign('btext', "<a href=\"".$_SERVER["PHP_SELF"]."?p=dhcps&a=add\"><img src=\"images/btn_add_db.gif\" width=\"24\" valign=\"center\">Add subnet</a>");
  $smarty->assign('list', $list);
  $smarty->assign('pheading', "DHCP Subnets");
  $smarty->assign('tablecycle', true);
  $smarty->display("$template/table.tpl");
}

?>
