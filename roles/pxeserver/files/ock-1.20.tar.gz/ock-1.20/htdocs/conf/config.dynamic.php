<?php
/*
 * Dynamic configuration to be included from config.php
 */


if (is_callable("yp_get_default_domain")) {
  # NIS domain to use for lookups, by default, use systems nis domain
  $nisdomain=yp_get_default_domain();
}
else {
  $nisdomain="No NIS support";
}

/*
 *
 * MySQL configuration
 *
 */
if (isset($sqlhost) && isset($sqluser) && isset($sqlpwd) && isset($sqldb)) {
  $sql = mysql_connect("$sqlhost","$sqluser","$sqlpwd") or die("Could not connect to the SQL server $sqlhost. Exiting.");
  mysql_select_db("$sqldb", $sql) or die("Could not connect to the database");

  # Loop over the config table from the database, and create vars:
  $result = mysql_query("select item,value from config", $sql) or die("Could not read configuration from database. Exiting.");
  if ($result) {
    while ($r = mysql_fetch_array($result, MYSQL_NUM)) {
      $$r[0] = "$r[1]";
      $ckey = $r[0];
      $cvalue = $r[1];
      $_SESSION["CFG"]["$ckey"] = $cvalue;
    }
  }
}
else {
  echo "Missing host/user/password information for the database. Exiting.";
  die();
}


/*
 *
 * LDAP configuration
 *
 */
if (isset($_SESSION["CFG"]["ldapenabled"]) && $_SESSION["CFG"]["ldapenabled"] == "1") {
  if (is_callable("ldap_connect")) {


    // Authenticated bind
    if ($_SESSION["CFG"]["ldap_bind_type"] == "ldap" || $_SESSION["CFG"]["ldap_bind_type"] == "ldaps") {
      $ldap_servers = explode(" ", $_SESSION["CFG"]["ldap_servers"]);
      $server_string = "";
      foreach ($ldap_servers as $key => $server) {
        $server_string .= " " .$_SESSION["CFG"]["ldap_bind_type"] . "://" . $server;
      }
    $ldap_conn = ldap_connect($server_string, $_SESSION["CFG"]["ldap_server_port"]) or $alert[]["text"] = "Could not connect to LDAP server. " . ldap_error($ldap_conn);
     ldap_bind($ldap_conn, $_SESSION["CFG"]["ldap_bind_user"], $_SESSION["CFG"]["ldap_bind_password"]) or $alert[]["text"] = "Could not bind to LDAP server. " . ldap_error($ldap_conn);
    }
    else {
      $ldap_servers = explode(" ", $_SESSION["CFG"]["ldap_servers"]);
      $server_string = "";
      foreach ($ldap_servers as $key => $server) {
        $server_string .= " " . "ldap://" . $server;
      }

      $ldap_conn = ldap_connect($_SESSION["CFG"]["ldap_servers"], $_SESSION["CFG"]["ldap_server_port"]) or $alert[]["text"] = "Could not connect to LDAP server. " . ldap_error();
     // Unauthenticated bind
       ldap_bind($ldap_conn) or $alert[]["text"] = "Could not bind to LDAP server. Please check credentials. " . ldap_error();

    }

  }
  else {
    $alert[]["text"] = "LDAP name lookups has been enabled, but LDAP support for PHP is not installed.";
  }
}

/*
 *
 * Find default Time Zone and set various variables
 *
 */

if ($_SESSION["CFG"]["default_timezone"]) {
  date_default_timezone_set($_SESSION["CFG"]["default_timezone"]);
}
$webroot = dirname($_SERVER["SCRIPT_NAME"]);
// Workaround issues when webroot = /
if ($webroot == "/") unset($webroot);
$sm_template_dir = "templates";

if (!isset($_GET["a"])) {
  $_GET["a"] = NULL;
}

/*
 *
 * Smarty configuration 
 *
 */
include('Smarty/Smarty.class.php');
$smarty = new Smarty;
$smarty->template_dir = "templates/";
$smarty->compile_dir = "sm_templates_c/";
$smarty->config_dir = "conf/";
$smarty->cache_dir = "sm_cache/";
$smarty->assign('templatedir', "$webroot/templates/$template");
$smarty->assign('webroot', $webroot);
if (isset($_GET["p"])) $smarty->assign('p', $_GET["p"]);

?>
