<?php

// Nothing to see here. Redirect to root.

header("Location: ../");

?>
